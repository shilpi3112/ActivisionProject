package pageFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Utility;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Constants.Locales;

public class SupportHomePage {

	BaseClass base;
	SoftAssert sa;
	GamesPage ghp;
	ProductPage gpp;
	OnlineServicesHomePage oshp;
	SupportOptionsHomePage sohp;
	MyCasesHomePage mycasehp;
	LoginPage lp;

	@FindBy(xpath = "//a[@class='navbar-brand']")
	public WebElement homepagelink;
	@FindBy(xpath = "//*[@id='navbartest']/ul/li[1]/a")
	public WebElement games;
	@FindBy(xpath = "//*[@id='navbartest']/ul/li[2]/a")
	public WebElement OnlineServies;
	@FindBy(xpath = "//*[@id='navbartest']/ul/li[3]/a")
	public WebElement SupportOptions;
	@FindBy(xpath = "//*[@id='navbartest']/ul/li[4]/a")
	public WebElement MyCases;
	@FindBy(xpath = "//a[@class='log-in-link']")
	public WebElement loginbuttonlink;
	@FindBy(xpath = "//a[@class='sign-up-link']")
	public WebElement Signupbuttonlink;
	@FindBy(id = "sign-up")
	public WebElement Signuppage;
	@FindBy(id = "alertBar")
	public WebElement carouselalert;
	@FindBy(xpath = "//*[@id='alertBar']/span[1]")
	public WebElement carouselalerttext;
	@FindBy(xpath = "//*[@id='alertBar']/span[2]")
	public WebElement carouselalertlearnmore;
	@FindBy(xpath = "//*[@class='carousel slide']")
	public WebElement carousel;

	public WebElement BannerId(int no) {
		return Driver.getDriver().findElement(By.xpath("//*[@id='banner-" + no + "']"));
	}

	public WebElement BannerCTA1(int no) {
		return Driver.getDriver().findElement(By.xpath("//*[@id='banner-" + no + "']/div/div[2]/a[1]"));
	}

	public WebElement BannerCTA2(int no) {
		return Driver.getDriver().findElement(By.xpath("//*[@id='banner-" + no + "']/div/div[2]/a[2]"));
	}

	public WebElement herosupportBanner(int no) {
		return Driver.getDriver().findElement(By.xpath("//*[@id='banner-" + no + "']/div/div[1]//img"));
	}

	@FindBy(xpath = "//*[@class='glyphicon glyphicon-chevron-left']")
	public WebElement bannerleftcontrol;
	@FindBy(xpath = "//*[@class='glyphicon glyphicon-chevron-right']")
	public WebElement bannerrightcontrol;

	public List<WebElement> noofgamesincarousle() {
		return Driver.getDriver().findElements(By.xpath("//*[@class='carousel slide']/div/div"));
	}

	public List<WebElement> carousleindicator() {
		return Driver.getDriver().findElements(By.xpath("//*[@class='carousel-indicators']/li"));
	}

	@FindBy(xpath = "//div[@class='sso-bar-menu']//div[@class='sso-menu-element sso-support']")
	public WebElement SSOSupportlink;

	public WebElement gameslinkonhomepage(int no) {
		return Driver.getDriver().findElement(By.xpath("//div[@class='dark']//ul/li[" + no + "]/a"));
	}

	public WebElement gamesHeaderonhomepage(int no) {
		return Driver.getDriver().findElement(By.xpath("//div[@class='dark']//ul/li[" + no + "]/a/p"));
	}

	public WebElement gamenameonhomepage(int no) {
		return Driver.getDriver().findElement(By.xpath("//div[@class='dark']//ul/li[" + no + "]//img"));
	}

	public List<WebElement> listofgamesonhomepage() {
		return Driver.getDriver().findElements(By.xpath("//div[@class='dark']//img"));
	}

	public List<WebElement> footerlinks() {
		return Driver.getDriver()
				.findElements(By.xpath("//footer//div[@class='row']//a"));
	}

	@FindBy(xpath = "//div[@class='ot-btn-container']/button[2]")
	public WebElement confirmchoicepopup;

	@FindBy(id = "search-global-input-large")
	public WebElement searchtextbox;

	@FindBy(xpath = "//i[@class='glyphicon glyphicon-search']")
	public WebElement searchbutton;

	public List<WebElement> Searcharticleslist() {
		return Driver.getDriver().findElements(By.xpath("//div[@class='article-posts-list']//li"));
	}
	public List<WebElement> Searcharticleslistheader() {
		return Driver.getDriver().findElements(By.xpath("//*[@id='easyPaginate']//li[not(contains(@style, 'display: none;'))]//h3/a"));
	}

	public List<WebElement> Searcharticleslistheader2() {
		return Driver.getDriver().findElements(By.xpath("//*[@id='easyPaginate']/li[position()>10]//h3/a"));
	}
	
	public WebElement Searcharticleslistheader3(int no) {
		return Driver.getDriver().findElement(By.xpath("//*[@id='easyPaginate']//li["+no+"]//h3/a"));
	}
	@FindBy(id = "h1-btn")
	public WebElement Rateoursitelink;
	@FindBy(id = "q1")
	public WebElement Rateoursitefirstquestion;
	
	
	
	public SupportHomePage() throws Exception {

		PageFactory.initElements(Driver.getDriver(), this);
		base = new BaseClass();
		homepagelink.click();
	
	}

	public void ValidateGamesLinkOnHomepage(Localecodes name) throws Exception {
		SoftAssert sa = new SoftAssert();
			base.stepInfo("Test started");
		base.stepInfo("Naviage to Home page");
		base.stepInfo("Verify Games link on home page");
		//Driver.getinstance().waitForPageToBeReady();
		base.waitTillElemetToBeClickable(games);
		sa.assertTrue(games.isDisplayed());
		base.passedStep(games.getText() + "--->Games link is available on home page");
		base.stepInfo("Click on Games link on Home page");
		games.click();
		ghp = new GamesPage();
		base.waitTillElemetToBeClickable(ghp.GamesLogoheader);
		sa.assertTrue(ghp.GamesLogoheader.isDisplayed());
		base.passedStep("Games page is loaded and header is displayed corectly");
		String expurl=null;
		if(name.toString().equals(""))
		{
			if (BaseClass.ReadProperties("Jenkinsrun").equals("Yes")) {
			expurl = System.getProperty("url") + name.toString() + "games";
			}
			 else if (BaseClass.ReadProperties("Jenkinsrun").equals("No")) {
				 expurl = BaseClass.ReadProperties("url") + name.toString() + "games";
		}
		}
		else {
			if (BaseClass.ReadProperties("Jenkinsrun").equals("Yes")) {
				expurl = System.getProperty("url") + name.toString() + "/games";
			}
			 else if (BaseClass.ReadProperties("Jenkinsrun").equals("No")) {
		expurl = BaseClass.ReadProperties("url") + name.toString() + "/games";
			}
		}
		sa.assertEquals(Driver.getDriver().getCurrentUrl(), expurl);
		base.passedStep("Games URL is displayed corectly");
		sa.assertAll();
	}

	public void ValidateOnlineServicesLinkOnHomepage(Localecodes name) throws Exception {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Naviage to Home page");
		base.stepInfo("Verify OnlineServices link on home page");
		//Driver.getinstance().waitForPageToBeReady();
		base.waitTillElemetToBeClickable(OnlineServies);
		sa.assertTrue(OnlineServies.isDisplayed());
		base.passedStep(OnlineServies.getText() + "--->OnlineServices link is available on home page");
		base.stepInfo("Click on OnlineServices link on Home page");
		OnlineServies.click();
		oshp = new OnlineServicesHomePage();
		base.waitTillElemetToBeClickable(oshp.OnlineServicesHeader);
		sa.assertTrue(oshp.OnlineServicesHeader.isDisplayed());
		base.passedStep("OnlineServices page is loaded and header is displayed corectly");
		String expurl=null;
		if(name.toString().equals(""))
		{
			if (BaseClass.ReadProperties("Jenkinsrun").equals("Yes")) {
			expurl = System.getProperty("url") + name.toString() + "onlineservices";
			}
			 else if (BaseClass.ReadProperties("Jenkinsrun").equals("No")) {
				 expurl = BaseClass.ReadProperties("url") + name.toString() + "onlineservices";
		}
		}
		else {
			if (BaseClass.ReadProperties("Jenkinsrun").equals("Yes")) {
				expurl = System.getProperty("url") + name.toString() + "/onlineservices";
			}
			 else if (BaseClass.ReadProperties("Jenkinsrun").equals("No")) {
		expurl = BaseClass.ReadProperties("url") + name.toString() + "/onlineservices";
			}
		}
	
		sa.assertEquals(Driver.getDriver().getCurrentUrl(), expurl);
		base.passedStep("OnlineServices URL is displayed corectly");
		sa.assertAll();
	}

	public void ValidateSupportOptionsLinkOnHomepage(Localecodes name) throws Exception {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Naviage to Home page");
		base.stepInfo("Verify SupportOptions link on home page");
		//Driver.getinstance().waitForPageToBeReady();
		base.waitTillElemetToBeClickable(SupportOptions);
		sa.assertTrue(SupportOptions.isDisplayed());
		base.passedStep(SupportOptions.getText() + "--->SupportOptions link is available on home page");
		base.stepInfo("Click on SupportOptions link on Home page");
		SupportOptions.click();
			sohp = new SupportOptionsHomePage();
		base.waitTillElemetToBeClickable(sohp.supportoptionheader);
		sa.assertTrue(sohp.supportoptionheader.isDisplayed());
		base.passedStep("SupportOptions page is loaded and header is displayed corectly");
		String expurl=null;
		if(name.toString().equals(""))
		{
			if (BaseClass.ReadProperties("Jenkinsrun").equals("Yes")) {
			expurl = System.getProperty("url") + name.toString() + "options";
			}
			 else if (BaseClass.ReadProperties("Jenkinsrun").equals("No")) {
				 expurl = BaseClass.ReadProperties("url") + name.toString() + "options";
		}
		}
		else {
			if (BaseClass.ReadProperties("Jenkinsrun").equals("Yes")) {
				expurl = System.getProperty("url") + name.toString() + "/options";
			}
			 else if (BaseClass.ReadProperties("Jenkinsrun").equals("No")) {
		expurl = BaseClass.ReadProperties("url") + name.toString() + "/options";
			}
		}
		sa.assertEquals(Driver.getDriver().getCurrentUrl(), expurl);
		base.passedStep("SupportOptions URL is displayed corectly");
		sa.assertAll();
	}


	public void ValidateMyCasesLinkOnHomepage() throws Exception {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Naviage to Home page");
		base.stepInfo("Verify MyCases link on home page");
		//Driver.getinstance().waitForPageToBeReady();
		base.waitTillElemetToBeClickable(MyCases);
		sa.assertTrue(MyCases.isDisplayed());
		base.passedStep(MyCases.getText() + "--->MyCases link is available on home page");
		base.stepInfo("Click on MyCases link on Home page");
		MyCases.click();
		lp = new LoginPage();
		base.waitTillElemetToBeClickable(lp.loginpage);
		sa.assertTrue(lp.loginpage.isDisplayed());
		base.passedStep("Login page is loaded and displayed corectly");
		sa.assertTrue(Driver.getDriver().getCurrentUrl().contains("https://s.activision.com/activision/login?"));
		base.passedStep("Login URL is displayed corectly");
		sa.assertAll();
	}

	public void ValidateSignUpLinkOnHomepage() throws Exception {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Naviage to Home page");
		base.stepInfo("Verify SignUp link on home page");
		
		//Driver.getinstance().waitForPageToBeReady();
		Driver.getDriver().navigate().refresh();
		Thread.sleep(5000);
		base.waitTillElemetToBeClickable(Signupbuttonlink);
		sa.assertTrue(Signupbuttonlink.isDisplayed());
		base.passedStep(Signupbuttonlink.getText() + "--->Signupbutton link is available on home page");
		base.stepInfo("Click on SignUp link on Home page");
		Signupbuttonlink.click();
		base.waitTillElemetToBeClickable(Signuppage);
		sa.assertTrue(Signuppage.isDisplayed());
		base.passedStep("SignUp page is loaded and displayed corectly");
		sa.assertEquals(Driver.getDriver().getCurrentUrl(), "https://s.activision.com/activision/signup");
		base.passedStep("SignUp URL is displayed corectly");
		sa.assertAll();
	}

	public void ValidateLoginLinkOnHomepage(Localecodes code) throws Exception {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Naviage to Home page");
		base.stepInfo("Verify Login link on home page");
		Thread.sleep(5000);
		base.waitTillElemetToBeClickable(loginbuttonlink);
		
		sa.assertTrue(loginbuttonlink.isDisplayed());
		base.passedStep(loginbuttonlink.getText() + "--->Login link is available on home page");
		base.stepInfo("Click on Login link on Home page");
		loginbuttonlink.click();
		lp = new LoginPage();
		sa.assertTrue(lp.loginpage.isDisplayed());
		base.passedStep("Login page is loaded and displayed corectly");
		System.out.println(Driver.getDriver().getCurrentUrl());
		String expurl=null;
		if(code.toString().equals(""))
		{
			 expurl = "https://s.activision.com/activision/login?redirectUrl=https://support.activision.com/";
		}
		else {
		 expurl = "https://s.activision.com/activision/login?redirectUrl=https://support.activision.com/" +code.toString()+ "/homepage";
			
	}
		
		sa.assertEquals(Driver.getDriver().getCurrentUrl(),expurl);
			base.passedStep("Login URL is displayed corectly");
		sa.assertAll();
	}

	public void validateHeaderLinkURLForAllGames(Locales name) throws Exception {
		SoftAssert sa = new SoftAssert();
		Workbook wb = null;
		Sheet sheet = null;
		gpp = new ProductPage();

		base.passedStep(name.toString() + "----> Locale is selected successfully");
		homepagelink.click();

		File file = new File(Utility.HomePageGames);
		FileInputStream fis = new FileInputStream(file);
		wb = WorkbookFactory.create(fis);
               sheet = wb.getSheet(name.toString());
 

		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			//Driver.getinstance().waitForPageToBeReady();
			String ExpGameName = sheet.getRow(i).getCell(0).getStringCellValue();
			String ExpGameHeader = sheet.getRow(i).getCell(1).getStringCellValue();
			String ExpGameHeaderProductPage = sheet.getRow(i).getCell(2).getStringCellValue();
			String ExpRegionwiseurl = sheet.getRow(i).getCell(3).getStringCellValue();

			base.waitTillElemetToBeClickable(gamesHeaderonhomepage(i));
			System.out.println("------" + ExpGameName + "----------" + ExpGameHeader + "--------" + ExpRegionwiseurl);

			base.stepInfo("Validating header for Games on home page");
			String actualheader = gamesHeaderonhomepage(i).getText();
			sa.assertEquals(actualheader, ExpGameHeader);

			base.stepInfo("Validating Gamename on home page");
			String actualgamename = gamenameonhomepage(i).getAttribute("alt");
			sa.assertEquals(actualgamename, ExpGameName);

			base.stepInfo("Validating Gamelink on home page");
			String actualregionwiseurl = gameslinkonhomepage(i).getAttribute("href");
			sa.assertEquals(actualregionwiseurl, ExpRegionwiseurl);

			base.stepInfo("Click on games icon-->" + actualregionwiseurl);
			base.waitTillElemetToBeClickable(gamenameonhomepage(i));
			gamenameonhomepage(i).click();

			base.passedStep(actualregionwiseurl + "--Game is clicked and navigated to product page");
			base.waitTillElemetToBeClickable(gpp.gamesheader);
			base.stepInfo("Title of the Page is-----" + Driver.getDriver().getTitle());
			base.stepInfo("Actual Header of page is--- " + gpp.gamesheader.getText());

			base.stepInfo("Validating Game header on product home page");
			sa.assertEquals(gpp.gamesheader.getText(), ExpGameHeaderProductPage);

			if (actualgamename.equals(ExpGameName)) {
				base.passedStep("Game name is displayed as expected 'Actual is'--" + actualgamename+"==Expected is"+ExpGameName);
			} else {
				base.failedStep("Game name is displayed as expected 'Actual is'--" + actualgamename+"==Expected is"+ExpGameName);
				sa.fail();
			}
			if (actualheader.equals(ExpGameHeader))
		 {
				base.passedStep("Game Header of the page is displayed as expected 'Actual is'--" + actualheader+"==Expected is"+ExpGameHeader);

			} else {
				base.failedStep("Game Header of the page is displayed as expected 'Actual is'--" + actualheader+"==Expected is"+ExpGameHeader);
			sa.fail();
			}
			if (actualregionwiseurl.equals(ExpRegionwiseurl)
					&& gpp.gamesheader.getText().equals(ExpGameHeaderProductPage)) {
				base.passedStep("URL of the page is displayed as expected 'Actual is'--" + actualregionwiseurl+"==Expected is"+ExpRegionwiseurl);
				base.passedStep("Product Header of the page is displayed as expected 'Actual is'--" + gpp.gamesheader.getText()+"==Expected is"+ExpGameHeaderProductPage);

			} else {
			base.failedStep("URL of the page is displayed as expected 'Actual is'--" + actualregionwiseurl+"==Expected is"+ExpRegionwiseurl);
			base.failedStep("Product Header of the page is displayed as expected 'Actual is'--" + gpp.gamesheader.getText()+"==Expected is"+ExpGameHeaderProductPage);
		sa.fail();
			}
			Driver.getDriver().navigate().back();
		}
		fis.close();
		wb.close();
		sa.assertAll();
	}

	public void validateGamesAndCTANamesinCarouselBanner(Locales name) throws Exception {
		SoftAssert sa = new SoftAssert();
		gpp = new ProductPage();

		base.passedStep(name.toString() + "----> Locale is selected successfully");
		homepagelink.click();

		XSSFWorkbook wb = new XSSFWorkbook(Utility.HomePageCarouselGames);
		XSSFSheet sheet = null;
		sheet = wb.getSheet(name.toString());

		base.stepInfo("Get the number of games in hero Banner slide on home page");
		base.stepInfo("Get the Name of Each Item in Carousel on home page");

		for (int i = 1; i < sheet.getLastRowNum(); i++) {

			Driver.getinstance().waitForPageToBeReady();
			String BannerName = sheet.getRow(i).getCell(1).getStringCellValue();
			String BannerCTA1 = sheet.getRow(i).getCell(2).getStringCellValue();
			String BannerCTA2 = sheet.getRow(i).getCell(3).getStringCellValue();
			String CTA2Header = sheet.getRow(i).getCell(4).getStringCellValue();
			// for (int j = 1; j <= noofgamesincarousle().size(); j++) {
			// To Get the Name of Each Item in Carousel
			if (herosupportBanner(i).isDisplayed()) {

				String actualbanner = herosupportBanner(i).getAttribute("src");
				String[] a1 = actualbanner.split("/hero/");

				if (a1[1].trim().contains(BannerName)) {

					base.stepInfo("Validating hero Banner names on home page");
					sa.assertTrue(a1[1].trim().contains(BannerName));
					if (a1[1].trim().contains(BannerName)) {
						base.passedStep("Banner of the page is displayed as expected " + a1[1].trim());
					} else {
						base.failedStep("Banner of the page is not displayed as expected " + "Expected is -->"
								+ BannerName + "But actual displayed as-->" + a1[1].trim());
					}

					base.stepInfo("Validating banner 'Call to Action1' on home page");
					String actualBannerCTA1 = BannerCTA1(i).getAttribute("href");
					sa.assertEquals(actualBannerCTA1, BannerCTA1);

					base.ClickHold(BannerCTA1(i));
					String expurl = base.verifyChildWindowandReturnUrl(BannerCTA1(i));
					System.out.println(expurl);
					sa.assertEquals(expurl, BannerCTA1);
					if (actualBannerCTA1.equals(BannerCTA1)) {
						base.passedStep("Banner 'Call to Action1' name is displayed as expected " + actualBannerCTA1);
					} else {
						base.failedStep("Banner 'Call to Action1' name is displayed as expected " + "Expected is -->"
								+ BannerCTA1 + "But actual displayed as-->" + actualBannerCTA1);
					}
					while (true) {
						if (BannerCTA2(i).isDisplayed()) {
							base.stepInfo("Validating banner 'Call to Action2' on home page");
							base.ClickHold(BannerCTA2(i));
							String actualBannerCTA2 = base.verifyChildWindowandreturnheader(BannerCTA2(i),
									gpp.gamesheader);
							System.out.println("Header after navigation-->" + actualBannerCTA2);
							System.out.println("Header from excel---->" + CTA2Header);
							sa.assertEquals(actualBannerCTA2, CTA2Header);
							sa.assertEquals(BannerCTA2(i).getAttribute("href"), BannerCTA2);

							if (actualBannerCTA2.equals(CTA2Header)) {
								base.passedStep(
										"Banner 'Call to Action2' name is displayed as expected " + "Expected is -->"
												+ CTA2Header + "But actual displayed as-->" + actualBannerCTA2);
							} else {
								base.failedStep(
										"Banner 'Call to Action1' name is displayed as expected " + "Expected is -->"
												+ CTA2Header + "But actual displayed as-->" + actualBannerCTA2);
							}
							break;
						} else {
							base.waitTillElemetToBeClickable(bannerrightcontrol);
							bannerrightcontrol.click();
						}

					}

				}

				else {
					base.stepInfo("Clicking on the Arrow of the Carousel");
					base.waitTillElemetToBeClickable(bannerrightcontrol);
					bannerrightcontrol.click();
				}
				base.stepInfo("Clicking on the Arrow of the Carousel");
				base.waitTillElemetToBeClickable(bannerrightcontrol);
			
			}
			bannerrightcontrol.click();
			// }
		}
		
		
		wb.close();
		sa.assertAll();
	}

	public void validateMovingCarouselBanner() throws InterruptedException, IOException {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Navigate to home page");
		homepagelink.click();
		base.stepInfo("Size of games in banner list-->" + noofgamesincarousle().size());
		int currentimageindex = 0;

		for (int i = 0; i < noofgamesincarousle().size(); i++) {

			if (noofgamesincarousle().get(i).getAttribute("class").contains("active")) {
				currentimageindex = i;
				base.stepInfo("current image index" + currentimageindex);
				break;
			}
		}

		base.stepInfo("Wait 6-7 seconds for carousle to move");
		Thread.sleep(7000);
		int newimageindex = 0;

		for (int i = 0; i < noofgamesincarousle().size(); i++) {
			if (noofgamesincarousle().get(i).getAttribute("class").contains("active")) {
				newimageindex = i;
				base.stepInfo("new  image index" + newimageindex);
				break;
			}
		}
		sa.assertTrue(currentimageindex != newimageindex);
		if (currentimageindex != newimageindex)
		{
			base.passedStep("Banner is automatically moving after 5 secs");
		} else {
			base.failedStep("Banner is not automatically moving after 5 secs");
			sa.fail();
		}
		sa.assertAll();
	}

	public void verifyCarouselAlert(Locales name) throws Exception {
		SoftAssert sa = new SoftAssert();
		gpp = new ProductPage();
		homepagelink.click();
		base.stepInfo("Nagivate to home page and wait for page to load");
		base.waitForElementToBeVisible(carouselalert, 60);
		sa.assertTrue(carouselalert.isDisplayed());
		base.passedStep("Carousel alert is displayed on home page");
		List<String> expectedcarouselalerttext = base.readExcelColumnData(Utility.HomePageheaderlinks, name.toString(), "AlertText"); 
		sa.assertEquals(carouselalerttext.getText(),
				expectedcarouselalerttext.get(0));
		if(carouselalerttext.getText().equals(expectedcarouselalerttext.get(0)))
				{
		base.passedStep("Carousel alert text is displayed as expected on home page" + carouselalerttext.getText());
				}
		else 
		{
			base.failedStep("Carousel alert text is not displayed as expected on home page" + carouselalerttext.getText());
			
		}
		List<String> expectedcarouselalertsubtext = base.readExcelColumnData(Utility.HomePageheaderlinks, name.toString(), "AlertsubText"); 
		
		
		sa.assertEquals(carouselalertlearnmore.getText().trim(), expectedcarouselalertsubtext.get(0));
		if(carouselalertlearnmore.getText().trim().equals(expectedcarouselalertsubtext.get(0)))
{
		base.passedStep(
				"Carousel alert learn more is displayed as expected on home page" + carouselalertlearnmore.getText());
}
else {
	base.failedStep(
			"Carousel alert learn more is displayed as expected on home page" + carouselalertlearnmore.getText());
}
		
		base.stepInfo("Click on alert link on home page");
		carouselalert.click();
		base.waitForElementToBeVisible(gpp.accountrecoveryheader, 10);
		sa.assertTrue(gpp.accountrecoveryheader.isDisplayed());
		List<String> expectedcarouselalertheader = base.readExcelColumnData(Utility.HomePageheaderlinks, name.toString(), "AlertHeader"); 
		
		sa.assertEquals(gpp.accountrecoveryheader.getText(), expectedcarouselalertheader.get(0));
		if(gpp.accountrecoveryheader.getText().equals(expectedcarouselalertheader.get(0)))
{
		base.passedStep("Account recovery is displayed as expected on home page" + gpp.accountrecoveryheader.getText());
}
else {
	base.failedStep("Account recovery is displayed as expected on home page" + gpp.accountrecoveryheader.getText());
}
sa.assertAll();
}

	public void checkAllFooterLinksonHomePage(Locales name) throws Exception {
		SoftAssert sa = new SoftAssert();
		Map<String, String> nameMap = new HashMap<String, String>();
		base.stepInfo("Verify all footer links on home page");
		List<String> expectedurl = new ArrayList<>();
		List<String> expectedtitle = new ArrayList<>();
		base.stepInfo("Verify all footer links on home page");
		if(System.getProperty("url").equals("https://test.support.activision.com/"))
		{
		expectedurl = base.readExcelColumnData(Utility.HomePagefooterlinksUAT, name.toString(), "FooterURL");
		expectedtitle = base.readExcelColumnData(Utility.HomePagefooterlinksUAT, name.toString(), "Title");
		}
		else if (System.getProperty("url").equals("https://support.activision.com/"))
		{
			expectedurl = base.readExcelColumnData(Utility.HomePagefooterlinks, name.toString(), "FooterURL");
			expectedtitle = base.readExcelColumnData(Utility.HomePagefooterlinks, name.toString(), "Title");
			}
		
			for (int i = 0; i < expectedurl.size(); i++) {
		if(expectedtitle.get(i).equals("Activision Support"))
			{
			nameMap = base.verifyURLAndTitleOnNewOpenedTab(footerlinks().get(i), confirmchoicepopup);
			}
			else {
			nameMap = base.verifyURLAndTitleOnNewOpenedTab(footerlinks().get(i));
			}
		
			sa.assertEquals(nameMap.get("URL"), expectedurl.get(i));
			sa.assertEquals(nameMap.get("Title"), expectedtitle.get(i));
			if (nameMap.get("URL").equals(expectedurl.get(i)) && nameMap.get("Title").equals(expectedtitle.get(i))) {
				base.passedStep("Actual urls-->" + nameMap.get("URL") + "------------------"
						+ "is matching with the Url after navigating to link--->" + expectedurl.get(i));
			} else {
				base.failedStep("Actual urls-->" + nameMap.get("URL") + "------------------"
						+ "is not matching with the Url after navigating to link-->" + expectedurl.get(i));

			}
		}
		sa.assertAll();
	}

	
	public void validateSearchFunction() throws Exception {
		String searchterm = null;
		Workbook wb = null;
		File file1 = new File(Utility.HomePageSearch);
		wb = WorkbookFactory.create(file1);
		Sheet sheet = wb.getSheet("SearchResultsData");
		DataFormatter formatter = new DataFormatter();
		System.out.println(sheet.getRow(0).getPhysicalNumberOfCells());

		//for (int i = 1; i < sheet.getRow(0).getPhysicalNumberOfCells(); i++) {
		for (int i = 1; i < 3; i++) {
			List<String> expectedarticletitles = new ArrayList<>();
			searchterm = sheet.getRow(0).getCell(i).getStringCellValue();
			base.stepInfo("Search term is:--->"+searchterm);
			for (int j = 1; j < sheet.getLastRowNum(); j++) {
				String currentValue = formatter.formatCellValue(sheet.getRow(j).getCell(i));
				/*
				 * if (currentValue.isEmpty() || currentValue == null) {
				 * System.out.println("row is blank"); } else {
				 * expectedarticletitles.add(currentValue); } }
				 */
				if (!(currentValue.length() == 0)) {
					expectedarticletitles.add(currentValue);
				}
			}

			base.waitTillElemetToBeClickable(searchtextbox);
			searchtextbox.sendKeys(searchterm);
			base.passedStep("Term entered in search box is --->"+searchterm);
			searchbutton.click();
			base.passedStep("Clicked on search button icon");
			

			List<String> actualarticletitles = base.AddEelementsWithPagination(Searcharticleslistheader());
			base.stepInfo("List of terms from excel -->" + expectedarticletitles);
			base.stepInfo("List of terms from application --->" + actualarticletitles);
			sa.assertEquals(actualarticletitles, expectedarticletitles);
			base.passedStep("Search terms are matching");
		}
		wb.close();
	}


}

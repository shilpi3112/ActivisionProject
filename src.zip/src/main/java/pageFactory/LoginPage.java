package pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import automationLibrary.Driver;
import base.BaseClass;

public class LoginPage {

	BaseClass base;

	@FindBy(id = "login")
	WebElement loginpage;

	@FindBy(id = "username")
	WebElement usernametextbox;
	@FindBy(id = "password")
	WebElement passwordtextbox;
	@FindBy(id = "login-button")
	WebElement loginbutton;
	@FindBy(id = "recaptcha-anchor")
	WebElement recaptchaanchor;
	@FindBy(xpath = "//div[@class='recaptcha-checkbox-border']")
	WebElement checkmark;

	public LoginPage() {
		PageFactory.initElements(Driver.getinstance().getDriver(), this);
		base = new BaseClass();
	}

	/*
	 * public void Loginintoapplication() throws Exception { //String username =
	 * BaseClass.ReadProperties("username"); //String password =
	 * BaseClass.ReadProperties("password"); //System.out.println("Username is "
	 * +username +"_------------" ); //System.out.println("Password is " +password
	 * +"_------------" ); //
	 * 
	 * //base.waitTillElemetToBeClickable(loginbuttonlink);
	 * //loginbuttonlink.click();
	 * 
	 * base.waitTillElemetToBeClickable(usernametextbox);
	 * usernametextbox.sendKeys(username);
	 * 
	 * base.waitTillElemetToBeClickable(passwordtextbox);
	 * passwordtextbox.sendKeys(password);
	 * 
	 * 
	 * //WebDriverWait wait = new WebDriverWait(Driver.getinstance().getDriver(),
	 * Duration.ofSeconds(60));
	 * //wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath(
	 * "//iframe[@title='reCAPTCHA']")));
	 * 
	 * base.waitTillElemetToBeClickable(checkmark); Driver.getinstance();
	 * Driver.getDriver().switchTo().frame(0);
	 * Driver.getinstance().waitForPageToBeReady();
	 * 
	 * checkmark.click(); Driver.getinstance();
	 * Driver.getDriver().switchTo().defaultContent(); Thread.sleep(10000);
	 * 
	 * base.waitTillElemetToBeClickable(loginbutton); loginbutton.click();
	 * 
	 * 
	 * }
	 */
}

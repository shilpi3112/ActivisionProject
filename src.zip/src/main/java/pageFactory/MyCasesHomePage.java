package pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import automationLibrary.Driver;
import base.BaseClass;

public class MyCasesHomePage {

	BaseClass base;
	SoftAssert sa;

	@FindBy(xpath = "//div[@class='row bannerTitle']//h1")
	public WebElement OnlineServicesHeader;

	public MyCasesHomePage() throws Exception {

		Driver.getinstance();
		PageFactory.initElements(Driver.getDriver(), this);
		base = new BaseClass();
	}

}

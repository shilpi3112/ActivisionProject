package pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.GamesList;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Stopwatchtime;

public class SupportOptionsResultPage {

	BaseClass base;
	SupportHomePage shp;
	GamesPage gp;
	ProductPage productpage;

	@FindBy(id = "back-to-selections")
	public WebElement backtoselections;
	@FindBy(xpath = "//*[@class='logged-in show-text']")
	public WebElement headertext;
	@FindBy(id = "main-solution")
	public WebElement mainsolutionblock;
	@FindBy(xpath = "//*[@class='article-opt-block']/h3/a")
	public WebElement firstarticleblock;
	@FindBy(xpath = "//div[@class='feature-header-inner']/h1")
	public WebElement articleheader;
	@FindBy(xpath = "//*[@class='article-opt-block secondary-article']")
	public WebElement secondaryarticlesection;
	@FindBy(xpath = "//*[@class='container contact-us-mid-modual other-options']/div[2]//h3/a")
	public WebElement secondarticleblock1;
	@FindBy(xpath = "//*[@class='container contact-us-mid-modual other-options']/div[3]//h3/a")
	public WebElement secondarticleblock2;
	@FindBy(id = "contact-us-options-modual")
	public WebElement additionaloptionsection;
	@FindBy(xpath = "//div[@id='contact-us-options-modual']/h3")
	public WebElement additionaloptionsheading;
	@FindBy(xpath = "//*[@class='mini-icons product']/following-sibling::div//h4")
	public WebElement productheadertext;
	@FindBy(xpath = "//*[@class='mini-icons ticket']/following-sibling::div//h4")
	public WebElement ticketheadertext;
	@FindBy(xpath = "//*[@class='mini-icons online-services']/following-sibling::div//h4")
	public WebElement OnlineServicesheadertext;
	@FindBy(xpath = "//*[@class='mini-icons product']/following-sibling::div//p")
	public WebElement productsubtext;
	@FindBy(xpath = "//*[@class='mini-icons ticket']/following-sibling::div//p")
	public WebElement ticketsubtext;
	@FindBy(xpath = "//*[@class='mini-icons online-services']/following-sibling::div//p")
	public WebElement OnlineServicessubtext;
	@FindBy(xpath = "//*[@class='mini-icons ticket']")
	public WebElement ticketicon;
	@FindBy(xpath = "//*[@class='mini-icons product']")
	public WebElement producticon;
	@FindBy(xpath = "//*[@class='mini-icons online-services']")
	public WebElement OnlineServicesicon;
	@FindBy(id = "create-ticket")
	public WebElement createticketsection;
	@FindBy(xpath = "//*[@class='ticket-form close-btn']")
	public WebElement ticketclosebutton;
	@FindBy(xpath = "//*[@class='prod-info']/h1")
	public WebElement gamepage;
	@FindBy(xpath = "//*[@class='title default']")
	public WebElement accountrecoveryheader;
	@FindBy(xpath = "//h1[text()='Online Services']")
	public WebElement OnlineServicespage;
	@FindBy(xpath = "//*[@class='main-ico article']")
	public WebElement mainiconarticle;
	@FindBy(xpath = "//*[@class='main-ico ticket']")
	public WebElement mainiconticket;
	@FindBy(xpath = "//*[@class='main-ico ext-link']")
	public WebElement mainiconreportbug;
	@FindBy(xpath = "//h2[@class='intro-header']")
	public WebElement appealheader;

	public SupportOptionsResultPage() throws Exception {

		PageFactory.initElements(Driver.getDriver(), this);
		base = new BaseClass();
	}

	public void validateSuggestedOptions_Article1(String article1) throws Exception {
		SoftAssert sa = new SoftAssert();
		base.waitTillElemetToBeClickable(headertext);
		base.stepInfo("Verify header displayed for suggested options");
		sa.assertEquals(headertext.getText(), "We suggest the following option:");
		base.passedStep("Header for the suggested options is displayed as expected-->" + headertext.getText());
		base.stepInfo("Verify first article displayed for suggested options");
		sa.assertEquals(firstarticleblock.getText(), article1);
		base.passedStep("First articles block is displayed as expected-->" + firstarticleblock.getText());
		base.stepInfo("Click on first article displayed for suggested options");
		String articletitle = base.verifyChildWindowandreturnheader(firstarticleblock, articleheader);
		sa.assertTrue(articletitle.equals(article1));
		sa.assertAll();
	}

	public void validateSecondary_Article(String article1, String article2) throws Exception {
		SoftAssert sa = new SoftAssert();
		Driver.getinstance().scrollingToElementofAPage(secondarticleblock1);
		base.stepInfo("Verify second article displayed for suggested options");
		sa.assertEquals(secondarticleblock1.getText(), article1);
		base.passedStep("Second articles block is displayed as expected-->" + secondarticleblock1.getText());
		base.stepInfo("Click on second article displayed for suggested options");
		String articletitle = base.verifyChildWindowandreturnheader(secondarticleblock1, articleheader);
		System.out.println(articletitle + "------------" + article1);
		sa.assertTrue(articletitle.equals(article1));
		try {
			if (secondarticleblock2.isDisplayed()) {
				Driver.getinstance().scrollingToElementofAPage(secondarticleblock2);
				base.stepInfo("Verify second article displayed for suggested options");
				sa.assertEquals(secondarticleblock2.getText(), article2);
				base.passedStep("Second articles block is displayed as expected-->" + secondarticleblock2.getText());
				base.stepInfo("Click on second article displayed for suggested options");
				String articletitle2 = base.verifyChildWindowandreturnheader(secondarticleblock2, articleheader);
				sa.assertTrue(articletitle2.equals(article2));
			}
		} catch (Exception e) {
			base.passedStep("Secondry block 2nd article is not available");
		}
		sa.assertAll();
	}

	public void validateAdditionalOptionsSection() throws Exception {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Verify product section is displayed for suggested options");
		Driver.getinstance().scrollingToElementofAPage(additionaloptionsection);
		sa.assertTrue(additionaloptionsection.isDisplayed());
		base.passedStep("Additional options section is displayed as expected");
		base.stepInfo("Verify Additional options section header");
		sa.assertEquals(additionaloptionsheading.getText(), "Here are some additional options:");
		base.passedStep("Product section heading is displayed as expected-->" + additionaloptionsheading.getText());
		sa.assertAll();
	}

	public void validateSuggestedOptions_SubmitTicket(String ticketheader, String expticketsubtext) throws Exception {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Verify Submit ticket section is displayed for additional options");

		base.waitTillElemetToBeClickable(ticketicon);
		sa.assertTrue(ticketicon.isDisplayed());
		base.passedStep("Ticket icon is displayed as expected");
		sa.assertEquals(ticketheadertext.getText(), ticketheader);
		base.passedStep("Ticket heading text is displayed as expected-->" + ticketheadertext.getText());

		sa.assertEquals(ticketsubtext.getText(), expticketsubtext);
		base.passedStep("Ticket sub heading text is displayed as expected-->" + ticketsubtext.getText());

		base.stepInfo("Click on ticket heading");
		ticketheadertext.click();

		Driver.getinstance().scrollingToElementofAPage(createticketsection);
		sa.assertTrue(createticketsection.isDisplayed());
		base.passedStep("Create a ticket section is available and displayed");
		base.waitTillElemetToBeClickable(ticketclosebutton);
		ticketclosebutton.click();

		boolean flag = base.waitForElementToBeGone(createticketsection, 15);
		if (flag) {
			base.passedStep("Element is not present");
		} else {
			base.failedStep("Element is present");

		}
		base.passedStep("Ticket section is closed and not displayed");
		sa.assertAll();
	}

	public void validateSuggestedOptions_ProductPage(String producttext, String expproductsubtext) throws Exception {
		SoftAssert sa = new SoftAssert();
		base.waitForElementToBeVisible(producticon, 15);
		base.stepInfo("Verify product section is displayed for suggested options");
		sa.assertTrue(producticon.isDisplayed());
		base.passedStep("Product icon is displayed as expected");
		sa.assertEquals(productheadertext.getText().toString(), producttext);
		base.passedStep("Product heading text is displayed as expected-->" + productheadertext.getText());

		sa.assertEquals(productsubtext.getText(), expproductsubtext);
		base.passedStep("Product sub heading text is displayed as expected-->" + productsubtext.getText());

		base.stepInfo("Click on product heading");

		productheadertext.click();
		base.waitForElementToBeVisible(gamepage, 10);
		sa.assertEquals(GamesList.CODWarzone2.toString().toUpperCase(), gamepage.getText());
		base.passedStep("User is redirected to product page");
		sa.assertAll();
	}

	public void validateSuggestedOptions_OnlineServices(String Onlineheader, String exponlinesubtext) throws Exception {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Verify Online Services section is displayed for additional options");

		base.waitTillElemetToBeClickable(OnlineServicesicon);
		sa.assertTrue(OnlineServicesicon.isDisplayed());
		base.passedStep("Online Services icon is displayed as expected");
		sa.assertEquals(OnlineServicesheadertext.getText(), Onlineheader);
		base.passedStep(
				"Online Services heading text is displayed as expected-->" + OnlineServicesheadertext.getText());

		sa.assertEquals(OnlineServicessubtext.getText(), exponlinesubtext);
		base.passedStep(
				"Online Services sub heading text is displayed as expected-->" + OnlineServicessubtext.getText());

		base.stepInfo("Click on Online Services heading");
		OnlineServicesheadertext.click();

		base.waitForElementToBeVisible(OnlineServicespage, 15);
		sa.assertEquals(OnlineServicespage.getText(), Onlineheader);
		base.passedStep("User is redirected to Online Services page");
		Driver.getDriver().navigate().back();
		Driver.getinstance().waitForPageToBeReady();
		sa.assertAll();
	}

	public void navigateBackToSelection() throws Exception {
		SoftAssert sa = new SoftAssert();
		Driver.getDriver().navigate().back();
		base.waitTillElemetToBeClickable(backtoselections);
		base.passedStep("Support results page is displayed");
		base.stepInfo("Click on back to selection button");
		backtoselections.click();
		base.passedStep("Back to selection button is clicked");
		Driver.getinstance().waitForPageToBeReady();
		sa.assertAll();
	}

	public void validateSuggestedOptions_ReportBug(String article, Localecodes code) throws Exception {
		SoftAssert sa = new SoftAssert();
		base.waitTillElemetToBeClickable(headertext);
		base.stepInfo("Verify header displayed for suggested options");
		sa.assertEquals(headertext.getText(), "We suggest the following option:");
		base.passedStep("Header for the suggested options is displayed as expected-->" + headertext.getText());
		base.stepInfo("Verify first article displayed for suggested options");
		sa.assertEquals(firstarticleblock.getText(), article);
		base.passedStep("First articles block is displayed as expected-->" + firstarticleblock.getText());
		base.stepInfo("Click on first article displayed for suggested options");

		if (article.equals("Appeal a Ban")) {
			String title = base.verifyChildWindowandreturnheader(firstarticleblock, appealheader);
			sa.assertTrue(title.equals("Submit a support ticket to appeal an account penalty."));
		} else if (article.equals("Report a bug in Call of Duty: Warzone 2.0")) {
			String articletitle = base.verifyChildWindowandReturnUrl(firstarticleblock);
			sa.assertTrue(articletitle.contains("https://web.cvent.com/survey/"));
		} else if (article.equals("Activision Account Recovery Request")) {
			String recoverytitle = base.validateAccountRecoveryLink(firstarticleblock, accountrecoveryheader, code);
			sa.assertTrue(recoverytitle.equals(article));
		}
		sa.assertAll();
	}

}

package automationLibrary;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Platform;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Parameters;

import base.BaseClass;
import commonUtilities.Utility;

public class Driver extends BaseClass {

	private static Driver instance;
	WebElement element = null;
	public ChromeOptions options;
	public EdgeOptions edgeoptions;
	public FirefoxOptions firefoxoptions;
	BaseClass base;

	// public static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	public static ThreadLocal<RemoteWebDriver> driver = new ThreadLocal<RemoteWebDriver>();;
	private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(Driver.class);

	public static Driver getinstance() {
		if (instance == null) {
			instance = new Driver();
		}
		return instance;
	}

	public static void Quit() {
		driver.get().quit();
	}

	public static WebDriver getDriver() {
		return driver.get();
	}

	public static void closeDriver() {
		driver.remove();
	}

	@Parameters("browser")
	public void setDriver(String browsername) throws Exception {
		if (browsername.equalsIgnoreCase("chrome")) {
			try {

				options = new ChromeOptions();
				options.addArguments("disable-gpu");
				options.addArguments("chrome.switches", "--disable-extensions");
				options.addArguments("disable-blink-features=AutomationControlled");
				options.addArguments("--disable-dev-shm-usage");
				options.addArguments("--remote-allow-origins=*");
				new DesiredCapabilities();
				options.setCapability(ChromeOptions.CAPABILITY, options);
				driver.set(new RemoteWebDriver(new URL("https://psgrid.kube.activision.com"), options));
				waitForPageToBeReady();
				driver.get().manage().window().maximize();
				System.out.println(
						"Driver intialzed by " + Thread.currentThread().getId() + " with reference as " + driver);
				System.out.println("chrome driver initiated");

			} catch (Exception ex) {
				ex.printStackTrace();
				throw new RuntimeException("couldnt create CHROME driver");
			}
		} else if (browsername.equalsIgnoreCase("edge")) {
			try {

				edgeoptions = new EdgeOptions();
				edgeoptions.addArguments("--start-maximized");
				//edgeoptions.addArguments("--remote-allow-origins=*");
				driver.set(new RemoteWebDriver(new URL("https://psgrid.kube.activision.com"), edgeoptions));
				waitForPageToBeReady();
				driver.get().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.get().manage().window().maximize();
				System.out.println(
						"Driver intialzed by " + Thread.currentThread().getId() + " with reference as " + driver);
				System.out.println("Edge driver initiated");

			} catch (Exception ex) {
				ex.printStackTrace();
				throw new RuntimeException("couldnt create EDGE driver");
			}

		} else if (browsername.equalsIgnoreCase("firefox")) {
			try {

				firefoxoptions = new FirefoxOptions();
				firefoxoptions.addArguments("--disable-gpu");
				firefoxoptions.addArguments("--headless");
				firefoxoptions.addArguments("--no-sandbox");
				driver.set(new RemoteWebDriver(new URL("https://psgrid.kube.activision.com"), firefoxoptions));
				waitForPageToBeReady();
				driver.get().manage().window().maximize();
				System.out.println(
						"Driver intialzed by " + Thread.currentThread().getId() + " with reference as " + driver);
			  System.out.println("Firefox driver initiated");
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new RuntimeException("couldnt create FIREFOX driver");
			}
		
	}
		
	}

	public void setoptionsheadless(String browsertype) {
		if (browsertype.equals("chrome")) {
			options.addArguments("--no-sandbox");
			options.addArguments("--headless");
			options.addArguments("disable-gpu");
			options.addArguments("--disable-dev-shm-usage");
			options.addArguments("window-size=1400,2100");
		} else if (browsertype.equalsIgnoreCase("firefox")) {
			// firefoxoptions.addArguments("--no-sandbox");
			// firefoxoptions.addArguments("--headless");
			// firefoxoptions.addArguments("--disable-gpu");
			// firefoxoptions.addArguments("window-size=1400,2100");

			firefoxoptions.addArguments("--headless");
			firefoxoptions.addArguments("window-size=1920x1080");
			firefoxoptions.addArguments("disable-gpu");
			firefoxoptions.addArguments("--window-position=-32000,-32000");
		} else if (browsertype.equalsIgnoreCase("edge")) {
			edgeoptions.addArguments("--no-sandbox");
			// edgeoptions.addArguments("--headless");
			edgeoptions.addArguments("--disable-gpu");
			edgeoptions.addArguments("window-size=1400,2100");
			// edgeoptions.setPageLoadStrategy(PageLoadStrategy.NONE);
		}

	}

	public void WaitUntil(Callable<Boolean> condition, int timeout) {

		long startingTime = System.currentTimeMillis();
		boolean running = true;
		Thread thread = Thread.currentThread();
		while (running) {
			ExecutorService executor = Executors.newFixedThreadPool(1);
			try {
				Future<Boolean> future = executor.submit(condition);
				if (future.get())
					return;
			} catch (Exception e) {
				// e.printStackTrace();
			}

			if ((System.currentTimeMillis() - startingTime) > timeout) {
				running = false;
			} else {
				try {
					thread.join(90000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			executor.shutdown();
		}

	}

	public void scrollingToElementofAPage(WebElement element) {
		try {

			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			e.getLocalizedMessage();
			e.printStackTrace();
		}
	}

	public void waitForPageToBeReady() {
		JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
		// This loop will rotate for 100 times to check If page Is ready after every 1
		// second.
		for (int i = 0; i < 30; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
			// To check page ready state.

			if (js.executeScript("return document.readyState").toString().equals("complete")) {
				// Add_Log.info("Page load is complete");
				break;
			}
		}
	}

	public void scrollingToBottomofAPage() {

		try {
			((JavascriptExecutor) driver.get()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Thread.sleep(500);
		} catch (Exception e) {
			System.out.println("IGNORE" + e.getLocalizedMessage());
		}
	}

	public void scrollPageToTop() {
		// Scroll page to make element visisble.

		for (int i = 0; i < 5; i++) {
			try {
				((JavascriptExecutor) driver.get()).executeScript("window.scrollTo(document.body.scrollHeight, 0)");
				Thread.sleep(500);
			} catch (Throwable e) {
				System.out.println("IGNORE" + e.getLocalizedMessage() + e.getMessage());
				e.printStackTrace();
			}
		}
	}

	public void waitForElement(final WebElement element) {
		try {
			WaitUntil((new Callable<Boolean>() {
				public Boolean call() {
					return element.isDisplayed() && element.isEnabled();
				}
			}), 10000);
		} catch (Exception e) {
			Utility.info("Got exception while waiting for element");
			e.printStackTrace();
		}
	}

	public void waitTime(int sec) {
		try {
			Thread.sleep(sec * 1000);
		} catch (InterruptedException e) {
			Utility.info("");
		}
	}

	public void waitAndClick(WebElement ele, int waitTime) {

		boolean clicked = false;
		for (int i = 1; i < waitTime; i++) {
			try {
				ele.click();
				break;
			}

			catch (Exception e) {
				waitTime(1);
			}
		}
	}

	/**
	 * @author Shilpi Mangal
	 * @param text
	 * @Description entering text in any textbox field
	 */
	public void sendkeyswebelement(WebElement element, String text) {
		waitForElement(element);
		element.click();
		element.clear();
		element.sendKeys(text);
	}

	/**
	 * @author Shilpi Mangal
	 * @param text
	 * @Description selecting any value from drop down field
	 */
	public void selectDropdown(WebElement element, String text) {
		try {
			Select select = new Select(element);
			waitForElement(element);
			select.selectByVisibleText(text);
			base.stepInfo("Text" + text + "is selected from drop down element" + element);
		} catch (Exception e) {
			Utility.info(element + "is not present or text " + text + "is not selected");
		}
	}

	public void implicitWait(int timeOut) {
		driver.get().manage().timeouts().implicitlyWait(timeOut, TimeUnit.SECONDS);
	}

	public Boolean isElementAvailable(WebElement ele, int timeOut) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		implicitWait(0);
		for (int iteration = 1; iteration <= timeOut; iteration++) {
			try {
				ele.isDisplayed();
				implicitWait(30);
				return true;
			} catch (StaleElementReferenceException E) {
				waitTime(1);
				if (iteration == timeOut) {
					E.printStackTrace(pw);
					Utility.info(sw.toString());
				} else {
					continue;
				}
			} catch (NoSuchElementException E) {
				waitTime(1);
				if (iteration == timeOut) {
					E.printStackTrace(pw);
					Utility.info(sw.toString());
				} else {
					continue;
				}
			} catch (WebDriverException E) {
				waitTime(1);
				if (iteration == timeOut) {
					E.printStackTrace(pw);
					Utility.info(sw.toString());
				} else {
					continue;
				}
			}
		}
		implicitWait(30);
		return false;

	}

	/// <summary>
	/// Amount of time to wait for an element to become present.
	/// </summary>
	public double getApplicationTimeout() {
		return 60000;
		// configuration.Timeout;
	}

	/// <summary>
	/// Interval to check if an element becomes available.
	/// </summary>
	public double getApplicationPollingInterval() {
		return 1000;
		// configuration.TimeoutPollingInterval;
	}

	private void AssertExists() throws InterruptedException {

		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		implicitWait(0);
		for (int i = 0; i <= 30; i++) {
			try {
				// element = driver.get().findElement(by);
				implicitWait(30);
				break;
			} catch (StaleElementReferenceException E) {
				base.wait(1);
				if (i == 30) {
					E.printStackTrace(pw);
					base.failedStep(sw.toString());
				} else {
					continue;
				}
			} catch (NoSuchElementException E) {
				base.wait(1);
				if (i == 30) {
					E.printStackTrace(pw);
					base.failedStep(sw.toString());
				} else {
					continue;
				}
			} catch (WebDriverException E) {
				base.wait(1);
				if (i == 30) {
					E.printStackTrace(pw);
					base.failedStep(sw.toString());
				} else {
					continue;
				}

			}
			implicitWait(30);
		}
	}

	public void waitAndClick(int waitTime) throws InterruptedException {

		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		AssertExists();

		boolean clicked = false;
		for (int i = 1; i < waitTime; i++) {
			try {
				element.click();
				break;
			}

			catch (Exception e) {
				base.wait(1);
				e.printStackTrace(pw);
				Utility.info(sw.toString());
			}
		}

	}
}

package commonUtilities;

import org.apache.commons.lang3.time.StopWatch;
import org.testng.Reporter;

public class Stopwatchtime extends StopWatch {
	static StopWatch stopwatch = new StopWatch();

	public static void timetaken() {
		long x = stopwatch.getTime();
// Convert the result to a string
		String numberAsString = Long.toString(x);
		System.out.println("Execution time for this method- " + numberAsString);
		Reporter.log("Time taken to execute this method- " + numberAsString);
	}

	public static void start(String methodname) {
		stopwatch.start();
		Reporter.log(methodname);
	}

	public static void stop(String methodname) {
		stopwatch.stop();
		Reporter.log(methodname);
	}

	public static void reset(String methodname) {
		stopwatch.reset();
		Reporter.log(methodname);
	}

}
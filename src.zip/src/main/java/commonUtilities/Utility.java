package commonUtilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class Utility {
	WebDriver driver;
	static Logger log = LogManager.getLogger("devpinoyLogger");
	public static String GamesTestData = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "TestData-GamesPage.xlsx";
	public static String GamesArticlesfilePath = System.getProperty("user.dir") + File.separator + "src"
			+ File.separator + "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "ArticlesData.xlsx";
	public static String ProductArticlesChivalry = System.getProperty("user.dir") + File.separator + "src"
			+ File.separator + "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "Product-Articles Chivalry Medieval.xlsx";
	public static String GamesHomePagefilePath = System.getProperty("user.dir") + File.separator + "src"
			+ File.separator + "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "TestData-GamesPage-HeaderLinkOptions.xlsx";
	public static String GamesSorting = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "TestData-GamesSorting.xlsx";
	public static String HomePagefooterlinks = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "Home Page- FooterLinks.xlsx";
	public static String HomePagefooterlinksUAT = System.getProperty("user.dir") + File.separator + "src"
			+ File.separator + "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "Home Page- FooterLinks-UAT.xlsx";

	public static String HomePageheaderlinks = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "HomePage-HeaderLinks.xlsx";
	public static String HomePageSearch = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "Home Page -Search Results.xlsx";
	public static String HomePageGames = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "HomePage-Games.xlsx";
	public static String HomePageGamesUAT = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "HomePage-Games- UAT.xlsx";

	public static String HomePageCarouselGames = System.getProperty("user.dir") + File.separator + "src"
			+ File.separator + "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "Home Page - Carousel Banner_TestData.xlsx";
	public static String OnlineServices = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "OnlineServices.xlsx";
	public static String OnlineServicesAllData = System.getProperty("user.dir") + File.separator + "src"
			+ File.separator + "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "OnlineServices-AllTestData.xlsx";
	public static String OnlineServicesGamesData = System.getProperty("user.dir") + File.separator + "src"
			+ File.separator + "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "Online Services - GamesTest data.xlsx";
	public static String OnlineServicesTips = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "Online Services - ConnectionTips.xlsx";
	public static String SupportOptions = System.getProperty("user.dir") + File.separator + "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "SupportOptions_TestData.xlsx";
	public static String SupportOptionsWarzone2 = System.getProperty("user.dir") + File.separator + "src"
			+ File.separator + "main" + File.separator + "java" + File.separator + "configurations" + File.separator
			+ "SupportOptionsData\\SupportOptions_CALL OF DUTY WARZONE 2.0.xlsx";

	public Utility(WebDriver driver) {

		this.driver = driver;
		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
	}

	public static int dynamicNameAppender() {
		Random random = new Random();
		return random.nextInt(1000000);

	}

	public static void logafter(String methodName) {

		log.info("XXXXXXXXXXXXXXXXXXXXXXX   " + "-E---N---D-" + "  " + methodName + "  XXXXXXXXXXXXXXXXXXXXXX");

	}

	public static void info(String message) {

		log.info(message);

	}

	public static void info(Date parse) {

		log.info(parse);
	}

	public static void info(boolean add) {

		log.info(add);
	}

	public static void info(String[] listarray) {

		log.info(listarray);
	}

	public static void info(List<WebElement> values) {
		log.info(values);
	}

	public static void info(int length) {

		log.info(length);
	}

	public static String randomCharacterAppender(int num) {

		String Alphabet = RandomStringUtils.randomAlphabetic(num);
		// System.out.println(Alphabet);
		return Alphabet;
	}

	public void screenShot(ITestResult result) {
		// if(screenShotOnFail.equalsIgnoreCase("YES"))
		try {
			// To create reference of TakesScreenshot
			TakesScreenshot screenshot = (TakesScreenshot) driver;
			// Call method to capture screenshot
			File src = screenshot.getScreenshotAs(OutputType.FILE);
			String name[] = result.getMethod().toString().replace(".", "--").split("\\(");

			File destFile = new File(System.getProperty("user.dir") + "/Screenshots/" + name[0]
					+ Utility.dynamicNameAppender() + ".png");

			// result.getName() will return name of test case so that screenshot name will
			// be same as test case name
			FileUtils.copyFile(src, destFile);
			System.out.println("Successfully captured a screenshot");
			// Reporter.log(path);
			Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath()
					+ "' height='50' width='50'/> </a>");
			// Reporter.log("<br><img src='"+path+"'height='300' width=’300’/><br>");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception while taking screenshot " + e.getMessage());
		}
	}

	@DataProvider(name = "readexcelbyname")
	public synchronized static String[][] readExcelbyname(Method m) throws IOException, InvalidFormatException {
		Workbook wb = null;
		Sheet sheet = null;
		String excelsheetname = m.getName();
		File file = new File(Utility.OnlineServices);
		FileInputStream fis = new FileInputStream(file);
		wb = WorkbookFactory.create(fis);

		// wb = WorkbookFactory.create(new FileInputStream());

		sheet = wb.getSheet(excelsheetname);
		String testdata[][] = new String[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];

		for (int i = 0; i < sheet.getLastRowNum(); i++) {

			for (int j = 0; j < sheet.getRow(0).getLastCellNum(); j++) {

				testdata[i][j] = new DataFormatter().formatCellValue(sheet.getRow(i + 1).getCell(j));

				System.out.println(testdata[i][j]);
			}

			fis.close();
			wb.close();
		}
		return testdata;
	}
	
	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}
	
	@DataProvider(name = "readfirstsheetsfromExcel")
	public static Object[][] readfirstsheetsfromExcel() throws IOException, InvalidFormatException {

		Workbook wb = null;
		Sheet sheet = null;
		File file = new File(Utility.GamesSorting);
		FileInputStream fis = new FileInputStream(file);
		wb = WorkbookFactory.create(fis);

		sheet = wb.getSheetAt(0);

		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];

		for (int i = 0; i < sheet.getLastRowNum(); i++) {

			for (int j = 0; j < sheet.getRow(0).getLastCellNum(); j++) {

				data[i][j] = new DataFormatter().formatCellValue(sheet.getRow(i + 1).getCell(j));
				System.out.println(data[i][j]);
			}
			fis.close();
			wb.close();
		}

		return data;

	}

	public static int randomnumberAppender() {

		// Random rand = new Random();
		int random = (int) (Math.random() * 50 + 1);
		System.out.println(random);
		return random;
	}

}
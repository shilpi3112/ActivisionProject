package commonUtilities;

import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestNGMethod;
import org.testng.log4testng.Logger;

public class TestCount implements ISuiteListener,IInvokedMethodListener {
	
	private static final Logger LOG = Logger.getLogger(TestCount.class);
	private int totaltestcount =0;
	private int totaltestcountwithbrowser =0;
	
	@Override
    public void onStart(ISuite suite) {
    	totaltestcount = 0;
        for (ITestNGMethod method : suite.getAllMethods()) {
            if (method.isTest()) {
            	totaltestcount++;
            }
         
        }
        System.out.println("Total test cases count for this script is: " + totaltestcount);
        LOG.info("Total test cases count for this script is: " + totaltestcount);
        try {
        	int browsercount=0;
        	String params = System.getProperty("browser");
    		String[] paramArray = params.split(",");

    		browsercount = paramArray.length;
    		  System.out.println("Total browser count for this script is: " + browsercount);
    	      LOG.info("Total browser count for this script is: " + browsercount);
    	      
    	      totaltestcountwithbrowser  = totaltestcount*browsercount;
    		
			WebUtility.updateTotalCount(totaltestcountwithbrowser);
		} catch (Exception e) {
			System.out.println("Unable to update total test count");
			e.printStackTrace();
		}
	     System.out.println("Total test cases count for all the browsersin this script is: " + totaltestcountwithbrowser);
        LOG.info("Total test cases count for all the browsers in this script is: " + totaltestcountwithbrowser);
    }

	@Override
     public void onFinish(ISuite suite) {
	}
    
}



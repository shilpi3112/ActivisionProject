package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.SupportHomePage;

public class HomePageHeaderLinks extends BaseClass {

	BaseClass base;
	SupportHomePage hp;
	GamesPage ghp;

	@BeforeClass(alwaysRun = true)
	public void preCondition() throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		Reporter.setCurrentTestResult(result);
		base.stepInfo("Navigate to Games Home page");
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}

	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforDE(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Deutschland);
		hp.verifyCarouselAlert(Locales.Deutschland);
		hp.ValidateGamesLinkOnHomepage(Localecodes.de);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.de);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.de);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		// Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Deutschland);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Deutschland);
		hp.ValidateLoginLinkOnHomepage(Localecodes.de);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforUS(String browser) throws Exception {
		// ghp.selectRegionByName(Locales.US);
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.ValidateGamesLinkOnHomepage(Localecodes.en);
		hp.verifyCarouselAlert(Locales.US);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.en);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.en);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		hp.ValidateLoginLinkOnHomepage(Localecodes.en);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforAustralia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Australia);
		hp.verifyCarouselAlert(Locales.Australia);
		hp.ValidateGamesLinkOnHomepage(Localecodes.en_au);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.en_au);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.en_au);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Australia);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
	//	Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Australia);
		hp.ValidateLoginLinkOnHomepage(Localecodes.en_au);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforUK(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.UK);
		hp.verifyCarouselAlert(Locales.UK);
		hp.ValidateGamesLinkOnHomepage(Localecodes.en_gb);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.en_gb);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.en_gb);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.UK);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.UK);
		hp.ValidateLoginLinkOnHomepage(Localecodes.en_gb);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforEspaña(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.España);
		hp.verifyCarouselAlert(Locales.España);
		hp.ValidateGamesLinkOnHomepage(Localecodes.es);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.es);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.es);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.España);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		// Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.España);
		hp.ValidateLoginLinkOnHomepage(Localecodes.es);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforSuomi(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Suomi);
		hp.verifyCarouselAlert(Locales.Suomi);
		hp.ValidateGamesLinkOnHomepage(Localecodes.fi);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.fi);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.fi);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Suomi);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Suomi);
		hp.ValidateLoginLinkOnHomepage(Localecodes.fi);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforFrance(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.France);
		hp.verifyCarouselAlert(Locales.France);
		hp.ValidateGamesLinkOnHomepage(Localecodes.fr);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.fr);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.fr);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.France);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.France);
		hp.ValidateLoginLinkOnHomepage(Localecodes.fr);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforBEFR(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.BEFR);
		hp.verifyCarouselAlert(Locales.BEFR);
		hp.ValidateGamesLinkOnHomepage(Localecodes.fr_be);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.fr_be);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.fr_be);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.BEFR);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.BEFR);
		hp.ValidateLoginLinkOnHomepage(Localecodes.fr_be);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforLuxembourg(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Luxembourg);
		hp.verifyCarouselAlert(Locales.Luxembourg);
		hp.ValidateGamesLinkOnHomepage(Localecodes.fr_lu);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.fr_lu);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.fr_lu);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Luxembourg);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Luxembourg);
		hp.ValidateLoginLinkOnHomepage(Localecodes.fr_lu);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforItalia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Italia);
		hp.verifyCarouselAlert(Locales.Italia);
		hp.ValidateGamesLinkOnHomepage(Localecodes.it);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.it);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.it);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Italia);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Italia);
		hp.ValidateLoginLinkOnHomepage(Localecodes.it);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforJapan(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Ja);
		hp.verifyCarouselAlert(Locales.Ja);
		hp.ValidateGamesLinkOnHomepage(Localecodes.ja);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.ja);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.ja);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		// Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Ja);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		// Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Ja);
		hp.ValidateLoginLinkOnHomepage(Localecodes.ja);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforKorea(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Ko);
		hp.verifyCarouselAlert(Locales.Ko);
		hp.ValidateGamesLinkOnHomepage(Localecodes.ko);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.ko);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.ko);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Ko);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Ko);
		hp.ValidateLoginLinkOnHomepage(Localecodes.ko);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforNorge(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Norge);
		hp.verifyCarouselAlert(Locales.Norge);
		hp.ValidateGamesLinkOnHomepage(Localecodes.no);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.no);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.no);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Norge);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Norge);
		hp.ValidateLoginLinkOnHomepage(Localecodes.no);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforBrasil(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Brasil);
		hp.verifyCarouselAlert(Locales.Brasil);
		hp.ValidateGamesLinkOnHomepage(Localecodes.pt_br);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.pt_br);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.pt_br);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Brasil);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Brasil);
		hp.ValidateLoginLinkOnHomepage(Localecodes.pt_br);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforCNZH(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.CN);
		hp.verifyCarouselAlert(Locales.CN);
		hp.ValidateGamesLinkOnHomepage(Localecodes.zh_cn);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.zh_cn);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.zh_cn);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.CN);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.CN);
		hp.ValidateLoginLinkOnHomepage(Localecodes.zh_cn);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforTwZh(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.TwZh);
		hp.verifyCarouselAlert(Locales.TwZh);
		hp.ValidateGamesLinkOnHomepage(Localecodes.zh_tw);
		hp.ValidateOnlineServicesLinkOnHomepage(Localecodes.zh_tw);
		hp.ValidateSupportOptionsLinkOnHomepage(Localecodes.zh_tw);
		hp.ValidateMyCasesLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.TwZh);
		hp.ValidateSignUpLinkOnHomepage();
		base.switchToNewWindow(hp.SSOSupportlink);
		//Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.TwZh);
		hp.ValidateLoginLinkOnHomepage(Localecodes.zh_tw);
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (AssertionError e1) {

			throw e1;
		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
		}
	}

}

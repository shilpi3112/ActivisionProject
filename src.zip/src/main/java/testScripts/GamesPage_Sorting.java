package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.ProductPage;

public class GamesPage_Sorting extends BaseClass {

	BaseClass base;
	GamesPage ghp;
	ProductPage gamesproductpage;

	@BeforeClass(alwaysRun = true)
	private void TestStart() throws Exception, InterruptedException, IOException {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("Executing method : " + testMethod.getName());
		base.stepInfo("Navigate to Games page to validate Sorting");
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforSuomi(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Suomi);
		ghp.ValidateSortDropdown("All EN except Australia");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforNorge(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Norge);
		ghp.ValidateSortDropdown("All EN except Australia");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforAustralia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Australia);
		ghp.ValidateSortDropdown("EN - Australia");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforUK(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.UK);
		ghp.ValidateSortDropdown("All EN except Australia");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforUS(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.ValidateSortDropdown("All EN except Australia");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforSpanish(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.España);
		ghp.ValidateSortDropdown("Spanish");
	}

	@Test(dataProvider = "testData")
	public void ValidatearticlesforGerman(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Deutschland);
		ghp.ValidateSortDropdown("German");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforLu(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Luxembourg);
		ghp.ValidateSortDropdown("All French");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforBEFR(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.BEFR);
		ghp.ValidateSortDropdown("All French");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforFr(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.France);
		ghp.ValidateSortDropdown("All French");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforItalian(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Italia);
		ghp.ValidateSortDropdown("Italian");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforPortuguese(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Brasil);
		ghp.ValidateSortDropdown("Portuguese");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforJapanese(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Ja);
		ghp.ValidateSortDropdown("Japanese");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforSimplifiedChinese(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.CN);
		ghp.ValidateSortDropdown("Simplified Chinese");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforTraditionalChinese(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.TwZh);
		ghp.ValidateSortDropdown("Traditional Chinese");
	}

	@Test(dataProvider = "testData")
	public void ValidatSortingforKorean(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		ghp.selectRegionByName(Locales.Ko);
		ghp.ValidateSortDropdown("Korean");
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}

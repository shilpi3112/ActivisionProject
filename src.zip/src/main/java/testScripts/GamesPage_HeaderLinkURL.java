package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.ProductPage;
import pageFactory.SupportHomePage;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Constants.Locales;

public class GamesPage_HeaderLinkURL extends BaseClass {

	BaseClass base;
	GamesPage Gamespage;
	ProductPage gamesproductpage;

	@BeforeClass(alwaysRun = true)
	public void preCondition() throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		Reporter.setCurrentTestResult(result);
		base.stepInfo("Navigate to Games page and validate Games URL, Header and product options");
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforDeutschland(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Deutschland);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Deutschland.toString(), Localecodes.de,
				Locales.Deutschland);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforSuomi(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Suomi);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Suomi.toString(), Localecodes.fi, Locales.Suomi);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforNorge(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Norge);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Norge.toString(), Localecodes.no, Locales.Norge);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforAustralia(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Australia);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Australia.toString(), Localecodes.en_au,
				Locales.Australia);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforUnitedKingdom(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.UK);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.UK.toString(), Localecodes.en_gb, Locales.UK);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforUnitedStates(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.US);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.US.toString(), Localecodes.en, Locales.US);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforEspaña(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.España);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.España.toString(), Localecodes.es, Locales.España);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforLuxembourg(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Luxembourg);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Luxembourg.toString(), Localecodes.fr_lu,
				Locales.Luxembourg);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforBelgiumFrançais(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.BEFR);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.BEFR.toString(), Localecodes.fr_be, Locales.BEFR);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforFrance(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.France);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.France.toString(), Localecodes.fr, Locales.France);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforItalia(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Italia);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Italia.toString(), Localecodes.it, Locales.Italia);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforBrasil(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Brasil);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Brasil.toString(), Localecodes.pt_br, Locales.Brasil);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforJapan(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Ja);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Ja.toString(), Localecodes.ja, Locales.Ja);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforChinese(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.CN);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.CN.toString(), Localecodes.zh_cn, Locales.CN);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforKorea(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.Ko);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.Ko.toString(), Localecodes.ko, Locales.Ko);
	}

	@Test(dataProvider = "testData")
	public void ValidateGamesHeaderLinkandURLforzhtw(String browser) throws Exception {
		base.applicationlaunch(browser);
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
		Gamespage.selectRegionByName(Locales.TwZh);
		gamesproductpage.validateHeaderLinkURLForAllGames(Locales.TwZh.toString(), Localecodes.zh_tw, Locales.TwZh);
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}

package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.stream.Stream;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.OnlineServicesHomePage;
import pageFactory.ProductPage;
import pageFactory.SupportHomePage;

public class OnlineServices_PlatformStatus extends BaseClass {

	BaseClass base;
	SupportHomePage hp;
	GamesPage ghp;
	ProductPage gpp;
	OnlineServicesHomePage onlinehp;

	@BeforeClass(alwaysRun = true)
	public void preCondition() throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
	
	}

	@Test(dataProvider = "testData")
	public void RumbleCrossplayData(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		onlinehp = new OnlineServicesHomePage();
		onlinehp.triggerEmailDefcon1("Rumble Crossplay - Live (CrossPlay)");
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.US,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.España,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.France,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko,"RumbleCrossplayData");
		onlinehp.triggerEmailDefcon2("Rumble Crossplay - Live (CrossPlay)");
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.US,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.España,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.France,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh,"RumbleCrossplayData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko,"RumbleCrossplayData");

	}

	@Test(dataProvider = "testData")
	public void Warzone2Data(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		onlinehp = new OnlineServicesHomePage();
		onlinehp.triggerEmailDefcon1("Call of Duty: Cortez (IW9) - Live (CrossPlay)");
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.US,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.España,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.France,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko,"Warzone2Data");
		onlinehp.triggerEmailDefcon2("Call of Duty: Cortez (IW9) - Live (CrossPlay)");
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.US,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.España,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.France,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh,"Warzone2Data");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko,"Warzone2Data");
	}

	@Test(dataProvider = "testData")
	public void CODVanguardData(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		onlinehp = new OnlineServicesHomePage();
		onlinehp.triggerEmailDefcon1("Call of Duty: Vanguard (S4) - Live (CrossPlay)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK,"CODVanguardData");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland,"CODVanguardData");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi,"CODVanguardData");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge,"CODVanguardData");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia,"CODVanguardData");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US,"CODVanguardData");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg,"CODVanguardData");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR,"CODVanguardData");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France,"CODVanguardData");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia,"CODVanguardData");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil,"CODVanguardData");
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja,"CODVanguardData");
		ghp.selectRegionByName(Locales.CN);
		onlinehp.verifyPlatformStatus(Locales.CN,"CODVanguardData");
		ghp.selectRegionByName(Locales.TwZh);
		onlinehp.verifyPlatformStatus(Locales.TwZh,"CODVanguardData");
		ghp.selectRegionByName(Locales.Ko);
		onlinehp.verifyPlatformStatus(Locales.Ko,"CODVanguardData");
		onlinehp.triggerEmailDefcon2("Call of Duty: Vanguard (S4) - Live (CrossPlay)");
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.US,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.España,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.France,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh,"CODVanguardData");
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko,"CODVanguardData");
	}

	@Test(dataProvider = "testData")
	public void CODColdWar(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		onlinehp = new OnlineServicesHomePage();
		onlinehp.triggerEmailDefcon1("Call of Duty: Black Ops 5 - Live (CrossPlay)");

		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "CODColdWar");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "CODColdWar");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "CODColdWar");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "CODColdWar");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "CODColdWar");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "CODColdWar");
		ghp.selectRegionByName(Locales.España);
		onlinehp.verifyPlatformStatus(Locales.España, "CODColdWar");
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "CODColdWar");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "CODColdWar");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "CODColdWar");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "CODColdWar");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "CODColdWar");
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, "CODColdWar");
		ghp.selectRegionByName(Locales.CN);
		onlinehp.verifyPlatformStatus(Locales.CN, "CODColdWar");
		ghp.selectRegionByName(Locales.TwZh);
		onlinehp.verifyPlatformStatus(Locales.TwZh, "CODColdWar");
		ghp.selectRegionByName(Locales.Ko);
		onlinehp.verifyPlatformStatus(Locales.Ko, "CODColdWar");
		onlinehp.triggerEmailDefcon2("Call of Duty: Black Ops 5 - Live (CrossPlay)");

		onlinehp.verifyPlatformStatus(Locales.Ko, "CODColdWar");
		onlinehp.triggerEmailDefcon3("Call of Duty: Black Ops 5 - Live (CrossPlay)");
		onlinehp.verifyPlatformStatus(Locales.Ko, "CODColdWar");
		onlinehp.triggerEmailDefcon4("Call of Duty: Black Ops 5 - Live (CrossPlay)");
		onlinehp.verifyPlatformStatus(Locales.Ko, "CODColdWar");
		onlinehp.triggerEmailDefcon5("Call of Duty: Black Ops 5 - Live (CrossPlay)");
		onlinehp.verifyPlatformStatus(Locales.Ko, "CODColdWar");
		onlinehp.triggerEmailFinalIncident("Call of Duty: Black Ops 5 - Live (CrossPlay)");

		onlinehp.verifyPlatformStatus(Locales.Ko, "CODColdWar");
	}

	@Test(dataProvider = "testData")
	public void WarzoneCaldera(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		onlinehp = new OnlineServicesHomePage();
		onlinehp.triggerEmailDefcon1("Call of Duty: Warzone - Live (CrossPlay)");

		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "WarzoneCaldera"); 
		ghp.selectRegionByName(Locales.España); 
		onlinehp.verifyPlatformStatus(Locales.España, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.CN);
		onlinehp.verifyPlatformStatus(Locales.CN, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.TwZh);
		onlinehp.verifyPlatformStatus(Locales.TwZh, "WarzoneCaldera");
		ghp.selectRegionByName(Locales.Ko);
		onlinehp.verifyPlatformStatus(Locales.Ko, "WarzoneCaldera");

		onlinehp.triggerEmailDefcon2("Call of Duty: Warzone - Live (CrossPlay)");
		onlinehp.verifyPlatformStatus(Locales.Ko, "WarzoneCaldera");
		onlinehp.triggerEmailDefcon3("Call of Duty: Warzone - Live (CrossPlay)");
		onlinehp.verifyPlatformStatus(Locales.Ko, "WarzoneCaldera");
		onlinehp.triggerEmailDefcon4("Call of Duty: Warzone - Live (CrossPlay)");
		onlinehp.verifyPlatformStatus(Locales.Ko, "WarzoneCaldera");
		onlinehp.triggerEmailDefcon5("Call of Duty: Warzone - Live (CrossPlay)");
		onlinehp.verifyPlatformStatus(Locales.Ko, "WarzoneCaldera");
		onlinehp.triggerEmailFinalIncident("Call of Duty: Warzone - Live (CrossPlay)");
		onlinehp.verifyPlatformStatus(Locales.Ko, "WarzoneCaldera");
	}

	@Test(dataProvider = "testData")
	public void TonyHawk(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		onlinehp = new OnlineServicesHomePage();
		onlinehp.triggerEmailDefcon1("Tony Hawk's Pro Skater 1 + 2 - Live (Xbox One)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "TonyHawk");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "TonyHawk");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "TonyHawk");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "TonyHawk");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "TonyHawk");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "TonyHawk");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "TonyHawk");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "TonyHawk");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "TonyHawk");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "TonyHawk");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "TonyHawk");
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, "TonyHawk");

		ghp.selectRegionByName(Locales.CN);
		onlinehp.verifyPlatformStatus(Locales.CN, "TonyHawk");
		ghp.selectRegionByName(Locales.TwZh);
		onlinehp.verifyPlatformStatus(Locales.TwZh, "TonyHawk");
		ghp.selectRegionByName(Locales.Ko);
		onlinehp.verifyPlatformStatus(Locales.Ko, "TonyHawk");

		onlinehp.triggerEmailDefcon2("Tony Hawk's Pro Skater 1 + 2 - Live (Xbox One)");

		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "TonyHawk");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "TonyHawk");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "TonyHawk");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "TonyHawk");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "TonyHawk");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "TonyHawk");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "TonyHawk");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "TonyHawk");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "TonyHawk");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "TonyHawk");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "TonyHawk");
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, "TonyHawk");

		onlinehp.triggerEmailDefcon3("Tony Hawk's Pro Skater 1 + 2 - Live (Xbox One)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "TonyHawk");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "TonyHawk");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "TonyHawk");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "TonyHawk");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "TonyHawk");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "TonyHawk");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "TonyHawk");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "TonyHawk");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "TonyHawk");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "TonyHawk");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "TonyHawk");
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, "TonyHawk");

		onlinehp.triggerEmailDefcon4("Tony Hawk's Pro Skater 1 + 2 - Live (Xbox One)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "TonyHawk");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "TonyHawk");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "TonyHawk");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "TonyHawk");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "TonyHawk");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "TonyHawk");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "TonyHawk");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "TonyHawk");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "TonyHawk");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "TonyHawk");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "TonyHawk");
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, "TonyHawk");

		onlinehp.triggerEmailDefcon5("Tony Hawk's Pro Skater 1 + 2 - Live (Xbox One)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "TonyHawk");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "TonyHawk");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "TonyHawk");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "TonyHawk");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "TonyHawk");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "TonyHawk");
		ghp.selectRegionByName(Locales.España);
		onlinehp.verifyPlatformStatus(Locales.España, "TonyHawk");
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "TonyHawk");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "TonyHawk");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "TonyHawk");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "TonyHawk");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "TonyHawk");
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, "TonyHawk");

		onlinehp.triggerEmailFinalIncident("Tony Hawk's Pro Skater 1 + 2 - Live (Xbox One)");
		onlinehp.verifyPlatformStatus(Locales.UK, "TonyHawk");
	}

	@Test(dataProvider = "testData")
	public void SkylanderSupercharger(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		onlinehp = new OnlineServicesHomePage();
		onlinehp.triggerEmailDefcon1("Skylanders Superchargers  - Live (PS4)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "SkylanderSupercharger");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "SkylanderSupercharger");

		onlinehp.triggerEmailDefcon2("Skylanders Superchargers  - Live (PS4)");

		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "SkylanderSupercharger");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "SkylanderSupercharger");

		onlinehp.triggerEmailDefcon3("Skylanders Superchargers  - Live (PS4)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "SkylanderSupercharger");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "SkylanderSupercharger");

		onlinehp.triggerEmailDefcon4("Skylanders Superchargers  - Live (PS4)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "SkylanderSupercharger");
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España
		// );
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "SkylanderSupercharger");

		onlinehp.triggerEmailDefcon5("Skylanders Superchargers  - Live (PS4)");
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.España);
		onlinehp.verifyPlatformStatus(Locales.España, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, "SkylanderSupercharger");
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, "SkylanderSupercharger");

		onlinehp.triggerEmailFinalIncident("Skylanders Superchargers  - Live (PS4)");
		onlinehp.validateFinalIncidentDetails();
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (AssertionError e1) {
			WebUtility.updateTotalCount(2);
			throw e1;
		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
		}
	}

}

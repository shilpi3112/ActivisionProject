package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.annotations.DataProvider;
import java.text.ParseException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Log;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.SupportHomePage;

public class JenkinsDemo extends BaseClass {

	BaseClass base;
	SupportHomePage hp;
	GamesPage ghp;

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {

		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		Reporter.setCurrentTestResult(result);
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}

	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforUS(ITestResult result, Method testMethod, String parameterValue)
			throws Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		base = new BaseClass();
		base.applicationlaunch(parameterValue);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		base.stepInfo("Navigate to Games Home page");
		Driver.getinstance().waitForPageToBeReady();
		// ghp.selectRegionByName(Locales.US);
		hp.ValidateGamesLinkOnHomepage(Localecodes.en);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforsuomi(ITestResult result, Method testMethod, String parameterValue)
			throws Exception {
		base = new BaseClass();
		base.applicationlaunch(parameterValue);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		base.stepInfo("Navigate to Games Home page");
		Driver.getinstance().waitForPageToBeReady();
		// ghp.selectRegionByName(Locales.US);
		hp.ValidateGamesLinkOnHomepage(Localecodes.en);
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
	
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (AssertionError e1) {

			throw e1;
		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
			Driver.getDriver().quit();
			}
		}
	}

}

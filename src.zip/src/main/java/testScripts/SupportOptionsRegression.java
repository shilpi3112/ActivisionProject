package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.GamesList;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.SupportOptionsHomePage;

public class SupportOptionsRegression extends BaseClass {

	BaseClass base;
	GamesPage gp;
	SupportOptionsHomePage shp;

	@BeforeClass(alwaysRun = true)
	public void preCondition() throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		Reporter.setCurrentTestResult(result);
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}
		base.stepInfo("Navigate to Games page and validate Games URL, Header and product options");
	}

	@Test(dataProvider = "testData")
	public void ValidateCallOfDutyWarzone(String browser) throws Exception {
		base.applicationlaunch(browser);
		gp = new GamesPage();
		shp = new SupportOptionsHomePage();
        gp.selectRegionByName(Locales.UK);
		shp.selectGame(GamesList.CODWarzone2);
		shp.validatePlatforms(Locales.UK.toString(), Utility.SupportOptionsWarzone2, GamesList.CODWarzone2,
				Localecodes.en_gb);
	}
	
	@Test(dataProvider = "testData")
	public void ValidateCallOfDutyWarzone1(String browser) throws Exception {
		base.applicationlaunch(browser);
		gp = new GamesPage();
		shp = new SupportOptionsHomePage();
        gp.selectRegionByName(Locales.UK);
		shp.selectGame(GamesList.CODWarzone2);
		shp.validatePlatforms(Locales.UK.toString(), Utility.SupportOptionsWarzone2, GamesList.CODWarzone2,
				Localecodes.en_gb);
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}

package commonUtilities;

import org.testng.IInvokedMethodListener;
import org.testng.IInvokedMethod;
import org.testng.ITestResult;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestNGMethod;
import org.testng.log4testng.Logger;

public class CompletedTestCount implements IInvokedMethodListener {
	
	private static final Logger LOG = Logger.getLogger(CompletedTestCount.class);
    private int executedtestcount =0;

	@Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
	    	
    }

    public int getExecutedTestCount()
	{
		return executedtestcount;
	}

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
    	if (method.isTestMethod()) {
    		executedtestcount++;
    	}
    	executedtestcount = getExecutedTestCount();
    	System.out.println("Executed script count is------>"+executedtestcount);
    	

    	 try {
 			WebUtility.updateCompletedCount(executedtestcount);
 		} catch (Exception e) {
 			System.out.println("Unable to update completed test count");
 			e.printStackTrace();
 		}
    }
    
}



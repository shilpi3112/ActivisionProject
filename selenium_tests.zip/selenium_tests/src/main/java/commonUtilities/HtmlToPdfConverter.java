package commonUtilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;

import base.BaseClass;

/**
 * This Class is used to convert TestNG html report into pdf file with running
 * scheduler.
 *
 * @author CSS144503 23/06/2023
 *
 */
public class HtmlToPdfConverter {

	public static void generatePDF(String outputDirectory) {
		final List<String> list = new ArrayList<String>();
		try {

			File htmlFilePath = new File(outputDirectory);
			// loop through the folder and get the names

			File[] htmlFiles = htmlFilePath.listFiles(new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return name.endsWith(".html");
				}
			});
			for (int i = 0; i < htmlFiles.length; i++) {
				if (htmlFiles[i].isFile()) {
					if (list.contains(htmlFiles[i].getName())) {
						// already checked file
						System.out.println("---- already file present ---- " + htmlFiles[i].getName());
					} else {
						// new file add your move logic and add it to the list
						list.add(htmlFiles[i].getName());
						System.out.println("---- New File Created ----- " + list.get(i));
						System.out.println("------------Pdf process Started ------------");
						// this line weeds out other directories/folders
						InputStream inputStream = new FileInputStream(htmlFiles[i]);
						String fileName = htmlFiles[i].getName().replace(".html", "");
						// Setting destination
						FileOutputStream fileOutputStream = new FileOutputStream(
								new File(htmlFilePath + File.separator + fileName + ".pdf"));
						PdfWriter pdfWriter = new PdfWriter(fileOutputStream);
						ConverterProperties converterProperties = new ConverterProperties();
						PdfDocument pdfDocument = new PdfDocument(pdfWriter);
						// For setting the PAGE SIZE
						pdfDocument.setDefaultPageSize(
								new PageSize(Integer.parseInt(BaseClass.ReadProperties("file.width")),
										Integer.parseInt(BaseClass.ReadProperties("file.height"))));
						Document document = HtmlConverter.convertToDocument(inputStream, pdfDocument,
								converterProperties);
						document.close();
						System.out.println(" ------- PDF report generated -------> ");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

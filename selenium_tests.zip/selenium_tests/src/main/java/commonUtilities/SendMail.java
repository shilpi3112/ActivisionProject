package commonUtilities;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {

	public void sendmail1(String subject, String body) throws AddressException, MessagingException {

		// change accordingly
		final String username = "smangal@activision.com";
		// change accordingly
		final String password = "sxhv2GbH74!6";
		// or IP address
		final String host = "smtp-mail.outlook.com";
		// Get system properties
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.ssl.trust", host);
		// enable STARTTLS
		props.put("mail.smtp.starttls.enable", "true");
		// Setup mail server
		props.put("mail.smtp.host", "smtp-mail.outlook.com");

		// TLS Port
		props.put("mail.smtp.port", "587");

		// creating Session instance referenced to
		// Authenticator object to pass in
		// Session.getInstance argument
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {

			// override the getPasswordAuthentication method
			protected PasswordAuthentication getPasswordAuthentication() {

				return new PasswordAuthentication(username, password);
			}
		});

		// try {

		// compose the message
		// javax.mail.internet.MimeMessage class is
		// mostly used for abstraction.
		Message message = new MimeMessage(session);

		// header field of the header.
		message.setFrom(new InternetAddress("smangal@activision.com"));

		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(
				"oshp_email_service@z-1mj3wna1pyf5b4l5fr3buce0ipu302eemehbwzqkb2otq11iuh.7b-h1l3eak.cs190.apex.sandbox.salesforce.com"));
		message.setSubject(subject);
		message.setText(body);

		Transport.send(message); // send Message

		System.out.println("Done");

	}

}

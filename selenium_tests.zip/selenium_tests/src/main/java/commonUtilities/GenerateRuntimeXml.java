package commonUtilities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlSuite.ParallelMode;
import org.testng.xml.XmlTest;

public class GenerateRuntimeXml {

	public static void main(String[] args) {

		TestNG testng = new TestNG();
		List<XmlSuite> suites = new ArrayList<XmlSuite>();
		//Take these browsers and classes values from Global variable
		List<String> browsers = Arrays.asList("chrome", "edge");
		List<String> classes = Arrays.asList("JenkinsDemo", "GamesPage");
	    suites.add(generateSuite(classes, browsers));
		System.out.println(suites.get(0).toXml());
		testng.setXmlSuites(suites);
		testng.run();
	}

	public static XmlSuite generateSuite(List<String> classNames, List<String> browsers) {
		XmlSuite suite = new XmlSuite();
		suite.setName("customGenerate");
		suite.addListener("commonUtilities.TestNGCustomReportListener");
		suite.setParallel(ParallelMode.TESTS);

		for (String browser : browsers) {
			XmlTest test = new XmlTest(suite);
			test.setName(browser + "test");

			Map<String, String> param = new HashMap<>();
			param.put("browsertype", browser);
			test.setParameters(param);

			List<XmlClass> classes = new ArrayList<XmlClass>();

			for (String className : classNames) {
				classes.add(new XmlClass("testScripts." + className));
			}

			test.setXmlClasses(classes);
		}
		return suite;
	}
}

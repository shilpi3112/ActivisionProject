package commonUtilities;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import javax.annotation.Nullable;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;

import com.google.common.net.HttpHeaders;

import base.BaseClass;


public class WebUtility {
	public static HttpClient httpclient= new DefaultHttpClient();

	public static HttpResponse updateOutput(String url, Map<String, String> customHeaders, File file, String json)
			throws ClientProtocolException, IOException {
		HttpClient httpclient = new DefaultHttpClient();
		HttpPut httpPut = new HttpPut(url);
		for (Map.Entry<String, String> entry : customHeaders.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			httpPut.setHeader(key, value);
		}
		FileBody uploadFilePart = new FileBody(file);
		MultipartEntity reqEntity = new MultipartEntity();
		reqEntity.addPart("file", uploadFilePart);
		reqEntity.addPart("json", new StringBody(json));
		httpPut.setEntity(reqEntity);

		HttpResponse response = httpclient.execute(httpPut);
		return response;
	}

	public static String encodeBasicAuth(String username, String password, @Nullable Charset charset) {
		Assert.assertNotNull(username, "Username must not be null");
		Assert.assertNotNull(password, "Password must not be null");
		if (charset == null) {
			charset = StandardCharsets.ISO_8859_1;
		}

		CharsetEncoder encoder = charset.newEncoder();
		if (!encoder.canEncode(username) || !encoder.canEncode(password)) {
			throw new IllegalArgumentException(
					"Username or password contains characters that cannot be encoded to " + charset.displayName());
		}

		String credentialsString = username + ":" + password;
		byte[] encodedBytes = Base64.getEncoder().encode(credentialsString.getBytes(charset));
		return new String(encodedBytes, charset);
	}
	
	public static String getStatus() throws Exception {
        String url =  BaseClass.ReadProperties("backend.url")+ "/api/job/"+System.getProperty("jobId");
     	HttpGet httpget = new HttpGet(url);
    	httpget.setHeader(HttpHeaders.AUTHORIZATION,   "Basic " +WebUtility.encodeBasicAuth(BaseClass.ReadProperties("backend.username"),BaseClass.ReadProperties("backend.password"), null));
    	HttpResponse response = httpclient.execute(httpget);
        String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(responseString);

        return json.get("state").toString();
    }
	
	public static HttpResponse updateTotalCount(int count)
			throws Exception {
		String url =  BaseClass.ReadProperties("backend.url")+ "/api/job/"+System.getProperty("jobId")+ "/total/count/"+count;
		HttpClient httpclient = new DefaultHttpClient();
		HttpPut httpPut = new HttpPut(url);
		httpPut.setHeader(HttpHeaders.AUTHORIZATION,   "Basic " +WebUtility.encodeBasicAuth(BaseClass.ReadProperties("backend.username"),BaseClass.ReadProperties("backend.password"), null));
		HttpResponse response = httpclient.execute(httpPut);
		return response;
	}
	
	public static HttpResponse updateCompletedCount(int count)
			throws Exception {
		String url =  BaseClass.ReadProperties("backend.url")+ "/api/job/"+System.getProperty("jobId")+ "/completed/count/"+count;
		HttpClient httpclient = new DefaultHttpClient();
		HttpPut httpPut = new HttpPut(url);
		httpPut.setHeader(HttpHeaders.AUTHORIZATION,   "Basic " +WebUtility.encodeBasicAuth(BaseClass.ReadProperties("backend.username"),BaseClass.ReadProperties("backend.password"), null));
		HttpResponse response = httpclient.execute(httpPut);
		return response;
	}

}

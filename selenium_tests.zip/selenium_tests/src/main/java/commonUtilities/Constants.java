package commonUtilities;

public class Constants {

	public enum Locales {
		Deutschland("Deutschland"), Suomi("Suomi"), Norge("Norge"), Australia("Australia"), UK("United Kingdom"),
		US("United States"), España("España"), Luxembourg("Luxembourg"), BEFR("Belgium Français"), France("France"),
		Italia("Italia"), Brasil("Brasil"), Ja("日本語"), CN("简体中文"), TwZh("繁體中文"), Ko("한국");

		private final String name;

		Locales(final String name) {
			this.name = name;
		}

		@Override
		public String toString() {
			return name;
		}
	}

	public enum SortOptions {
		NTO("Newest to Oldest"), OTN("Oldest to Newest"), TitleATOZ("Title (A-Z)"), TitleZTOA("Title (Z-A)");

		private final String options;

		SortOptions(final String options) {
			this.options = options;
		}

		@Override
		public String toString() {
			return options;
		}
	}

	public enum Localecodes {
		de("de"), en(""), en_au("au/en"), en_gb("uk/en"), es("es"), fi("fi"), fr("fr"), fr_be("be/fr"), fr_lu("lu/fr"),
		it("it"), ja("ja"), ko("ko"), no("no"), pt_br("br/pt"), zh_cn("cn/zh"), zh_tw("tw/zh");

		private final String codes;

		Localecodes(final String codes) {
			this.codes = codes;
		}

		@Override
		public String toString() {
			return codes;
		}
	}

	public enum GamesList {
		CrashTeam("CRASH TEAM RUMBLE"), WarzoneMobile("CALL OF DUTY: WARZONE MOBILE"),
		CODWarzone2("Call of Duty: Warzone"), CODWarfareII("CALL OF DUTY: MODERN WARFARE II"),
		Vanguard("CALL OF DUTY: VANGUARD"), ColdWar("CALL OF DUTY: BLACK OPS COLD WAR"),
		CrashBandicoot4("CRASH BANDICOOT 4: IT'S ABOUT TIME"), Caldera("CALL OF DUTY: WARZONE CALDERA"),
		ModernWarfare("CALL OF DUTY: MODERN WARFARE"), TonyHawkPro12("TONY HAWK'S PRO SKATER 1 + 2"),
		CODMobile("CALL OF DUTY: MOBILE"), CODWarfareIIRemastered("CALL OF DUTY: MODERN WARFARE 2 REMASTERED"),
		CrashTeamRacing("CRASH TEAM RACING NITRO-FUELED"), Sekiro("SEKIRO: SHADOWS DIE TWICE"),
		Spyro("SPYRO REIGNITED TRILOGY TEST"), CODBlackOps4("CALL OF DUTY: BLACK OPS 4"), CODWWII("CALL OF DUTY: WWII"),
		CrashBandicootTrilogy("CRASH BANDICOOT N. SANE TRILOGY"), CODInfiniteWarfare("CALL OF DUTY: INFINITE WARFARE"),
		CODModernWarfareRemastered("CALL OF DUTY: MODERN WARFARE REMASTERED"),
		MarvelAlliance("MARVEL ULTIMATE ALLIANCE"), Ghostbusters("GHOSTBUSTERS"), TMNT("TMNT: MUTANTS IN MANHATTAN"),
		Chivarly("CHIVALRY: MEDIEVAL WARFARE"), CODBlackOpsIII("CALL OF DUTY: BLACK OPS III"),
		GuitarHero("GUITAR HERO LIVE"), SkylandersImaginators("SKYLANDERS IMAGINATORS"),
		Transformers("TRANSFORMERS DEVASTATION"), TonyHawkPro5("TONY HAWK'S PRO SKATER 5"),
		SkylandersSuperchargers("SKYLANDERS SUPERCHARGERS"), KingsQuest("KING'S QUEST"),
		GeometryWars3("GEOMETRY WARS 3 DIMENSIONS"), CODAdvancedWarfare("CALL OF DUTY: ADVANCED WARFARE"),
		SpiderMan2("THE AMAZING SPIDER-MAN 2"), CODGhosts("CALL OF DUTY: GHOSTS"), Deadpool("DEADPOOL"),
		CODBlackOpsII("CALL OF DUTY: BLACK OPS II"), AngryBirdsTrilogy("ANGRY BIRDS TRILOGY"),
		ActivisionAnthology("ACTIVISION ANTHOLOGY"), IceAgeDrift("ICE AGE: CONTINENTAL DRIFT"),
		AmazingSpiderMan("THE AMAZING SPIDER-MAN"), CODModernWarfare3("CALL OF DUTY: MODERN WARFARE 3"),
		CODBlackOps("CALL OF DUTY: BLACK OPS"), CODModernWarfare("CALL OF DUTY 4: MODERN WARFARE");

		private final String name;

		GamesList(final String name) {
			this.name = name;
		}

		@Override
		public String toString() {
			return name;
		}
	}

}

package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import commonUtilities.Constants.Locales;
import pageFactory.GamesPage;
import pageFactory.ProductPage;

public class GamesPage_Articles {

	BaseClass base;
	GamesPage Gamespage;
	ProductPage gamesproductpage;

	@BeforeClass(alwaysRun = true)
	public void preCondition() throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod)
			throws ParseException, Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		Reporter.setCurrentTestResult(result);
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}
	
		Gamespage = new GamesPage();
		gamesproductpage = new ProductPage();
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticles(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		// Gamespage.selectRegionByName(Locales.US);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforBeFr(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.BEFR);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforUS(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		// Gamespage.selectRegionByName(Locales.US);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforNorge(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Norge);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforItalia(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Italia);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}
	
	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforFrLu(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Luxembourg);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforBrasil(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Brasil);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforCN(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.CN);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforKo(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Ko);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforJA(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Ja);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidateArticlesforen_au(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Australia);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidatearticlesforDE(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Deutschland);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidatearticlesforSuomi(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.Suomi);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidatearticlesforFrance(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.France);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void ValidatearticlesforEspana(String idno, String localecode, String gamename) throws Exception {
		base.stepInfo("Navigate to Games page");
		Driver.getinstance().waitForPageToBeReady();
		Gamespage.selectRegionByName(Locales.España);
		gamesproductpage.validateArticles(idno, localecode, gamename);
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
				
				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}

package testScripts;

import java.lang.reflect.Method;
import java.text.ParseException;

import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import pageFactory.GamesPage;
import pageFactory.OnlineServicesHomePage;
import pageFactory.ProductPage;
import pageFactory.SupportHomePage;

public class OnlineServices_PlatformStatus extends BaseClass {

	BaseClass base;
	SupportHomePage hp;
	GamesPage ghp;
	ProductPage gpp;
	OnlineServicesHomePage onlinehp;

	@BeforeClass(alwaysRun = true)
	@Parameters({ "browsertype" })
	public void preCondition(String browsertype) throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
		base.applicationlaunch(browsertype);
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		ghp = new GamesPage();
		hp = new SupportHomePage();
		onlinehp = new OnlineServicesHomePage();
		base.stepInfo("Navigate to Games Home page");
		Driver.getinstance().waitForPageToBeReady();
	}

	// @Test(dataProviderClass = Utility.class,dataProvider = "readexcelbyname")
	public void RumbleCrossplayData(String PlatformsTitle, String GamesinDropDown, String Platforms,
			String Gamesfromgamepage, String GamesPlatforms) throws Exception {
		onlinehp.triggerEmailDefcon1(PlatformsTitle);
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.España, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.triggerEmailDefcon2(PlatformsTitle);
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.España, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

	}

	// @Test(dataProviderClass = Utility.class,dataProvider = "readexcelbyname")
	public void Warzone2Data(String PlatformsTitle, String GamesinDropDown, String Platforms, String Gamesfromgamepage,
			String GamesPlatforms) throws Exception {
		onlinehp.triggerEmailDefcon1(PlatformsTitle);
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.España, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.triggerEmailDefcon2(PlatformsTitle);
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.España, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
	}

	// @Test(dataProviderClass = Utility.class,dataProvider = "readexcelbyname")
	public void CODVanguardData(String PlatformsTitle, String GamesinDropDown, String Platforms,
			String Gamesfromgamepage, String GamesPlatforms) throws Exception {
		// onlinehp.triggerEmailDefcon1(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.CN);
		onlinehp.verifyPlatformStatus(Locales.CN, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.TwZh);
		onlinehp.verifyPlatformStatus(Locales.TwZh, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Ko);
		onlinehp.verifyPlatformStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.triggerEmailDefcon2(PlatformsTitle);
		onlinehp.selectLocaleAndVerifyStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.España, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.CN, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.TwZh, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		onlinehp.selectLocaleAndVerifyStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
	}

	// @Test(dataProviderClass = Utility.class,dataProvider = "readexcelbyname")
	public void CODColdWar(String PlatformsTitle, String GamesinDropDown, String Platforms, String Gamesfromgamepage,
			String GamesPlatforms) throws Exception {
		// onlinehp.triggerEmailDefcon1(PlatformsTitle);
		/*
		 * ghp.selectRegionByName(Locales.UK);
		 * onlinehp.verifyPlatformStatus(Locales.UK,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * ghp.selectRegionByName(Locales.Deutschland);
		 * onlinehp.verifyPlatformStatus(Locales.Deutschland,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Suomi);
		 * onlinehp.verifyPlatformStatus(Locales.Suomi,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Norge);
		 * onlinehp.verifyPlatformStatus(Locales.Norge,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * ghp.selectRegionByName(Locales.Australia);
		 * onlinehp.verifyPlatformStatus(Locales.Australia,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.US);
		 * onlinehp.verifyPlatformStatus(Locales.US,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); //
		 * ghp.selectRegionByName(Locales.España); //
		 * onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * ghp.selectRegionByName(Locales.Luxembourg);
		 * onlinehp.verifyPlatformStatus(Locales.Luxembourg,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.BEFR);
		 * onlinehp.verifyPlatformStatus(Locales.BEFR,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.France);
		 * onlinehp.verifyPlatformStatus(Locales.France,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Italia);
		 * onlinehp.verifyPlatformStatus(Locales.Italia,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Brasil);
		 * onlinehp.verifyPlatformStatus(Locales.Brasil,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Ja);
		 * onlinehp.verifyPlatformStatus(Locales.Ja,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.CN);
		 * onlinehp.verifyPlatformStatus(Locales.CN,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.TwZh);
		 * onlinehp.verifyPlatformStatus(Locales.TwZh,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Ko);
		 * onlinehp.verifyPlatformStatus(Locales.Ko,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * onlinehp.triggerEmailDefcon2(PlatformsTitle);
		 * 
		 * onlinehp.verifyPlatformStatus(Locales.Ko,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * onlinehp.triggerEmailDefcon3(PlatformsTitle);
		 * onlinehp.verifyPlatformStatus(Locales.Ko,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * onlinehp.triggerEmailDefcon4(PlatformsTitle);
		 * onlinehp.verifyPlatformStatus(Locales.Ko,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * onlinehp.triggerEmailDefcon5(PlatformsTitle);
		 * onlinehp.verifyPlatformStatus(Locales.Ko,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * onlinehp.triggerEmailFinalIncident(PlatformsTitle);
		 */
		onlinehp.verifyPlatformStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
	}

	// @Test(dataProviderClass = Utility.class,dataProvider = "readexcelbyname")
	public void WarzoneCaldera(String PlatformsTitle, String GamesinDropDown, String Platforms,
			String Gamesfromgamepage, String GamesPlatforms) throws Exception {
		// onlinehp.triggerEmailDefcon1(PlatformsTitle);
		/*
		 * ghp.selectRegionByName(Locales.UK);
		 * onlinehp.verifyPlatformStatus(Locales.UK,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * ghp.selectRegionByName(Locales.Deutschland);
		 * onlinehp.verifyPlatformStatus(Locales.Deutschland,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Suomi);
		 * onlinehp.verifyPlatformStatus(Locales.Suomi,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Norge);
		 * onlinehp.verifyPlatformStatus(Locales.Norge,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * ghp.selectRegionByName(Locales.Australia);
		 * onlinehp.verifyPlatformStatus(Locales.Australia,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.US);
		 * onlinehp.verifyPlatformStatus(Locales.US,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); //
		 * ghp.selectRegionByName(Locales.España); //
		 * onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 * ghp.selectRegionByName(Locales.Luxembourg);
		 * onlinehp.verifyPlatformStatus(Locales.Luxembourg,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.BEFR);
		 * onlinehp.verifyPlatformStatus(Locales.BEFR,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.France);
		 * onlinehp.verifyPlatformStatus(Locales.France,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Italia);
		 * onlinehp.verifyPlatformStatus(Locales.Italia,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Brasil);
		 * onlinehp.verifyPlatformStatus(Locales.Brasil,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Ja);
		 * onlinehp.verifyPlatformStatus(Locales.Ja,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.CN);
		 * onlinehp.verifyPlatformStatus(Locales.CN,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.TwZh);
		 * onlinehp.verifyPlatformStatus(Locales.TwZh,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Ko);
		 * onlinehp.verifyPlatformStatus(Locales.Ko,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 */
		onlinehp.triggerEmailDefcon2(PlatformsTitle);
		onlinehp.verifyPlatformStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.triggerEmailDefcon3(PlatformsTitle);
		onlinehp.verifyPlatformStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.triggerEmailDefcon4(PlatformsTitle);
		onlinehp.verifyPlatformStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.triggerEmailDefcon5(PlatformsTitle);
		onlinehp.verifyPlatformStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		onlinehp.triggerEmailFinalIncident(PlatformsTitle);
		onlinehp.verifyPlatformStatus(Locales.Ko, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
	}

	// @Test(dataProviderClass = Utility.class,dataProvider = "readexcelbyname")
	public void TonyHawk(String PlatformsTitle, String GamesinDropDown, String Platforms, String Gamesfromgamepage,
			String GamesPlatforms) throws Exception {
		onlinehp.triggerEmailDefcon1(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		/*
		 * ghp.selectRegionByName(Locales.CN);
		 * onlinehp.verifyPlatformStatus(Locales.CN,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.TwZh);
		 * onlinehp.verifyPlatformStatus(Locales.TwZh,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms); ghp.selectRegionByName(Locales.Ko);
		 * onlinehp.verifyPlatformStatus(Locales.Ko,GamesinDropDown, Platforms,
		 * Gamesfromgamepage, GamesPlatforms);
		 */
		onlinehp.triggerEmailDefcon2(PlatformsTitle);

		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		onlinehp.triggerEmailDefcon3(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		onlinehp.triggerEmailDefcon4(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		onlinehp.triggerEmailDefcon5(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.España);
		onlinehp.verifyPlatformStatus(Locales.España, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyPlatformStatus(Locales.Ja, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		onlinehp.triggerEmailFinalIncident(PlatformsTitle);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readexcelbyname")
	public void SkylanderSupercharger(String PlatformsTitle, String GamesinDropDown, String Platforms,
			String Gamesfromgamepage, String GamesPlatforms) throws Exception {
		onlinehp.triggerEmailDefcon1(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		onlinehp.triggerEmailDefcon2(PlatformsTitle);

		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		onlinehp.triggerEmailDefcon3(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		onlinehp.triggerEmailDefcon4(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		// ghp.selectRegionByName(Locales.España);
		// onlinehp.verifyPlatformStatus(Locales.España,GamesinDropDown, Platforms,
		// Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		onlinehp.triggerEmailDefcon5(PlatformsTitle);
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyPlatformStatus(Locales.UK, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyPlatformStatus(Locales.Deutschland, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyPlatformStatus(Locales.Suomi, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyPlatformStatus(Locales.Norge, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyPlatformStatus(Locales.Australia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyPlatformStatus(Locales.US, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.España);
		onlinehp.verifyPlatformStatus(Locales.España, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyPlatformStatus(Locales.Luxembourg, GamesinDropDown, Platforms, Gamesfromgamepage,
				GamesPlatforms);
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyPlatformStatus(Locales.BEFR, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyPlatformStatus(Locales.France, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyPlatformStatus(Locales.Italia, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyPlatformStatus(Locales.Brasil, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);

		// onlinehp.triggerEmailFinalIncident(PlatformsTitle);
		// onlinehp.validateFinalIncidentDetails();
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Driver.getinstance();
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		Utility.info("Executed :" + result.getMethod().getMethodName());
	}

	@AfterClass(alwaysRun = true)
	public void close() {
		try {
			Driver.getinstance();
			Driver.getDriver().quit();
		} finally {
			Driver.getinstance();
			Driver.closeDriver();
		}
		base.stepInfo("******TEST CASES FOR 'GamesHeaderLinkURL' EXECUTED******");
	}

}

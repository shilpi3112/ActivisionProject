package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;

public class GamesPage_ViewAndSortWithView extends BaseClass {

	BaseClass base;
	GamesPage Gamespage;
	public String sheetname;
	
	
	@BeforeClass(alwaysRun = true)
	private void TestStart() throws Exception, InterruptedException, IOException {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	
	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("Executing method : " + testMethod.getName());
    	Gamespage = new GamesPage();
		base.stepInfo("Navigate to Games page to validate Sorting with View Options");
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforDe(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Deutschland);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Deutschland);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforSuomi(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Suomi);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Suomi);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforNorge(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Norge);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Norge);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforAu(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Australia);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Australia);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforUK(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.UK);
		sheetname = Gamespage.selectsheetbyRegion(Locales.UK);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforUS(String gamename, String columnname, String gamecount) throws Exception {
		// Gamespage.selectRegionByName(Locales.US);
		sheetname = Gamespage.selectsheetbyRegion(Locales.US);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforEs(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.España);
		sheetname = Gamespage.selectsheetbyRegion(Locales.España);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforLu(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Luxembourg);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Luxembourg);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforFrance(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.France);
		sheetname = Gamespage.selectsheetbyRegion(Locales.France);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforBEFR(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.BEFR);
		sheetname = Gamespage.selectsheetbyRegion(Locales.BEFR);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforItalia(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Italia);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Italia);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforBrasil(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Brasil);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Brasil);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(dataProviderClass = Utility.class, dataProvider = "readfirstsheetsfromExcel")
	public void ValidateViewWithSortforJa(String gamename, String columnname, String gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Ja);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Ja);
		System.out.println(sheetname);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount, sheetname);
	}

	@Test(priority = 14, dataProvider = "viewandsortforCJK")
	public void ValidateViewWithSortforCN(String gamename, String columnname, int gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.CN);
		sheetname = Gamespage.selectsheetbyRegion(Locales.CN);
		System.out.println(sheetname);
		String gamecount1 = String.valueOf(gamecount);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount1, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount1, sheetname);
	}

	@Test(priority = 15, dataProvider = "viewandsortforTwZh")
	public void ValidateViewWithSortforTwZh(String gamename, String columnname, int gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.TwZh);
		sheetname = Gamespage.selectsheetbyRegion(Locales.TwZh);
		System.out.println(sheetname);
		String gamecount1 = String.valueOf(gamecount);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount1, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount1, sheetname);
	}

	@Test(priority = 16, dataProvider = "viewandsortforCJK")
	public void ValidateViewWithSortforKo(String gamename, String columnname, int gamecount) throws Exception {
		Gamespage.selectRegionByName(Locales.Ko);
		sheetname = Gamespage.selectsheetbyRegion(Locales.Ko);
		System.out.println(sheetname);
		String gamecount1 = String.valueOf(gamecount);
		Gamespage.sortingWithViewOptions(gamename, columnname, gamecount1, sheetname);
		Gamespage.validateViewDropdown(gamename, columnname, gamecount1, sheetname);
	}

	@DataProvider(name = "viewandsortforCJK")
	public Object[][] viewandsortforCJK() {
		return new Object[][] { { "Call", "Newest to Oldest", 8 } };
	}

	@DataProvider(name = "viewandsortforTwZh")
	public Object[][] viewandsortforTwZh() {
		return new Object[][] { { "Call", "Newest to Oldest", 11 } };
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}

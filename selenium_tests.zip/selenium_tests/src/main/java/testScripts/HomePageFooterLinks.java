package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.SupportHomePage;

public class HomePageFooterLinks extends BaseClass {

	BaseClass base;
	SupportHomePage hp;
	GamesPage ghp;

	@BeforeClass(alwaysRun = true)
	public void preCondition() throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	
	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		Reporter.setCurrentTestResult(result);
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}
    }

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforDE(String browser) throws Exception {
        base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		base.stepInfo("Navigate to Games Home page");
		Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Deutschland);
		hp.checkAllFooterLinksonHomePage(Locales.Deutschland);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforUS(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.US);
		hp.checkAllFooterLinksonHomePage(Locales.US);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforAustralia(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Australia);
		hp.checkAllFooterLinksonHomePage(Locales.Australia);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforUK(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.UK);
		hp.checkAllFooterLinksonHomePage(Locales.UK);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforEspaña(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.España);
		hp.checkAllFooterLinksonHomePage(Locales.España);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforSuomi(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Suomi);
		hp.checkAllFooterLinksonHomePage(Locales.Suomi);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforFrance(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.France);
		hp.checkAllFooterLinksonHomePage(Locales.France);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforBEFR(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.BEFR);
		hp.checkAllFooterLinksonHomePage(Locales.BEFR);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforLuxembourg(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Luxembourg);
		hp.checkAllFooterLinksonHomePage(Locales.Luxembourg);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforItalia(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Italia);
		hp.checkAllFooterLinksonHomePage(Locales.Italia);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforJapan(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Ja);
		hp.checkAllFooterLinksonHomePage(Locales.Ja);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforKorea(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Ko);
		hp.checkAllFooterLinksonHomePage(Locales.Ko);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforNorge(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Norge);
		hp.checkAllFooterLinksonHomePage(Locales.Norge);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforBrasil(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.Brasil);
		hp.checkAllFooterLinksonHomePage(Locales.Brasil);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforCNZH(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.CN);
		hp.checkAllFooterLinksonHomePage(Locales.CN);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageLinksforTwZh(String browser) throws Exception {
		   base.applicationlaunch(browser);
			ghp = new GamesPage();
			hp = new SupportHomePage();
			base.stepInfo("Navigate to Games Home page");
			Driver.getinstance().waitForPageToBeReady();
		ghp.selectRegionByName(Locales.TwZh);
		hp.checkAllFooterLinksonHomePage(Locales.TwZh);
	}

	@DataProvider(name = "testData")
    public static Object[][] testData() {
        String params = System.getProperty("browser");
        String[] paramArray = params.split(",");

        Object[][] data = new Object[paramArray.length][];
        for (int i = 0; i < paramArray.length; i++) {
            data[i] = new Object[]{paramArray[i]};
        }
        return data;
    }
	
	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (AssertionError e1) {

			throw e1;
		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
			Driver.getDriver().quit();
			}
		}
	}

}

package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.SupportHomePage;

public class HomePage_Games extends BaseClass {

	BaseClass base;
	SupportHomePage hp;
	GamesPage ghp;

	@BeforeClass(alwaysRun = true)
	public void preCondition() throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {

		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		Reporter.setCurrentTestResult(result);
		base.stepInfo("Navigate to Home page");
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforDe(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Deutschland);
		hp.validateHeaderLinkURLForAllGames(Locales.Deutschland);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforSuomi(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Suomi);
		hp.validateHeaderLinkURLForAllGames(Locales.Suomi);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforNorge(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Norge);
		hp.validateHeaderLinkURLForAllGames(Locales.Norge);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforAustralia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Australia);
		hp.validateHeaderLinkURLForAllGames(Locales.Australia);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforUK(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.UK);
		hp.validateHeaderLinkURLForAllGames(Locales.UK);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforEspana(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.España);
		hp.validateHeaderLinkURLForAllGames(Locales.España);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforLuxembourg(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Luxembourg);
		hp.validateHeaderLinkURLForAllGames(Locales.Luxembourg);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforBEFR(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.BEFR);
		hp.validateHeaderLinkURLForAllGames(Locales.BEFR);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforFrance(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.France);
		hp.validateHeaderLinkURLForAllGames(Locales.France);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforItalia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Italia);
		hp.validateHeaderLinkURLForAllGames(Locales.Italia);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforBrasil(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Brasil);
		hp.validateHeaderLinkURLForAllGames(Locales.Brasil);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforUS(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.US);
		hp.validateHeaderLinkURLForAllGames(Locales.US);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforKorean(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Ko);
		hp.validateHeaderLinkURLForAllGames(Locales.Ko);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforJa(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Ja);
		hp.validateHeaderLinkURLForAllGames(Locales.Ja);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforCNZh(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.CN);
		hp.validateHeaderLinkURLForAllGames(Locales.CN);
	}

	@Test(dataProvider = "testData")
	public void ValidateHomePageforTwZh(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.TwZh);
		hp.validateHeaderLinkURLForAllGames(Locales.TwZh);
	}

	@DataProvider(name = "testData")
	public static Object[][] testData() {
		String params = System.getProperty("browser");
		String[] paramArray = params.split(",");

		Object[][] data = new Object[paramArray.length][];
		for (int i = 0; i < paramArray.length; i++) {
			data[i] = new Object[] { paramArray[i] };
		}
		return data;
	}

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (AssertionError e1) {
            WebUtility.updateTotalCount(2);
			throw e1;
		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
			Driver.getDriver().quit();
			}
		}
	}

}

package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.GamesPage;
import pageFactory.OnlineServicesHomePage;
import pageFactory.SupportHomePage;

public class OnlineServices_AllValidations {
	BaseClass base;
	SupportHomePage hp;
	OnlineServicesHomePage onlinehp;
	GamesPage ghp;

	@BeforeClass(alwaysRun = true)
    public void preCondition(String browsertype) throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {
		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
	base.stepInfo("Navigate to Online Services page");
	String status = WebUtility.getStatus();
	System.out.println(status);
	if (status.equalsIgnoreCase("Cancelled")) {

		if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
			Driver.getDriver().quit();
		}
		throw new SkipException("skipping all test cases");
	}

	else {
		System.out.println("Continue execution");
	}
	}

	@Test(priority = 1,dataProvider = "testData")
	public void ValidatAllFunctionalityforDE(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Deutschland);
		onlinehp.verifyConnectionTips(Locales.Deutschland);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Deutschland);
	}

	@Test(priority = 2,dataProvider = "testData")
	public void ValidatAllFunctionalityforSuomi(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Suomi);
		onlinehp.verifyConnectionTips(Locales.Suomi);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Suomi);
	}

	@Test(priority = 3,dataProvider = "testData")
	public void ValidatAllFunctionalityforNorge(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Norge);
		onlinehp.verifyConnectionTips(Locales.Norge);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Norge);
	}

	@Test(priority = 4,dataProvider = "testData")
	public void ValidatAllFunctionalityforAustralia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Australia);
		onlinehp.verifyConnectionTips(Locales.Australia);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Australia);
	}

	@Test(priority = 5,dataProvider = "testData")
	public void ValidatAllFunctionalityforUK(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.UK);
		onlinehp.verifyConnectionTips(Locales.UK);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.UK);
	}

	@Test(priority = 6,dataProvider = "testData")
	public void ValidatAllFunctionalityforUS(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.US);
		onlinehp.verifyConnectionTips(Locales.US);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.US);
	}

	@Test(priority = 7,dataProvider = "testData")
	public void ValidatAllFunctionalityforEspaña(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.España);
		onlinehp.verifyConnectionTips(Locales.España);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.España);
	}

	@Test(priority = 8,dataProvider = "testData")
	public void ValidatAllFunctionalityforLuxembourg(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Luxembourg);
		onlinehp.verifyConnectionTips(Locales.Luxembourg);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Luxembourg);
	}

	@Test(priority = 9,dataProvider = "testData")
	public void ValidatAllFunctionalityforBEFR(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.BEFR);
		onlinehp.verifyConnectionTips(Locales.BEFR);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.BEFR);
	}

	@Test(priority = 10,dataProvider = "testData")
	public void ValidatAllFunctionalityforFrance(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.France);
		onlinehp.verifyConnectionTips(Locales.France);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.France);
	}

	@Test(priority = 11,dataProvider = "testData")
	public void ValidatAllFunctionalityforItalia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Italia);
		onlinehp.verifyConnectionTips(Locales.Italia);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Italia);
	}

	@Test(priority = 12,dataProvider = "testData")
	public void ValidatAllFunctionalityforBrasil(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Brasil);
		onlinehp.verifyConnectionTips(Locales.Brasil);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Brasil);
	}

	@Test(priority = 13,dataProvider = "testData")
	public void ValidatAllFunctionalityforKo(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Ko);
		onlinehp.verifyConnectionTips(Locales.Ko);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Ko);
	}

	@Test(priority = 14,dataProvider = "testData")
	public void ValidatAllFunctionalityforJa(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.Ja);
		onlinehp.verifyConnectionTips(Locales.Ja);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.Ja);
	}

	@Test(priority = 15,dataProvider = "testData")
	public void ValidatAllFunctionalityforCN(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.CN);
		onlinehp.verifyConnectionTips(Locales.CN);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.CN);
	}

	@Test(priority = 16,dataProvider = "testData")
	public void ValidatAllFunctionalityforTwZh(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		ghp.selectRegionByName(Locales.TwZh);
		onlinehp.verifyConnectionTips(Locales.TwZh);
		onlinehp.checkServerNetworkStatus();
		onlinehp.verifyFollowonTwitter();
		onlinehp.gamesstatus(Locales.TwZh);
	}

	@DataProvider(name = "testData")
    public static Object[][] testData() {
        String params = System.getProperty("browser");
        String[] paramArray = params.split(",");

        Object[][] data = new Object[paramArray.length][];
        for (int i = 0; i < paramArray.length; i++) {
            data[i] = new Object[]{paramArray[i]};
        }
        return data;
    }

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
				
				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}

package testScripts;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Utility;
import commonUtilities.WebUtility;
import pageFactory.SupportHomePage;
import pageFactory.GamesPage;

public class HomePageSearchMovingCarousel extends BaseClass {

	BaseClass base;
	SupportHomePage hp;
	GamesPage ghp;

	@BeforeClass(alwaysRun = true)
	public void preCondition() throws Exception {
		System.out.println("******Execution started for " + this.getClass().getSimpleName() + "********");
		System.out.println("------------------------------------------");
		base = new BaseClass();
   }

	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result, Method testMethod) throws ParseException, Exception {

		System.out.println("------------------------------------------");
		System.out.println("Executing method : " + testMethod.getName());
		Reporter.setCurrentTestResult(result);
		String status = WebUtility.getStatus();
		System.out.println(status);
		if (status.equalsIgnoreCase("Cancelled")) {

			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
				Driver.getDriver().quit();
			}
			throw new SkipException("skipping all test cases");
		}

		else {
			System.out.println("Continue execution");
		}
		base.stepInfo("Navigate to Games Home page");
	}

	@Test(priority = 1,dataProvider = "testData")
	public void ValidateSearchCarouselforDeutschland(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 2,dataProvider = "testData")
	public void ValidateSearchCarouselforSuomi(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 3,dataProvider = "testData")
	public void ValidateSearchCarouselforNorge(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 4,dataProvider = "testData")
	public void ValidateSearchCarouselforAustralia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 5,dataProvider = "testData")
	public void ValidateSearchCarouselforUnitedKingdom(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 6,dataProvider = "testData")
	public void ValidateSearchCarouselforUnitedStates(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 7,dataProvider = "testData")
	public void ValidateSearchCarouselforEspaña(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 8,dataProvider = "testData")
	public void ValidateSearchCarouselforLuxembourg(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 9,dataProvider = "testData")
	public void ValidateSearchCarouselforBelgiumFrançais(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 10,dataProvider = "testData")
	public void ValidateSearchCarouselforFrance(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 11,dataProvider = "testData")
	public void ValidateSearchCarouselforItalia(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 12,dataProvider = "testData")
	public void ValidateSearchCarouselforBrasil(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 13,dataProvider = "testData")
	public void ValidateSearchCarouselforJapan(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 14,dataProvider = "testData")
	public void ValidateSearchCarouselforChinese(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 15,dataProvider = "testData")
	public void ValidateSearchCarouselforKorea(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@Test(priority = 16,dataProvider = "testData")
	public void ValidateSearchCarouselforzhtw(String browser) throws Exception {
		base.applicationlaunch(browser);
		ghp = new GamesPage();
		hp = new SupportHomePage();
		hp.validateMovingCarouselBanner();
		hp.validateSearchFunction();
	}

	@DataProvider(name = "testData")
    public static Object[][] testData() {
        String params = System.getProperty("browser");
        String[] paramArray = params.split(",");

        Object[][] data = new Object[paramArray.length][];
        for (int i = 0; i < paramArray.length; i++) {
            data[i] = new Object[]{paramArray[i]};
        }
        return data;
    }

	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result, Method testMethod) throws IOException, Exception {
		Reporter.setCurrentTestResult(result);
		Utility.logafter(testMethod.getName());
		if (ITestResult.FAILURE == result.getStatus()) {
			Utility baseClass = new Utility(Driver.getDriver());
			baseClass.screenShot(result);
		}
		try {
			if (Driver.getDriver() != null && ((RemoteWebDriver) Driver.getDriver()).getSessionId() != null) {

				Driver.getDriver().close();
				Driver.Quit();
			}

		} catch (AssertionError e1) {

			throw e1;
		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			if (Driver.getDriver()!=null && ((RemoteWebDriver) Driver.getDriver()).getSessionId()!= null) {
			Driver.getDriver().quit();
			}
		}
	}

}

package base;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import automationLibrary.Driver;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Utility;
import pageFactory.ProductPage;

public class BaseClass {

	public static Properties prop;
	public static Workbook wb = null;
	public static Sheet sheet = null;
	public static String sheetname;
	public static String FilePath;
	public static String fileName;
	public static int numRows;
	SoftAssert softAssertion;
	StringWriter sw;

	private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ProductPage.class);

	public BaseClass() {

		softAssertion = new SoftAssert();
		sw = new StringWriter();

	}

	public void applicationlaunch(String browser) throws Exception {
		softAssertion = new SoftAssert();
		sw = new StringWriter();
		String[] browsernames = browser.split(",");
		for(String browsername: browsernames)
		{
            System.out.println("Browser used for the script-->" +browsername);
			Driver.getinstance().setDriver(browsername);
			LOGGER.info(browsername + "--> is launched and application is loaded");
			stepInfo(browsername + "--> is launched and application is loaded");
			LOGGER.info("URL for the application is--->" + System.getProperty("url"));
			Driver.getDriver().get(System.getProperty("url"));
			Driver.getinstance().waitForPageToBeReady();
			LOGGER.info("URL for the application is--->" + System.getProperty("url"));
			System.out.println("URL used for the script-->" + System.getProperty("url"));
			System.out.println("Browser used for the script-->" + browsername);
			System.out.println("Suite used for the script-->" + System.getProperty("suiteXmlFile"));
			Driver.getinstance().waitForPageToBeReady();
		}
	}

	
	public static String ReadProperties(String key) throws Exception, IOException {
		FileInputStream fis = null;
		prop = new Properties();
		fis = new FileInputStream(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main"
				+ File.separator + "java" + File.separator + "configurations" + File.separator + "config.properties");

		// create Properties class object to access properties file load the properties
		// file
		prop.load(fis);
		String value = prop.get(key).toString();

		if (value.isEmpty()) {
			throw new Exception("Value is not specified for: " + key + "in properties file");
		}
		return value;
	}

	/**
	 * Method is to print the test step information in report in blue color
	 * 
	 * @author Shilpi
	 * @param message Message which needs to be printed in report
	 */
	public void stepInfo(String message) {
		Reporter.log("<font color='blue'>" + message + "</font>");
		Utility.info("Step info: " + message);
	}

	/**
	 * Method is to print the test step pass information in report in green color
	 * 
	 * @author Shilpi
	 * @param message Message which needs to be printed in report
	 */
	public void passedStep(String message) {
		Reporter.log("<font color='green'>" + message + "</font>");
		Utility.info("Passed step: " + message);

	}

	/**
	 * Method is to print the test step fail information in report in blue color
	 * 
	 * @author Shilpi
	 * @param message Message which needs to be printed in report
	 */
	public void failedStep(String message) {
		Reporter.log("<font color='red'>" + message + "</font>");
		Utility.info("Failed step: " + message);
		SoftAssert sa = new SoftAssert();
		sa.fail();
		// softAssertion.assertAll();
		// Assert.assertTrue(false);
	}

	public void getallselectele(Select ele) {
		List<WebElement> dd = ele.getOptions();

		System.out.println(dd.size());

		for (int j = 0; j < dd.size(); j++) {
			System.out.println(dd.get(j).getText());
			Utility.info(dd.get(j).getText());

		}
	}

	/**
	 * @author Indium Raghuram ] Description : Method to collect the list of
	 *         elements and returns as list with text (GenericMethod) Date:8/15/21
	 *         Modified date: N/A Modified by: N/A
	 */
	public List<String> availableListofElements(List<WebElement> elementlist) {
		List<String> stringList = new ArrayList<String>();
		try {
			for (WebElement element : elementlist) {
				stringList.add(element.getText().trim().toString());
				// System.out.println(element.getText());
			}
			for (String s : stringList) {
				System.out.println(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stringList;
	}

	public void comparearraywithlist(String[] listarray, List<WebElement> values) {

		// List<WebElement> values = driverref.getDriver().findElements());
		List<String> value = new ArrayList<String>();
		value = availableListofElements(values);
		System.out.println(listarray + "--------------" + values);
		Utility.info(listarray);
		Utility.info(values);
		Assert.assertEquals(listarray, value);
	}

	public void getlistsize(List<WebElement> elementList, int count) {
		elementList = new ArrayList<WebElement>();
		int sizeoflist = elementList.size();
		Assert.assertEquals(sizeoflist, count);
	}

	/**
	 * Method is to wait for the element until it is clickable
	 * 
	 * @author Sowndariya
	 * @param element Element locator for which needs to be waited
	 */
	public boolean waitTillElemetToBeClickable(WebElement element) {
		boolean status = false;
		try {
			WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(60));
			wait.until(ExpectedConditions.elementToBeClickable(element));
			status = true;
		} catch (Exception e) {
			Utility.info("Exception occured whilr waiting for element is clickable");
		}
		return status;
	}

	/**
	 * Converts List to string array
	 * 
	 * @author Shilpi Mangal
	 * @param list
	 * @return
	 */
	public String[] ListTOStringArray(List<String> list) {
		try {
			String[] StringArray = new String[list.size()];
			StringArray = list.toArray(StringArray);

			for (String s : StringArray)
				System.out.println(s);
			return StringArray;
		} catch (Exception E) {
			E.printStackTrace();
			Utility.info(sw.toString());
			return null;
		}

	}

	/**
	 * @author
	 * @return
	 * @Description compare list with list using contains
	 * @Modified By :Shilpi
	 */

	public boolean compareListViaContains(List<String> baseList, List<String> compareList) {
		boolean flag = false;

		for (int i = 0; i < baseList.size(); i++) {
			if (baseList.get(i).contains(compareList.get(i))) {
				Assert.assertEquals(true, true);
				flag = true;
			} else {
				failedStep("Base String doesn't contains compare String");
				flag = false;
			}
		}
		return flag;
	}

	/**
	 * @author Shilpi
	 */
//	Method used for checking the exepected condition to be available
	public void waituntilelementtobevisible(WebElement element, int time) {

		try {
			WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(time));
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			e.printStackTrace();
			Utility.info("Exception occured while waiting for element is not clickable");
		}

	}

	public void checkBrokenLinks() throws InterruptedException, MalformedURLException, IOException {
		List<WebElement> allHref = new ArrayList<WebElement>();
		List<WebElement> linklist = Driver.getDriver().findElements(By.tagName("a"));

		for (int i = 0; i < linklist.size(); i++) {
			if (linklist.get(i).getAttribute("href").contains("https:")
					&& linklist.get(i).getAttribute("href") != null) {
				System.out.println(linklist.get(i).getAttribute("href"));

				HttpURLConnection connection = (HttpURLConnection) new URL(linklist.get(i).getAttribute("href"))
						.openConnection();
				connection.connect();
				String response = connection.getResponseMessage();
				connection.disconnect();
				System.out.println(linklist.get(i).getAttribute("href") + "R=e=s=p=o=n=s=e=>" + response);
				allHref.add(linklist.get(i));
			}

		}
	}

	public void capturealllinksandclick(List<WebElement> element) throws InterruptedException {
		String[] links = null;
		// List<WebElement> all_links_webpage = element.;
		int linksCount = element.size();
		System.out.println("Total no of links Available: " + linksCount);
		links = new String[linksCount];
		System.out.println("List of links Available: ");
		// print all the links from webpage
		for (int i = 1; i < linksCount; i++) {
			links[i] = element.get(i).getAttribute("alt");
			System.out.println(element.get(i).getAttribute("alt"));
		}
		/*
		 * // navigate to each Link on the webpage for(int i=0;i<linksCount;i++) {
		 * Driver.getDriver().navigate().to(links[i]); Thread.sleep(3000);
		 * 
		 * }
		 */
	}

	public List<String> getalllielementsfromdropdown(List<WebElement> ele) {
		List<String> dropdownvalues = new ArrayList<String>();
		for (WebElement list : ele) {
			System.out.println(list.getText());
		}
		return dropdownvalues;
	}

	/**
	 * @author Shilpi Description : To verify if list is empty or not
	 */
	public Boolean verifyElementCollectionIsNotEmpty(List<WebElement> elementC, String passMsg, String failMsg) {

		if (elementC.size() > 0) {
			passedStep(passMsg);
			return true;
		} else {
			failedStep(failMsg);
			return false;
		}
	}

	/**
	 * @author Shilpi : Description : listCompareEquals with Pass and Fail Message
	 */
	public void listCompareEquals(List<String> sourceList, List<String> compreList, String passMsg,
			String failMessage) {
		try {
			SoftAssert sa1 = new SoftAssert();
			stepInfo("Source String  : " + sourceList);
			stepInfo("Compare String  : " + compreList);

			if (sourceList == compreList) {
				passedStep(passMsg);
				sa1.assertEquals(sourceList, compreList);
			} else
				failedStep(failMessage);
			sa1.fail();
		} catch (Exception e) {
			e.printStackTrace();
			Utility.info(sw.toString());
			failedStep(failMessage);
		}
	}

	/**
	 * @author Shilpi Mangal
	 * @param element
	 * @param n
	 * @throws InterruptedException
	 * @Description this method is used for move to element and perform action
	 *              click, this method used action not performed in not normal click
	 *              method.
	 */
	public void moveWaitAndClick(WebElement element, int n) throws InterruptedException {

		Actions action = new Actions(Driver.getDriver());
		for (int i = 0; i < n; i++) {
			try {
				action.moveToElement(element).click().perform();
				break;
			} catch (Exception e) {
				wait(2);

			}
		}
	}

	/**
	 * @author Shilpi Mangal Description : textCompareEquals with Pass and Fail
	 *         Message
	 */
	public void digitCompareEquals(int value1, int value2, String passMsg, String failMessage) {
		try {
			System.out.println("Value 1  : " + value1);
			System.out.println("Value 2  : " + value2);
			softAssertion = new SoftAssert();
			Driver.getinstance().waitForPageToBeReady();
			softAssertion.assertEquals(value1, value2);
			if (value1 == value2) {
				passedStep(passMsg);
			} else if (value1 != value2) {
				failedStep(failMessage);
			}
		} catch (Exception E) {
			sw = new StringWriter();

			E.printStackTrace();
			Utility.info(sw.toString());
		}
	}

	/**
	 * @author Raghuram A Date: 11/11/21 Modified date:7/13/22 Modified by:
	 *         Description : textCompareEquals with Pass and Fail Message
	 */
	public void textCompareEquals(String sourceString, String compreString, String passMsg, String failMessage) {
		try {
			System.out.println("Source String  : " + sourceString);
			System.out.println("Compare String  : " + compreString);

			stepInfo("Expected : " + sourceString);
			stepInfo("Actual : " + compreString);

			if (sourceString.equals(compreString)) {
				passedStep(passMsg);
			} else if (!sourceString.equals(compreString)) {
				failedStep(failMessage);
			}
		} catch (Exception E) {
			E.printStackTrace();
			Utility.info(sw.toString());
			failedStep(failMessage);
		}
	}

	/**
	 * @author Shilpi Description : verify Original SortOrder
	 */
	public void verifyOriginalSortOrder(List<String> originalOrderedList, List<String> afterSortList, String sortType,
			Boolean sortOrder) throws InterruptedException, AWTException {

		for (String a : originalOrderedList) {
			stepInfo("Original Order--------->" + a);
		}

		if (sortType.equals("Ascending")) {
			Collections.sort(originalOrderedList);
		} else if (sortType.equals("Descending")) {
			Collections.sort(originalOrderedList, Collections.reverseOrder());
		}

		if (sortOrder) {
			listCompareEquals(originalOrderedList, afterSortList, "Sorting order maintained", "Sorting order failed");
		}

	}

	public void verifyandselectdropdowns(List<WebElement> element, String texttocompare) throws InterruptedException {
		List<String> dropdownvalueinString = new ArrayList<String>();
		dropdownvalueinString = availableListofElements(element);
		for (WebElement options : element) {
			if (options.getText().equalsIgnoreCase(texttocompare)) {
				options.click();
				Thread.sleep(1000);
			}

		}
	}

	/**
	 * @author Shilpi
	 * @param source
	 * @param compareString
	 * @param passMsg
	 * @param failMsg
	 * @throws InterruptedException
	 */
	public void compareListWithString(List<String> source, String compareString, String passMsg, String failMsg)
			throws InterruptedException {
		boolean compare = false;
		for (String actualValue : source) {
			if (actualValue.contains(compareString)) {
				compare = true;
			} else {
				compare = false;
				break;
			}
		}
		if (compare) {
			passedStep(passMsg);
		} else {
			failedStep(failMsg);
		}

	}

	/**
	 * @Author Shilpi
	 * @Description : compare list via contains & trim Space
	 * @param baseList
	 * @param compareList
	 * @return
	 * @throws InterruptedException
	 */
	public void compareListViaContainsTrimSpace(List<String> baseList, List<String> compareList)
			throws InterruptedException {
		SoftAssert sa1 = new SoftAssert();

		List<String> newsource = new ArrayList<>();
		List<String> newcompare = new ArrayList<>();

		for (int i = 0; i < baseList.size(); i++) {

			String source = baseList.get(i).trim().replace(" ", "");
			String compare = compareList.get(i).trim().replace(" ", "");

			System.out.println("Source : " + source);
			System.out.println("Compare : " + compare);

			newsource.add(source);
			newcompare.add(compare);
		}

		if (newsource.containsAll(newcompare)) {
			sa1.assertEquals(newsource, newcompare, "Base string is not matching with compare list");
			passedStep("String with comma separated values-->" + newsource + "  is matching with list" + newcompare);

		} else {
			// failedStep("Base list doesn't contains compare list");
			failedStep(
					"String with comma separated values-->" + newsource + "  is not matching with list" + newcompare);
			sa1.fail();
		}
	}

	public List<String> convertstringintolist(String CommaSeparatedstring) {
		Driver.getinstance().waitForPageToBeReady();
		List<String> newstring = Arrays.asList(CommaSeparatedstring.split("\\s*,\\s*"));
		System.out.println(newstring);
		List<String> newstring1 = new ArrayList<String>();
		for (String string : newstring) {
			string.trim().split(",");
			newstring1.add(string);

		}
		return newstring1;
	}

	public void comparelistwithStringCommaSeparated(String CommaSeparatedstring, List<WebElement> elements)
			throws InterruptedException {
		try {
			stepInfo("Scrolling to elements");
			Driver.getinstance().waitForPageToBeReady();
			List<String> newstring = Arrays.asList(CommaSeparatedstring.split("\\s*,\\s*"));
			System.out.println(newstring);
			List<String> newstring1 = new ArrayList<String>();
			for (String string : newstring) {
				string.split(",");
				newstring1.add(string);

			}
			List<String> actualoptions = new ArrayList<String>();
			actualoptions = availableListofElements(elements);

			// boolean flag=false;
			compareListViaContainsTrimSpace(actualoptions, newstring1);
			/*
			 * if(flag=true) { assertTrue(flag, "Base String contains compare String");
			 * passedStep("String with comma separated values-->"+CommaSeparatedstring
			 * +"  is matching with list"+actualoptions); } else if(flag=false) {
			 * assertFalse(flag=false, "Base String doesn't contains compare String");
			 * failedStep("String with comma separated values-->"+CommaSeparatedstring
			 * +"  is not matching with list"+actualoptions); softAssertion.fail(); }
			 */
		} catch (Exception e) {
			e.printStackTrace();
			failedStep("Exception occured while comparing values from product options" + e.getLocalizedMessage());
			Assert.fail();

		}
		// softAssertion.assertAll();
	}

	/**
	 * @author
	 * @Description reads excel column data
	 */
	public List<String> readExcelColumnData(String filepath, String sheetname, String columnHeading) throws Exception {
		Workbook wb = null;
		Sheet sheet = null;

		List<String> excelData = new ArrayList<String>();

		FileInputStream fis = new FileInputStream(filepath);
		wb = WorkbookFactory.create(fis);
		sheet = wb.getSheet(sheetname);

		numRows = sheet.getLastRowNum() + 1;
		// System.out.println("no of Rows : " + numRows);
		int numCols = sheet.getRow(0).getPhysicalNumberOfCells();
		// System.out.println("NO of columns : " + numCols);

		for (int i = 0; i < numCols; i++) {
			String columnValue = sheet.getRow(0).getCell(i).getStringCellValue();
			// System.out.println(columnValue);

			if (columnValue.equalsIgnoreCase(columnHeading)) {
				for (int j = 1; j < numRows; j++) {
					String currentValue = sheet.getRow(j).getCell(i).getStringCellValue();
					// System.out.println(currentValue);
					excelData.add(currentValue);
					// System.out.println(excelData);
				}

				break;
			}
		}
		fis.close();
		wb.close();
		return excelData;

	}

	public List<String> getallstringvaluefromattribute(List<WebElement> ele, String attrvalue) {
		List<String> dropdownvalues = new ArrayList<String>();
		for (WebElement list : ele) {
			System.out.println(list.getAttribute(attrvalue));
		}
		return dropdownvalues;
	}

	public String readexcelwithcolumnnindex(String filePath, String sheetname, int rowno, int colno)
			throws IOException, EncryptedDocumentException, InvalidFormatException {
		// System.out.println("start time-- >"+System.currentTimeMillis());
		String value = null;
//	XSSFWorkbook wb = new XSSFWorkbook(filePath);
		File file = new File(filePath);
		wb = WorkbookFactory.create(file);
		Sheet sheet = null;
		sheet = wb.getSheet(sheetname);

		value = sheet.getRow(rowno)
				.getCell(colno, org.apache.poi.ss.usermodel.Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
				.getStringCellValue();
		System.out.println("Value getting from the excel-------------------" + value);
		// System.out.println("end time-- >"+System.currentTimeMillis());

		wb.close();
		return value;
	}

	public List<String> addstringtolist(String str) {
		List<String> list = new ArrayList<String>();
		System.out.println(numRows);
		for (int i = 0; i < numRows; i++) {
			list.add(str);
		}
		return list;

	}

	public static void readlargeexcel(String filepath) throws IOException {
		try {
			File file1 = new File(filepath);
			System.out.println(file1.length());

			long start = System.currentTimeMillis();
			List<String> list = Files.lines(Paths.get(filepath), StandardCharsets.UTF_8)
					.filter(line -> line.contains("Deadpool")).collect(Collectors.toList());
			long end = System.currentTimeMillis();
			System.out.println(list);
			System.out.println(end - start);
		} catch (Exception e) {
			System.out.println("error");
		}
	}

	/**
	 * @author Shilpi Mangal
	 * @param expURL
	 * @description : This method verifies page navigation using url
	 */
	public void verifyPageNavigation(String expURL) {
		Driver.getinstance().waitForPageToBeReady();

		String actualURL = Driver.getDriver().getCurrentUrl();
		if (actualURL.contains(expURL)) {
			passedStep("Navigated to  " + expURL + " Page sucessfully");
		} else {
			failedStep("Navigated to  " + actualURL + " Page but expected Page to navigate  is " + expURL + ".");
		}
	}

	/**
	 * @author Shilpi Mangal
	 * @param expURL
	 * @description : This method verifies paginations if available
	 */
	public boolean verifyPagination() {
		boolean nextPage = false;
		try {
			Driver.getinstance().scrollingToBottomofAPage();
			if (Driver.getDriver().findElement(By.xpath("//a[text()='Next']")).isDisplayed())
				;
			nextPage = true;
			Driver.getDriver().findElement(By.xpath("//a[text()='Next']")).click();

		} catch (Exception e) {
			nextPage = false;
		}
		return nextPage;
	}
	/*
	 * public void setfilter(String filtervalue,String sheetname) throws
	 * EncryptedDocumentException, InvalidFormatException, IOException { File file =
	 * new File(System.getProperty("user.dir")+
	 * "\\src\\main\\java\\configurations\\GamesPage - ArticlesData - Copy.xlsx");
	 * wb = WorkbookFactory.create(file); // sheet = wb.getSheetAt(0); sheet =
	 * wb.getSheet(sheetname);
	 * 
	 * // String valuetofilter = "black-ops-4"; List<Row> rows = new ArrayList<>();
	 * System.out.println(sheet.getPhysicalNumberOfRows());
	 * 
	 * Map<String,List<Row>> rowbytitle = new HashMap<>();
	 * 
	 * 
	 * for(int i=1;i<sheet.getPhysicalNumberOfRows();i++) { // for(Row row : sheet)
	 * final Row row = sheet.getRow(i);
	 * 
	 * Cell cell = row.getCell(0); if(!(
	 * cell.getStringCellValue().equals(filtervalue))) { rows.add(row);
	 * 
	 * } } for(Row row : rowsToRemove) { sheet.removeRow(row); } //
	 * removeEmptyRows(sheet);
	 * 
	 * System.out.println("Adding filter on XLSX file Finished ...");
	 * FileOutputStream os = new FileOutputStream(System.getProperty("user.dir")+
	 * "\\src\\main\\java\\configurations\\Testing.xlsx"); wb.write(os);
	 * System.out.println("Writing on XLSX file Finished ..."); wb.close(); }
	 * 
	 */

	public Map<String, List<Row>> setfilter(String filePath, String sheetname)
			throws EncryptedDocumentException, InvalidFormatException, IOException, InterruptedException {
		Workbook wb = null;
		Sheet sheet = null;
		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);
		wb = WorkbookFactory.create(fis);
		sheet = wb.getSheet(sheetname);

		System.out.println(sheet.getPhysicalNumberOfRows());

		Map<String, List<Row>> rowsByTitle = new HashMap<String, List<Row>>();

		for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
			// for(Row row : sheet)
			final Row row = sheet.getRow(i);
			if (row != null) {
				Cell cell = row.getCell(0);
				if (rowsByTitle.containsKey(cell.getStringCellValue())) {
					rowsByTitle.get(cell.getStringCellValue()).add(row);
				} else {
					List<Row> rows = new ArrayList<>();
					rows.add(row);
					rowsByTitle.put(cell.getStringCellValue(), rows);
					System.out.println("Key Values :->" + cell.getStringCellValue());
				}
			}
		}
//rowsByTitle.get("Skylanders SuoerChargers").get(0).getCell(3)
		/*
		 * for(Row row : rowsToRemove) { sheet.removeRow(row); }
		 */
		// removeEmptyRows(sheet);

		System.out.println("Adding filter on XLSX file Finished ...");

//	FileOutputStream os = new FileOutputStream(System.getProperty("user.dir")+ "\\src\\main\\java\\configurations\\Testing.xlsx");
//	wb.write(os);
		fis.close();
		wb.close();
		return rowsByTitle;
	}

	/*
	 * public void setfilter(String filtervalue,String sheetname) throws
	 * EncryptedDocumentException, InvalidFormatException, IOException { File file =
	 * new File(System.getProperty("user.dir")+
	 * "\\src\\main\\java\\configurations\\GamesPage - ArticlesData - Copy.xlsx");
	 * wb = WorkbookFactory.create(file); // sheet = wb.getSheetAt(0); sheet =
	 * wb.getSheet(sheetname);
	 * 
	 * // String valuetofilter = "black-ops-4"; List<Row> rows = new ArrayList<>();
	 * System.out.println(sheet.getPhysicalNumberOfRows());
	 * 
	 * Map<String,List<Row>> rowbytitle = new HashMap<>();
	 * 
	 * 
	 * for(int i=1;i<sheet.getPhysicalNumberOfRows();i++) { // for(Row row : sheet)
	 * final Row row = sheet.getRow(i);
	 * 
	 * Cell cell = row.getCell(0); if(!(
	 * cell.getStringCellValue().equals(filtervalue))) { rows.add(row);
	 * 
	 * } } for(Row row : rowsToRemove) { sheet.removeRow(row); } //
	 * removeEmptyRows(sheet);
	 * 
	 * System.out.println("Adding filter on XLSX file Finished ...");
	 * FileOutputStream os = new FileOutputStream(System.getProperty("user.dir")+
	 * "\\src\\main\\java\\configurations\\Testing.xlsx"); wb.write(os);
	 * System.out.println("Writing on XLSX file Finished ..."); wb.close(); }
	 * 
	 */

	/**
	 * Method is to print the test step information in report in blue color
	 * 
	 * @author Shilpi
	 * @param message Message which needs to be printed in report
	 */
	public void stepInfoList(List<String> message) {
		Reporter.log("<font color='blue'>" + message + "</font>");
		Utility.info("Step info: " + message);
	}

	public List<String> readFile(String FilePath, String sheetname, String Columnname)
			throws FileNotFoundException, IOException {
		Map<String, Integer> requiredHeaders = new HashMap<>();
		List<String> rowdata = new ArrayList<>();
		FileInputStream file = new FileInputStream(new File(FilePath));
		Workbook workbook = new XSSFWorkbook(file);
		DataFormatter formatter = new DataFormatter();
		Sheet sheet = workbook.getSheet(sheetname);
		// Sheet sheet = workbook.getSheetAt(0);6
		for (Cell cell : sheet.getRow(0)) {
			requiredHeaders.put(cell.getStringCellValue(), cell.getColumnIndex());

			if (cell.getStringCellValue().equals(Columnname)) {
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					Row row = sheet.getRow(i);
					String a1 = formatter.formatCellValue(row.getCell(cell.getColumnIndex()));
					if (!(a1.length() == 0)) {
						String a = formatter
								.formatCellValue(row.getCell(requiredHeaders.get(cell.getStringCellValue())));
						rowdata.add(a);
					}
				}
				System.out.println(rowdata);
			}
		}
		workbook.close();
		return rowdata;
	}

	/**
	 * @author Shilpi This method verify is element is present or not
	 */
	public void ValidateElement_Presence(WebElement element, String ElementName) {
		SoftAssert sa = new SoftAssert();
		try {
			sa.assertEquals(element.getText(), ElementName);
			passedStep("Element is present -" + element.getText());

		} catch (Exception e) {
			failedStep("Element is not present");
			e.printStackTrace();
			sa.assertFalse(false);
		}
	}

	public void ClickHold(WebElement element) {
		Actions action = new Actions(Driver.getDriver());
		action.clickAndHold(element).build().perform();
		// you need to release the control from the test
		// actions.MoveToElement(element).Release();
	}

	public String verifyChildWindowandReturnUrl(WebElement element) throws Exception {

		String url = null;

		try {
			waitTillElemetToBeClickable(element);
			String parentWindow = Driver.getDriver().getWindowHandle();
			Actions a = new Actions(Driver.getDriver());
			Thread.sleep(1000);
			a.keyDown(Keys.CONTROL).click(element).keyUp(Keys.CONTROL).build().perform();
			new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(30))
					.until(ExpectedConditions.numberOfWindowsToBe(2));
			for (String window : Driver.getDriver().getWindowHandles()) {
				if (!parentWindow.equalsIgnoreCase(window)) {
					Driver.getDriver().switchTo().window(window);
				}
			}

			JavascriptExecutor j = (JavascriptExecutor) Driver.getDriver();
			j.executeScript("return document.readyState").toString().equals("complete");
			url = Driver.getDriver().getCurrentUrl();
			Driver.getDriver().close();
			Driver.getDriver().switchTo().window(parentWindow);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return url;
	}

	/**
	 * This method is used to wait for element till visibility of element.
	 * 
	 * @param driver
	 * @param attributeValue - provide locator value of element till it is visible
	 *                       on application and then click that element.
	 * @param waitTime       - provide maximum wait time in seconds for driver
	 */
	public boolean waitForElementToBeVisible(WebElement ele, int waitTime) {
		boolean flag = false;
		try {
			new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(waitTime))
					.until(ExpectedConditions.visibilityOf(ele));
			flag = true;
			return flag;
		} catch (Exception Ex) {
			return flag;
		}
	}

	public WebElement waitForElementPresent(final By by) {
		WebElement element;
		try {
			Driver.getDriver().manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // Nullify implicitlyWait()

			WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(5000));
			element = wait.until(ExpectedConditions.presenceOfElementLocated(by));

			Driver.getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); // Reset implicitlyWait
			return element; // Return the element

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void switchToNewWindow(WebElement causeOfNewWindow) {

		// Get Handles before opening new window
		Set<String> oldHandles = Driver.getDriver().getWindowHandles();

		// Click element to open new Window
		waitTillElemetToBeClickable(causeOfNewWindow);
		causeOfNewWindow.click();

		// Get Handles after opening new window
		Set<String> newHandles = Driver.getDriver().getWindowHandles();

		for (String handle : newHandles) {

			if (!oldHandles.contains(handle)) {
				Driver.getDriver().switchTo().window(handle);
			}

		}
	}

	public String verifyChildWindowandreturnheader(WebElement element, WebElement headertoverify) throws Exception {

		String header = null;
		try {
			waitTillElemetToBeClickable(element);
			String parentWindow = Driver.getDriver().getWindowHandle();
			Actions a = new Actions(Driver.getDriver());
			Thread.sleep(1000);
			a.keyDown(Keys.CONTROL).click(element).keyUp(Keys.CONTROL).build().perform();
			new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10))
					.until(ExpectedConditions.numberOfWindowsToBe(2));
			for (String window : Driver.getDriver().getWindowHandles()) {
				if (!parentWindow.equalsIgnoreCase(window)) {
					Driver.getDriver().switchTo().window(window);
				}
			}

			JavascriptExecutor j = (JavascriptExecutor) Driver.getDriver();
			j.executeScript("return document.readyState").toString().equals("complete");
			header = headertoverify.getText();
			Driver.getDriver().close();
			Driver.getDriver().switchTo().window(parentWindow);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return header;
	}

	public void fluentwait(int waitTimeout, int pollingEvery) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(Driver.getDriver())
				.withTimeout(Duration.ofSeconds(waitTimeout)).pollingEvery(Duration.ofSeconds(pollingEvery))
				.ignoring(NoSuchElementException.class);
	}

	public Map<String, String> verifyURLAndTitleOnNewOpenedTab(WebElement element) throws Exception {
		
		String url = null;
		String title = null;
		Map<String, String> newMap = new HashMap<String, String>();
		  try {
		waitTillElemetToBeClickable(element);
		String parentWindow = Driver.getDriver().getWindowHandle();
		Actions a = new Actions(Driver.getDriver());
		((JavascriptExecutor) Driver.getDriver()).executeScript("arguments[0].scrollIntoView();", element);
		a.keyDown(Keys.CONTROL).click(element).keyUp(Keys.CONTROL).build().perform();

		new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(200)).until(ExpectedConditions.numberOfWindowsToBe(2));
		for (String window : Driver.getDriver().getWindowHandles()) {
			if (!parentWindow.equalsIgnoreCase(window)) {
				Driver.getDriver().switchTo().window(window);
			}
		}

		// JavascriptExecutor j = (JavascriptExecutor) Driver.getDriver();
		// j.executeScript("return document.readyState").toString().equals("complete");
		Driver.getinstance().waitForPageToBeReady();
		url = Driver.getDriver().getCurrentUrl();
		title = Driver.getDriver().getTitle();
		newMap.put("URL", url);
		newMap.put("Title", title);

		Driver.getDriver().close();
		Driver.getDriver().switchTo().window(parentWindow);

     }
     catch(Exception e)
     {
    	 e.printStackTrace();
    	 stepInfo("Error while loading the page");
     }

		return newMap;
	}


	public Map<String, String> verifyURLAndTitleOnNewOpenedTab(WebElement element, WebElement popup) throws Exception {

		String url = null;
		String title = null;
		Map<String, String> newMap = new HashMap<String, String>();

		waitTillElemetToBeClickable(element);
		String parentWindow = Driver.getDriver().getWindowHandle();
		Actions a = new Actions(Driver.getDriver());
		a.keyDown(Keys.CONTROL).click(element).keyUp(Keys.CONTROL).build().perform();
		boolean isavailable = popup.isDisplayed();
		if (isavailable) {
			Driver.getDriver().switchTo().activeElement();
			waitTillElemetToBeClickable(popup);
			popup.click();
		} else {
			stepInfo("Confirm choice pop up is not available");
		}

		new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(60)).until(ExpectedConditions.numberOfWindowsToBe(2));
		for (String window : Driver.getDriver().getWindowHandles()) {
			if (!parentWindow.equalsIgnoreCase(window)) {
				Driver.getDriver().switchTo().window(window);
			}
		}

		JavascriptExecutor j = (JavascriptExecutor) Driver.getDriver();
		j.executeScript("return document.readyState").toString().equals("complete");
		Driver.getinstance().waitForPageToBeReady();
		url = Driver.getDriver().getCurrentUrl();
		title = Driver.getDriver().getTitle();
		newMap.put("URL", url);
		newMap.put("Title", title);

		Driver.getDriver().close();
		Driver.getDriver().switchTo().window(parentWindow);

		return newMap;
	}

	/**
	 * @author Shilpi Mangal
	 * @param expURL
	 * @throws InterruptedException
	 * @description : This method verifies paginations if available
	 */
	public List<String> AddEelementsWithPagination(List<WebElement> listofWebelements) {
		List<String> actuallist = new ArrayList<>();
		// boolean nextPage = false;
		actuallist = availableListofElements(listofWebelements);
		while (true) {
			try {
				Driver.getinstance().scrollingToBottomofAPage();
				if (Driver.getDriver().findElement(By.xpath("//a[text()='Next']")).isDisplayed())
					;
				// nextPage = true;
				Driver.getDriver().findElement(By.xpath("//a[text()='Next']")).click();
				actuallist.addAll(availableListofElements(listofWebelements));

			} catch (Exception e) {
				System.out.println("Next page is not available");
			}
			return actuallist;
		}

	}

	/**
	 * Purpose - to get current date and time
	 * 
	 * @return - String (returns date and time)
	 */
	public static String getCurrentDateTimeusingCalendar() {
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy:HH.mm.ss");
		System.out.println("Current date and time is " + formatter.format(currentDate.getTime()));
		return formatter.format(currentDate.getTime());
	}

	public String getCurrentDateTime(String formats) {
		// YYYY-MM-dd HH:mm:ss
		// Create object of SimpleDateFormat class and decide the format
		DateFormat dateFormat = new SimpleDateFormat(formats);

		// get current date time with Date()
		Date date = new Date();

		// Now format the date
		String date1 = dateFormat.format(date);

		// Print the Date
		System.out.println("Current date and time is " + date1);
		return date1;
	}

	public String getCurrentDateOnly(String dateformat) {
		// Create object of SimpleDateFormat class and decide the format
		DateFormat dateFormat = new SimpleDateFormat(dateformat);

		// get current date time with Date()
		Date date = new Date();

		// Now format the date
		String date1 = dateFormat.format(date);

		// Print the Date
		System.out.println("Current date and time is " + date1);
		return date1;
	}

	public void select_Option_In_DropDown_ByVisibleText(WebElement element, String sVisibleTextOptionToSelect) {
		try {
			Select select = new Select(element);
			select.selectByVisibleText(sVisibleTextOptionToSelect);

		} catch (NoSuchElementException e) {
			System.out.println("Option value not find in dropdown");

		}
	}

	public List<WebElement> getlistofalloptions_SelectTag(WebElement element) {

		Select select = new Select(element);
		List<WebElement> optionList = select.getOptions();
		optionList.remove(0);

		return optionList;
	}

	public static String getCurrentTimeUsingTimeZone(String zone) {
		Date currentTime = new Date();

		// Create object of SimpleDateFormat class and decide the format
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");

		// Creating PST timezone
		TimeZone Timezone = TimeZone.getTimeZone(zone);

		// setting pst timezone to formatter.
		dateFormat.setTimeZone(Timezone);

		// converting IST to PST
		String Time = dateFormat.format(currentTime);
		System.out.println("Time in mentioned timezone " + zone + "is : " + Time);

		return Time;
	}

	public String addminutestoCurrentTimeUsingTimeZone(String zone, int timeinmin) {
		// Date currentTime = new Date();

		// Create object of SimpleDateFormat class and decide the format
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");

		// Creating PST timezone
		TimeZone Timezone = TimeZone.getTimeZone(zone);

		// setting pst timezone to formatter.
		dateFormat.setTimeZone(Timezone);

		// converting IST to PST

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, timeinmin);
		String newTime = dateFormat.format(cal.getTime());
		System.out.println("Updated time in mentioned timezone  " + zone + " is : " + newTime);

		return newTime;
	}

	/**
	 * @author
	 * @Description reads excel column data
	 */
	public String readExcel_StringfromColumn(String filepath, String sheetname, String columnHeading) throws Exception {
		String currentValue = null;
		try {
			File file1 = new File(filepath);
			wb = WorkbookFactory.create(file1);
			sheet = wb.getSheet(sheetname);

			numRows = sheet.getLastRowNum() + 1;
			System.out.println("no of Rows : " + numRows);
			int numCols = sheet.getRow(0).getPhysicalNumberOfCells();
			System.out.println("NO of columns : " + numCols);

			for (int i = 0; i < numCols; i++) {
				String columnValue = sheet.getRow(0).getCell(i).getStringCellValue();

				if (columnValue.equalsIgnoreCase(columnHeading)) {
					for (int j = 1; j < numRows; j++) {
						currentValue = sheet.getRow(j).getCell(i).getStringCellValue();
						System.out.println(currentValue);
					}

					break;
				}
			}
		}

		catch (Exception e) {
			e.getMessage();
		}
		wb.close();
		return currentValue;

	}

	public String validateAccountRecoveryLink(WebElement recoverylink, WebElement header, Localecodes localecode)
			throws InterruptedException {
		String headertext = null;
		try {
			String parentWindow = Driver.getDriver().getWindowHandle();
			Actions a = new Actions(Driver.getDriver());
			a.keyDown(Keys.CONTROL).click(recoverylink).keyUp(Keys.CONTROL).build().perform();
			new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10))
					.until(ExpectedConditions.numberOfWindowsToBe(2));
			for (String window : Driver.getDriver().getWindowHandles()) {
				if (!parentWindow.equalsIgnoreCase(window)) {
					Driver.getDriver().switchTo().window(window);
				}
			}

			JavascriptExecutor j = (JavascriptExecutor) Driver.getDriver();
			j.executeScript("return document.readyState").toString().equals("complete");
			Driver.getinstance().waitForPageToBeReady();

			stepInfo(Driver.getDriver().getCurrentUrl());
			Assert.assertEquals("https://support.activision.com/" + localecode.toString() + "/account-recovery",
					Driver.getDriver().getCurrentUrl());

			headertext = header.getText();
			System.out.println(headertext + "-------------" + header.getText());
			Driver.getDriver().close();
			Driver.getDriver().switchTo().window(parentWindow);
		} catch (Exception e) {
			failedStep("Account recovery header is not displayed correctly ");

		}
		return headertext;
	}

	public void javascriptclick(WebElement ele) {
		JavascriptExecutor executor = (JavascriptExecutor) Driver.getDriver();
		executor.executeScript("arguments[0].scrollIntoView(true);", ele);
		executor.executeScript("arguments[0].click();", ele);
	}

	/**
	 * @author Shilpi
	 * 
	 */
	public boolean waitForElementToBeGone(WebElement element, int timeout) {
		boolean status = false;
		try {
			WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(timeout));
			status = wait.until(ExpectedConditions.invisibilityOf(element));
		} catch (Exception e) {
			Utility.info("Exception occured while waiting for element invisibilty");
			e.printStackTrace();
		}
		return status;
	}

}

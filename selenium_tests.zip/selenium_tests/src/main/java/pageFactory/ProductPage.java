package pageFactory;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Constants.Locales;
import commonUtilities.Utility;

public class ProductPage {

	BaseClass base;
	GamesPage gamespage;
	SupportHomePage hp;

	public List<WebElement> gamesarticlecategories() {
		return Driver.getDriver().findElements(By.xpath("//*[@id='prod-opts']/li/a/h3"));
	}

	@FindBy(xpath = "//h2[text()='What brings you here?']")
	public WebElement productheader;
	@FindBy(xpath = "//div[@class='prod-info']/h1")
	public WebElement gamesheader;
	int j;

	public List<WebElement> gameslist() {
		return Driver.getDriver().findElements(By.xpath("//*[contains(@class,'article-resource-section')][2]//div/a"));
	}

	String x = "//*[@id='";
	String y = "']/a";
	@FindBy(xpath = "//a[@class='view-all']")
	public WebElement viewallbutton;

	public List<WebElement> articlesnamelistinViewAll(int no) {
		return Driver.getDriver().findElements(By.xpath("//*[@id='" + no + "']//li/a/h3"));
	}

	public List<WebElement> articlesnamelist() {
		return Driver.getDriver().findElements(By.xpath("//*[@class='option active']/div/ul//li/a/h3"));
	}

	public List<WebElement> articlesnamesubtitlelistinViewAll(int no) {
		return Driver.getDriver().findElements(By.xpath("//*[@id='" + no + "']//li/a/h3/following-sibling::p"));
	}

	public List<WebElement> articlesnamesubtitlelist() {
		return Driver.getDriver().findElements(By.xpath("//*[@class='option active']/div/ul//li/a/p"));
	}

	public List<WebElement> articlelistinViewAll() {
		return Driver.getDriver().findElements(By.xpath("//*[@class='option active view-all-cont']/div/ul//li/a/h3"));

	}

	@FindBy(xpath = "//a[text()='Next']")
	public WebElement Nextbutton;
	@FindBy(xpath = "//a[text()='Last']")
	public WebElement Lastbutton;
	@FindBy(xpath = "//div[@class='active']")
	public WebElement Articlesctiveclass;
	@FindBy(xpath = "//div[@class='inactive']")
	public WebElement Articlesinctiveclass;
	@FindBy(xpath = "//div[@class='option active']")
	public WebElement Articlesclass;

	public List<WebElement> classlist() {
		return Driver.getDriver().findElements(By.xpath("//div[@class='prod-list-links']//a"));
	}

	public List<WebElement> activeclasslist() {
		return Driver.getDriver().findElements(By.xpath("//div[@class='prod-list-links']//div[@class='active']//a"));
	}

	public List<WebElement> pagesizelist() {
		return Driver.getDriver().findElements(By.xpath("//ul[@class='pagination']/li/a"));
	}

	@FindBy(xpath = "//div[@class='prod-info']/h3/a")
	public WebElement CTALevel1;
	@FindBy(xpath = "//img[@alt='Activision Support Shield']/following-sibling::h1")
	public WebElement accountrecoveryheader;
	@FindBy(xpath = "//div[@class='feature-header-inner']/h1")
	public WebElement CTALevel1header;

	public List<WebElement> productinfo1() {
		return Driver.getDriver().findElements(By.xpath("//*[@id='prod-opts']/li/a/h3"));
	}

	@FindBy(xpath = "//a[text()='First']")
	public WebElement Firstbutton;

	public ProductPage() throws Exception {
		PageFactory.initElements(Driver.getDriver(), this);
		base = new BaseClass();
		hp = new SupportHomePage();
		gamespage = new GamesPage();
	}

	public void validateHeaderLinkURLForAllGames(String localename, Localecodes localecode, Locales name)
			throws Exception {
		SoftAssert sa = new SoftAssert();
		base.passedStep(localename + "----> Locale is selected successfully and navigates to Games page");

		Workbook wb = null;
		Sheet sheet = null;
		File file = new File(Utility.GamesHomePagefilePath);
		FileInputStream fis = new FileInputStream(file);
		wb = WorkbookFactory.create(fis);

		sheet = wb.getSheet(localename);
		base.stepInfo("Size of the games list is -------->" + gamespage.gameslist().size());
		String explogo = sheet.getRow(1)
				.getCell(0, org.apache.poi.ss.usermodel.Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
				.getStringCellValue();
		String actualgameslogo = gamespage.GamesLogoheader.getText().toString();
		sa.assertEquals(explogo, actualgameslogo);
		if (actualgameslogo.equals(explogo)) {
			base.passedStep("Actual Header of the page is displayed correctly---------->" + actualgameslogo);
		} else {
			base.failedStep("Expected Header of the page is not displayed correctly------->" + explogo);
		}

		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			Driver.getinstance().waitForPageToBeReady();
			String expheader = sheet.getRow(i + 1).getCell(1).getStringCellValue();
			String expurlref = sheet.getRow(i + 1).getCell(2).getStringCellValue();
			String exparticlecategories = sheet.getRow(i + 1)
					.getCell(3, org.apache.poi.ss.usermodel.Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
					.getStringCellValue();
			String expCTAleveheader = sheet.getRow(i + 1)
					.getCell(4, org.apache.poi.ss.usermodel.Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
					.getStringCellValue();

			System.out.println("----" + explogo + "------" + expheader + "----------" + expurlref + "--------"
					+ exparticlecategories);

			String actualgamename = gamespage.allgames().get(i).getAttribute("data-info");
			String actualurl = gamespage.allgamesurl().get(i).getAttribute("href");
			gamespage.allgames().get(i).click();

			base.passedStep(actualgamename + "--Game is clicked and navigated to product page");
			base.waitTillElemetToBeClickable(gamesheader);
			base.stepInfo("Title of the Page is-----" + Driver.getDriver().getTitle());
			String gamesheaderactual = gamesheader.getText();
			base.stepInfo("Actual Header of page is--- " + gamesheader.getText());

			sa.assertEquals(actualurl, expurlref, "URL of the page is not displayed as expected ");
			if (actualurl.equals(expurlref)) {
				base.passedStep(
						"URL of the page is displayed as expected " + expurlref + "---Actual is-->" + actualurl);
			} else {
				base.failedStep("URL of the page is not displayed as expected " + expurlref + "---But displayed as-->"
						+ actualurl);
				sa.fail();
			}
			sa.assertEquals(gamesheaderactual, expheader, "Header of the page is not displayed as expected ");
			if (gamesheaderactual.equals(expheader)) {
				base.passedStep(
						"Header of the page is displayed as expected " + expheader + "---Actual is -->" + expheader);
			} else {
				base.failedStep("Header of the page is not displayed as expected " + expheader
						+ "---But displayed as-->" + gamesheaderactual);
				sa.fail();
			}
			if (exparticlecategories != null && !exparticlecategories.trim().isEmpty()) {
				base.stepInfo("Scrolling to Games options");
				Driver.getinstance().scrollingToElementofAPage(gamesheader);
				List<String> expvalues = base.convertstringintolist(exparticlecategories);
				List<String> actualoptions = base.availableListofElements(gamesarticlecategories());

				sa.assertEquals(expvalues, actualoptions);
				if (expvalues.containsAll(actualoptions)) {
					base.passedStep("String with comma separated values-->" + expvalues + "  is matching with list"
							+ actualoptions);
				} else {
					base.failedStep("String with comma separated values-->" + expvalues + "  is not matching with list"
							+ actualoptions);
					sa.fail();
				}

			} else if (exparticlecategories == null || exparticlecategories.trim().isEmpty()) {

				base.passedStep("Options of the page are displayed as blank or empty ");
			} else {
				base.failedStep("Options of the page is not displayed as expected ");
				sa.fail();
			}

			if (Driver.getinstance().isElementAvailable(CTALevel1, 5)) {
				base.waitTillElemetToBeClickable(CTALevel1);
				sa.assertTrue(CTALevel1.isDisplayed(), "Product info not dispalyed under header");
				String parentWindow = Driver.getDriver().getWindowHandle();
				CTALevel1.click();
				// try {
				Driver.getinstance().waitForPageToBeReady();
				if (!(Driver.getDriver().findElements(By.id("login"))).isEmpty()) {
					sa.assertTrue(
							Driver.getDriver().getCurrentUrl().contains("https://s.activision.com/activision/login"));

					base.switchToNewWindow(hp.SSOSupportlink);
					Driver.getinstance().waitForPageToBeReady();
					GamesPage ghp = new GamesPage();
					ghp.selectRegionByName(Locales.Ko);

				}

				else if (base.waitForElementToBeVisible(accountrecoveryheader, 2)) {
					sa.assertTrue(accountrecoveryheader.isDisplayed());
					base.stepInfo(Driver.getDriver().getCurrentUrl());
					if (localename.equals("United States")) {
						sa.assertEquals("https://support.activision.com/" + "account-recovery",
								Driver.getDriver().getCurrentUrl());
					} else {
						sa.assertEquals("https://support.activision.com/" + localecode.toString() + "/account-recovery",
								Driver.getDriver().getCurrentUrl());
					}
					if (accountrecoveryheader.isDisplayed()) {
						base.passedStep("Product Info is displayed correctly ");
					} else {
						base.failedStep("Product Info is not displayed correctly ");
						sa.fail();
					}

				}

				else if (base.waitForElementToBeVisible(CTALevel1header, 2)) {
					sa.assertTrue(CTALevel1header.isDisplayed());
					String actualheader = CTALevel1header.getText();
					sa.assertEquals(actualheader, expCTAleveheader);
					gamespage.selectRegionByName(name);
				} else {
					for (String window : Driver.getDriver().getWindowHandles()) {
						if (!parentWindow.equalsIgnoreCase(window)) {
							Driver.getDriver().switchTo().window(window);
						}
					}

					JavascriptExecutor j = (JavascriptExecutor) Driver.getDriver();
					j.executeScript("return document.readyState").toString().equals("complete");
					String url = Driver.getDriver().getCurrentUrl();
					Driver.getDriver().close();
					Driver.getDriver().switchTo().window(parentWindow);

					sa.assertTrue(url.contains(expCTAleveheader));
					gamespage.selectRegionByName(name);
				}
				// } catch (Exception e) {
				// base.passedStep("Article Categories Call to Action Level1 is not available
				// for this game");

				// }
			}
			Driver.getinstance().waitForPageToBeReady();
			gamespage.gameslink.click();
		}
		fis.close();
		wb.close();
		sa.assertAll();
	}

	public void validateArticles(String idno, String localecode, String gamename) throws Exception {
		SoftAssert sa = new SoftAssert();
		List<String> GameTitlelist = new ArrayList<>();
		List<String> Articleurl = new ArrayList<>();
		List<String> Call = new ArrayList<>();
		List<String> Articlesubtitle = new ArrayList<>();
		Thread.sleep(1000);
	
		Map<String, List<Row>> gamesdata = new HashMap<>();
		try {
			gamesdata = base.setfilter(Utility.GamesArticlesfilePath, localecode);
			Thread.sleep(1000);
			if (gamesdata.isEmpty() || gamesdata == null) {
				base.stepInfo("Game name is not available in sheet");
			} else {
				for (String key : gamesdata.keySet()) {
					System.out.println("keys-->:" + key);
				}
				List<Row> getgamesbyrows = gamesdata.get(gamename);
				Thread.sleep(1000);
				for (Row game : getgamesbyrows) {
					GameTitlelist.add(game.getCell(0).toString());
					Articleurl.add(game.getCell(1).toString());
					Call.add(game.getCell(2).toString());
					Articlesubtitle.add(game.getCell(3).toString());
				}
			}
		}

		catch (Exception e) {
			base.stepInfo("Game name is not matching");
		}

		base.stepInfo("Validation for Games Articles started------------");

		Driver.getinstance().waitForPageToBeReady();
		base.stepInfo("Size of the games is -------->" + gameslist().size());

		String gamesxpath = x + idno + y;
		WebElement games = Driver.getDriver().findElement(By.xpath(gamesxpath));
		String hrefurllink = Driver.getDriver().findElement(By.xpath(gamesxpath)).getAttribute("href");

		base.stepInfo("Click on games icon" + hrefurllink);
		base.waitTillElemetToBeClickable(games);
		Driver.getinstance().scrollingToElementofAPage(games);
		base.waitTillElemetToBeClickable(games);
		games.click();

		Driver.getinstance().scrollingToBottomofAPage();
		List<String> ArticlenamesActuallist = new ArrayList<String>();
		List<String> ArticlesubtitleActuallist = new ArrayList<String>();

		if (Driver.getinstance().isElementAvailable(viewallbutton, 5)) {
			base.waitTillElemetToBeClickable(viewallbutton);
			base.stepInfo("Click on 'ViewAll' button");
			viewallbutton.click();

			for (int k = 1; k <= articlelistinViewAll().size(); k++) {
				for (WebElement element : articlesnamelistinViewAll(k)) {
					ArticlenamesActuallist.add(element.getText().trim().toString());
				}
				for (WebElement element : articlesnamesubtitlelistinViewAll(k)) {
					ArticlesubtitleActuallist.add(element.getText().trim().toString());
				}
				Driver.getinstance().scrollingToBottomofAPage();
				if (!(Driver.getinstance().isElementAvailable(Lastbutton, 5))) {
					sa.assertFalse(false);
					Utility.info("Lastbutton is not displayed as expected");
					Driver.getinstance().scrollPageToTop();
					break;
				} else {
					sa.assertTrue(true);
					Driver.getinstance().scrollingToBottomofAPage();
					Thread.sleep(1000);
					Nextbutton.click();
					Driver.getinstance().scrollPageToTop();
				}
			}
		} else {
			ArticlesubtitleActuallist = base.availableListofElements(articlesnamesubtitlelist());
			for (WebElement s1 : articlesnamelist()) {
				final String[] s1Split = s1.getText().split("- Updated");

				ArticlenamesActuallist.add(s1Split[0].trim());
			}
		}

		base.stepInfo("Getting list of all articles--------------->");
		base.stepInfo("List of all articles from excel sheet--------------->" + Call);
		base.stepInfo("List of all articles from application -------------->" + ArticlenamesActuallist);
		base.stepInfo("List size for all articles from excel -----------" + Call.size());
		base.stepInfo("List size for all articles from Application -----------" + ArticlenamesActuallist.size());
		base.stepInfo("List size for all sub-articles from excel-----------" + Articlesubtitle.size());
		base.stepInfo("List of all sub-articles from excel sheet--------------->" + Articlesubtitle);
		base.stepInfo("List of all sub-articles from application -------------->" + ArticlesubtitleActuallist);
		base.stepInfo("List size for all sub-articles from Application -----------" + ArticlesubtitleActuallist.size());

		base.stepInfo("Comparing article names list");
		// if (ArticlenamesActuallist.size() == Call.size()) {
		// Collections.sort(ArticlenamesActuallist);
		// Collections.sort(Call);
		sa.assertEquals(ArticlenamesActuallist, Call);
		if (ArticlenamesActuallist.equals(Call)) {
			base.passedStep("List is matching");
		} else {
			base.failedStep("Article title List is not matching");
			sa.fail();
		}

		base.stepInfo("Comparing article sub title names list");
		// Collections.sort(ArticlesubtitleActuallist);
		// Collections.sort(Articlesubtitle);
		sa.assertEquals(ArticlesubtitleActuallist, Articlesubtitle);
		if (ArticlesubtitleActuallist.equals(Articlesubtitle)) {
			base.passedStep("List is matching");

		} else {
			base.failedStep("Article sub title List is not matching");
			sa.fail();
		}

		try {
			Firstbutton.click();
		} catch (Exception e) {
			base.stepInfo("First button is not available");
		}
		List<String> Joinedlist = new ArrayList<>();
		List<String> list1 = new ArrayList<>();
		System.out.println("___________________________________");
		while (true) {
			list1 = clickAllArticles();
			Joinedlist.addAll(list1);
			Driver.getinstance().scrollingToBottomofAPage();
			if (!(Driver.getinstance().isElementAvailable(Lastbutton, 5))) {
				sa.assertFalse(false);
				Utility.info("Lastbutton is not displayed as expected");
				Driver.getinstance().scrollPageToTop();
				break;
			} else {
				sa.assertTrue(true);
				Driver.getinstance().scrollingToBottomofAPage();
				Thread.sleep(1000);
				Nextbutton.click();
				Driver.getinstance().scrollPageToTop();
			}
		}

		base.stepInfo("List of all articles url from application--------------->" + Joinedlist);
		base.stepInfo("List size of articles from application -----------" + Joinedlist.size());
		base.stepInfo("List of all articles url from excel sheet--------------->" + Articleurl);
		base.stepInfo("List size of articles from excel-----------" + Articleurl.size());

		if (Joinedlist.containsAll(Articleurl)) {
			sa.assertTrue(CollectionUtils.isEqualCollection(Joinedlist, Articleurl));
			base.passedStep("URL is matching");
		} else {
			base.failedStep("URL is not matching");
			sa.fail();
		}
		sa.assertAll();
	}

	public List<String> clickAllArticles() throws Exception {

		List<String> Articleurllist = new ArrayList<String>();
		try {
			if (Articlesctiveclass.isDisplayed()) {
				for (int c = 0; c < activeclasslist().size(); c++) {
					Driver.getinstance().waitForPageToBeReady();
					base.waitTillElemetToBeClickable(activeclasslist().get(c));
					String parentWindow = Driver.getDriver().getWindowHandle();
					Actions a = new Actions(Driver.getDriver());
					Thread.sleep(1000);
					a.keyDown(Keys.CONTROL).click(activeclasslist().get(c)).keyUp(Keys.CONTROL).build().perform();
					new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10))
							.until(ExpectedConditions.numberOfWindowsToBe(2));
					for (String window : Driver.getDriver().getWindowHandles()) {
						if (!parentWindow.equalsIgnoreCase(window)) {
							Driver.getDriver().switchTo().window(window);
						}
					}

					JavascriptExecutor j = (JavascriptExecutor) Driver.getDriver();
					j.executeScript("return document.readyState").toString().equals("complete");
					String url = Driver.getDriver().getCurrentUrl();
					Articleurllist.add(url);
					Driver.getinstance().waitForPageToBeReady();
					Driver.getDriver().close();
					Driver.getDriver().switchTo().window(parentWindow);
				}
			}
		} catch (Exception e) {
			if (Articlesclass.isDisplayed()) {
				for (int c = 0; c < classlist().size(); c++) {
					Driver.getinstance().waitForPageToBeReady();
					base.waitTillElemetToBeClickable(classlist().get(c));
					String parentWindow = Driver.getDriver().getWindowHandle();
					Actions a = new Actions(Driver.getDriver());
					Thread.sleep(1000);
					a.keyDown(Keys.CONTROL).click(classlist().get(c)).keyUp(Keys.CONTROL).build().perform();
					new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10))
							.until(ExpectedConditions.numberOfWindowsToBe(2));
					for (String window : Driver.getDriver().getWindowHandles()) {
						if (!parentWindow.equalsIgnoreCase(window)) {
							Driver.getDriver().switchTo().window(window);
						}
					}
					JavascriptExecutor j = (JavascriptExecutor) Driver.getDriver();
					j.executeScript("return document.readyState").toString().equals("complete");
					String url = Driver.getDriver().getCurrentUrl();
					Articleurllist.add(url);
					Driver.getinstance().waitForPageToBeReady();
					Driver.getDriver().close();
					Driver.getDriver().switchTo().window(parentWindow);
				}
			}
		}
		return Articleurllist;
	}
}

package pageFactory;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.Constants.SortOptions;
import commonUtilities.Utility;

public class GamesPage {

	BaseClass base;

	@FindBy(xpath = "//*[@id='navbartest']/ul/li[1]/a")
	public WebElement gameslink;
	@FindBy(xpath = "//h1[@class='games-text']")
	public WebElement GamesLogoheader;
	@FindBy(xpath = "//div[@class='myIcon']/following-sibling::p")
	public List<WebElement> gameslist;
	@FindBy(xpath = "//div[@class='myIcon']/ancestor::a")
	public WebElement producturls;

	public List<WebElement> gameslist() {
		return Driver.getDriver().findElements(By.xpath("//*[contains(@class,'article-resource-section')][2]//div/a"));
	}

	public List<WebElement> productslist() {
		return Driver.getDriver().findElements(By.xpath("//div[@class='myIcon']"));
	}

	@FindBy(xpath = "//button[@class='btn btn-primary dropdown-toggle btn-sm view-button']")
	public WebElement dropdownmenubutton;
	@FindBy(xpath = "//div[@class='new-sso-region']")
	public WebElement localeselector;
	@FindBy(xpath = "//ul[@class='locale-list']//a")
	public List<WebElement> localelist;
	@FindBy(xpath = "//a[@title='Choose your region']")
	public WebElement regionselected;

	public WebElement selectregions(String regiontext) {
		return Driver.getDriver().findElement(By.xpath("//ul[@class='locale-list']//a[@title='" + regiontext + "']"));
	}

	@FindBy(xpath = "//span[@class='view-button']")
	public WebElement viewbutton;

	public List<WebElement> viewdropdown() {
		return Driver.getDriver().findElements(By.xpath(
				"//button[@class='btn btn-primary dropdown-toggle btn-sm view-button']/following-sibling::ul/li/a"));
	}

	@FindBy(xpath = "//span[@class='sort-button']")
	public WebElement sortbutton;

	public List<WebElement> selectgamesfromlist() {
		return Driver.getDriver().findElements(By.xpath("//div[@class='myIcon']"));
	}

	public List<WebElement> OtherElements() {
		return Driver.getDriver().findElements(
				By.xpath("//div[@class='article-resource-block col-lg-15 col-md-3 col-xs-6 thumb other']"));
	}

	public List<WebElement> ViewbyGamename(String name) {
		return Driver.getDriver()
				.findElements(By.xpath("//div[@class='myIcon']/following-sibling::p[contains(.,'" + name + "')]"));
	}

	public List<WebElement> sortdropdown() {
		return Driver.getDriver().findElements(By.xpath(
				"//button[@class='btn btn-primary dropdown-toggle btn-sm sort-button']/following-sibling::ul/li/a"));
	}

	public List<WebElement> regionlist() {
		return Driver.getDriver().findElements(By.cssSelector(".region"));
	}

	public List<WebElement> allgames() {
		return Driver.getDriver().findElements(
				By.xpath("//div[starts-with(@class,'article-resource-block col-lg-15 col-md-3 col-xs-6')]"));
	}

	public List<WebElement> allgamesurl() {
		return Driver.getDriver().findElements(
				By.xpath("//div[starts-with(@class,'article-resource-block col-lg-15 col-md-3 col-xs-6')]/a"));
	}

	public List<WebElement> serverstatus() {
		return Driver.getDriver().findElements(By.xpath("//*[@class='server-status-inner']//span"));
	}

	public WebElement serverstatus(String name) {
		return Driver.getDriver()
				.findElement(By.xpath("//*[@class='server-status-inner']/a[text()='" + name + "']/span"));
	}

	public WebElement selectgamebyname(String name) {
		return Driver.getDriver().findElement(By.xpath("//div[@alt='" + name + "']"));
	}

	public WebElement serverplatforms(String name) {
		return Driver.getDriver().findElement(By.xpath("//*[@class='server-status-inner']/a[text()='" + name + "']"));
	}

	public GamesPage() throws Exception {

		PageFactory.initElements(Driver.getDriver(), this);
		base = new BaseClass();
		gameslink.click();
		Driver.getinstance().waitForPageToBeReady();
	}

	public void selectRegionByName(Locales name) throws Exception {

		base.javascriptclick(localeselector);
		localeselector.click();
		Thread.sleep(1000);

		base.passedStep("Local selector icon is clicked and opened");
		Driver.getinstance().waitForPageToBeReady();
		try {
			selectregions(name.toString()).click();
			base.passedStep(name + "----> Locale is clicked and selected successfully");
		} catch (Exception e) {
			base.stepInfo("Locale is already selected");
		}
	}

	public void validateViewDropdown(String gamename, String columnname, String gamecount, String sheetname)
			throws InterruptedException, FileNotFoundException, IOException {
		SoftAssert sa = new SoftAssert();
		List<String> actualgames = new ArrayList<String>();
		List<String> expgames = new ArrayList<String>();

		Driver.getinstance().waitForPageToBeReady();
		base.stepInfo("Clicked on View button");
		viewbutton.click();
		base.passedStep("View button is clicked");
		Thread.sleep(2000);

		for (int i = 0; i < viewdropdown().size(); i++) {
			if (viewdropdown().get(i).getText().contains(gamename.toUpperCase()))
				viewdropdown().get(i).click();
		}
		base.passedStep("Game is selected from the list --" + gamename);
		Thread.sleep(2000);
		Driver.getinstance().waitForPageToBeReady();
		expgames = base.readFile(Utility.GamesSorting, sheetname, columnname);

		for (WebElement element : selectgamesfromlist()) {

			if (gamename.equalsIgnoreCase("Call") || gamename.equalsIgnoreCase("Crash")
					|| gamename.equalsIgnoreCase("Skylanders")) {
				if (element.getAttribute("alt").contains(gamename))
					actualgames.add(element.getAttribute("alt"));
			}
		}
		if (gamename.equalsIgnoreCase("Other")) {
			for (WebElement list : OtherElements()) {
				if (list.getAttribute("data-info").contains("thumb other"))
					;
				actualgames.add(list.getAttribute("data-info").toString());
			}

		}
		int expgamescount = Integer.parseInt(gamecount);
		int actualcount = ViewbyGamename(gamename).size();
		base.stepInfo("Count of the selected games-->" + actualcount);
		if (actualcount == expgamescount) {
			sa.assertTrue(CollectionUtils.isEqualCollection(expgames, actualgames));
			base.passedStep("Expected games are matching with actual games" + actualgames);

			sa.assertEquals(expgamescount, actualcount);
			base.passedStep("Expected Count of games is matching");
		} else {
			base.failedStep("Expected games are not matching with actual games" + actualgames);
			base.failedStep("Count of games are not matching");
		}

		sa.assertAll();
	}

	public void ValidateSortDropdown(String sheetname) throws Exception {
		SoftAssert sa = new SoftAssert();
		List<String> OriginalSortOrder = new ArrayList<String>();
		List<String> afterSortList = new ArrayList<String>();
		Thread.sleep(1000);
		Driver.getinstance().waitForPageToBeReady();

		for (int i = 0; i < productslist().size(); i++) {
			OriginalSortOrder.add(productslist().get(i).getAttribute("alt").toString());
			Driver.getinstance().scrollingToElementofAPage(productslist().get(i));
		}
		// try {
		for (SortOptions type : SortOptions.class.getEnumConstants()) {
			if (type.toString().equalsIgnoreCase(SortOptions.TitleATOZ.toString())) {
				base.stepInfo("Validate sorting for TitleAtoZ--------------->");
				afterSortList = clickingSortOptionandTakeAfterSortList(2);
				base.stepInfo("Ascending List coming from application----->" + afterSortList);
				base.stepInfo("\n");
				Collections.sort(OriginalSortOrder, String.CASE_INSENSITIVE_ORDER);
				base.stepInfo("Ascending List coming from coded sorted list --->" + OriginalSortOrder);
				sa.assertEquals(OriginalSortOrder, afterSortList, "Sorting order failed");
				if(OriginalSortOrder.equals(afterSortList))
				{
				base.passedStep("Sorting order is displayed as expected for 'TitleAtoZ'");
				}
				else 
				{
					base.failedStep("Sorting order is not displayed as expected for 'TitleAtoZ'");
					sa.fail();
				}
			}
			if (type.toString().equalsIgnoreCase(SortOptions.TitleZTOA.toString())) {
				base.stepInfo("Validate sorting for TitleZtoA--------------->");
				afterSortList = clickingSortOptionandTakeAfterSortList(3);
				base.stepInfo("Ascending List coming from application----->" + afterSortList);
				base.stepInfo("\n");
				Collections.sort(OriginalSortOrder, String.CASE_INSENSITIVE_ORDER);
				Collections.reverse(OriginalSortOrder);
				base.stepInfo("Ascending List coming from coded sorted list --->" + OriginalSortOrder);
				sa.assertEquals(OriginalSortOrder, afterSortList, "Sorting order failed");
				if(OriginalSortOrder.equals(afterSortList))
				{
				base.passedStep("Sorting order is displayed as expected for 'TitleZtoA'");
				}
				else 
				{
					base.failedStep("Sorting order is displayed as expected for 'TitleZtoA'");
					sa.fail();
				}
				base.passedStep("Sorting order is not displayed as expected for 'TitleZtoA'");
			}
			if (type.toString().equalsIgnoreCase(SortOptions.NTO.toString())) {
				base.stepInfo("Validate sorting for Newest to Oldest--------------->");
				OriginalSortOrder = base.readExcelColumnData(Utility.GamesSorting, sheetname, "Newest to Oldest");
				base.stepInfo("Getting list of all sort data for Newest to Oldest--------------->");
				base.stepInfo("<--------------------------->");
				base.stepInfoList(OriginalSortOrder);
				base.stepInfo("List size----" + OriginalSortOrder.size());

				afterSortList = clickingSortOptionandTakeAfterSortList(0);
				base.stepInfo("\n");
				base.stepInfoList(afterSortList);
				base.stepInfo("List size----" + afterSortList.size());
				sa.assertEquals(OriginalSortOrder, afterSortList, "Sorting order failed");
				if(OriginalSortOrder.equals(afterSortList))
				{
				base.passedStep("Sorting order is displayed as expected for 'Newest to Oldest'");
				}
				else 
				{
					base.failedStep("Sorting order is not displayed as expected for 'Newest to Oldest'");
					sa.fail();
				}
			}
			if (type.toString().equalsIgnoreCase(SortOptions.OTN.toString())) {
				base.stepInfo("Validate sorting for Oldest to Newest--------------->");
				OriginalSortOrder = base.readExcelColumnData(Utility.GamesSorting, sheetname, "Newest to Oldest");
				Collections.reverse(OriginalSortOrder);
				base.stepInfo("Getting list of all sort data for Oldest to Newest--------------->");
				base.stepInfoList(OriginalSortOrder);
				base.stepInfo("List size----" + OriginalSortOrder.size());
				afterSortList = clickingSortOptionandTakeAfterSortList(1);
				base.stepInfoList(afterSortList);
				base.stepInfo("List size----" + afterSortList.size());
				sa.assertEquals(OriginalSortOrder, afterSortList, "Sorting order failed");
				if(OriginalSortOrder.equals(afterSortList))
				{
				base.passedStep("Sorting order is displayed as expected for 'Oldest to Newest'");
				}
				else 
				{
					base.failedStep("Sorting order is not displayed as expected for 'Oldest to Newest'");
					sa.fail();
				}
			
			}
		}
		/*
		 * } catch (Exception e) { e.printStackTrace(); e.getMessage();
		 * base.failedStep("Sorting order failed in catch block"); }
		 */
		sa.assertAll();
	}

	public List<String> clickingSortOptionandTakeAfterSortList(int index) throws Exception {
		List<String> afterSortList = new ArrayList<String>();
		Driver.getinstance().scrollPageToTop();
		sortbutton.click();
		Thread.sleep(2000);
		sortdropdown().get(index).click();
		Thread.sleep(2000);
		for (int i = 0; i < productslist().size(); i++) {
			// System.out.println(productslist().get(i).getAttribute("alt").toString());
			afterSortList.add(productslist().get(i).getAttribute("alt").toString());
			Driver.getinstance().scrollingToElementofAPage(productslist().get(i));
		}
		return afterSortList;
	}

	public void sortingWithViewOptions(String gamename, String columnname, String gamecount, String sheetname)
			throws Exception {
		SoftAssert sa = new SoftAssert();
		List<String> sortListFromExcel = new ArrayList<String>();
		List<String> OriginalListBeforeSorting = new ArrayList<String>();
		List<String> actualListAfterSorting = new ArrayList<String>();

		Driver.getinstance().waitForPageToBeReady();
		viewbutton.click();
		for (int i = 0; i < viewdropdown().size(); i++) {
			if (viewdropdown().get(i).getText().contains(gamename.toUpperCase()))
				viewdropdown().get(i).click();
		}
		base.passedStep("Game is selected from the list --" + gamename);
		Thread.sleep(2000);
		Driver.getinstance().waitForPageToBeReady();
		OriginalListBeforeSorting = addEelementsWithAltAttribute(gamename);

		for (SortOptions type : SortOptions.class.getEnumConstants()) {
			if (type.toString().equalsIgnoreCase(SortOptions.TitleATOZ.toString())) {
				base.stepInfo("----------------Validation for Title A to Z--------------->");
				Driver.getinstance().scrollPageToTop();
				sortbutton.click();
				sortdropdown().get(2).click();
				actualListAfterSorting = addEelementsWithAltAttribute(gamename);
				// base.verifyOriginalSortOrder(actualListAfterSorting, actualListAfterSorting,
				// "Ascending", true);

				Collections.sort(OriginalListBeforeSorting, String.CASE_INSENSITIVE_ORDER);
				base.stepInfo("List from A to Z after sort---->" + actualListAfterSorting);
				sa.assertEquals(OriginalListBeforeSorting, actualListAfterSorting, "Failed");
			}
			if (type.toString().equalsIgnoreCase(SortOptions.TitleZTOA.toString())) {
				base.stepInfo("----------------Validation for Title Z to A--------------->");
				Driver.getinstance().scrollPageToTop();
				sortbutton.click();
				sortdropdown().get(3).click();
				actualListAfterSorting = addEelementsWithAltAttribute(gamename);
				// base.verifyOriginalSortOrder(actualListAfterSorting, actualListAfterSorting,
				// "Descending", true);
				Collections.sort(OriginalListBeforeSorting, String.CASE_INSENSITIVE_ORDER);
				Collections.reverse(OriginalListBeforeSorting);
				base.stepInfo("List from A to Z after sort---->" + actualListAfterSorting);
				sa.assertEquals(OriginalListBeforeSorting, actualListAfterSorting, "Failed");

			}
			if (type.toString().equalsIgnoreCase(SortOptions.NTO.toString())) {
				base.stepInfo("----------------Validation for  Newest to Oldest--------------->");
				sortListFromExcel = base.readFile(Utility.GamesSorting, sheetname, columnname);
				base.stepInfo("Getting list of all sort data for Newest to Oldest--------------->");
				base.stepInfoList(sortListFromExcel);
				base.stepInfo("<--------------------------->");
				base.stepInfo("List size----" + sortListFromExcel.size());
				Driver.getinstance().scrollPageToTop();
				sortbutton.click();
				sortdropdown().get(0).click();
				actualListAfterSorting = addEelementsWithAltAttribute(gamename);
				sa.assertEquals(sortListFromExcel, actualListAfterSorting, "Sorting order failed");
				base.passedStep("Sorting order passed for oldest to newest");
			}
			if (type.toString().equalsIgnoreCase(SortOptions.OTN.toString())) {
				base.stepInfo("----------------Validation for  Oldest to Newest---------------->");
				sortListFromExcel = base.readFile(Utility.GamesSorting, sheetname, columnname);

				Collections.reverse(sortListFromExcel);
				base.stepInfo("Getting list of all sort data for Oldest to Newest--------------->");
				base.stepInfoList(sortListFromExcel);
				base.stepInfo("List size----" + sortListFromExcel.size());
				Driver.getinstance().scrollPageToTop();
				sortbutton.click();
				sortdropdown().get(1).click();
				actualListAfterSorting = addEelementsWithAltAttribute(gamename);

				sa.assertEquals(sortListFromExcel, actualListAfterSorting, "Sorting order failed");
				base.passedStep("Sorting order passed for newest to oldest");
			}
		}
		sa.assertAll();
	}

	public void selectViewAndSort(String gameName, int index) throws Exception {
		base.stepInfo("Clicked on View button");
		viewbutton.click();
		base.passedStep("View button is clicked");
		Thread.sleep(2000);

		for (WebElement options : viewdropdown()) {

			if (options.getText().equals(gameName)) {
				Driver.getinstance().waitAndClick(options, 15);
				base.passedStep("Game is selected from the list --" + gameName);
				Thread.sleep(2000);
				Driver.getinstance().waitForPageToBeReady();
			}

			clickingSortOptionandTakeAfterSortList(index);
		}

	}

	public List<String> addEelementsWithAltAttribute(String gamename) {
		List<String> actualgames = new ArrayList<String>();

		for (WebElement element : selectgamesfromlist()) {

			if (gamename.equalsIgnoreCase("Call") || gamename.equalsIgnoreCase("Crash")
					|| gamename.equalsIgnoreCase("Skylanders")) {
				if (element.getAttribute("alt").contains(gamename))
					actualgames.add(element.getAttribute("alt"));
			}
		}
		if (gamename.equalsIgnoreCase("Other")) {
			for (WebElement list : OtherElements()) {
				if (list.getAttribute("data-info").contains("thumb other"))
					;
				actualgames.add(list.getAttribute("data-info").toString());
			}

		}
		return actualgames;
	}

	public String selectsheetbyRegion(Locales name) throws Exception {
		String sheetname = null;

		if (name.equals(Locales.Deutschland)) {
			sheetname = "German";
		}
		if (name.equals(Locales.Suomi)) {
			sheetname = "All EN except Australia";
		}
		if (name.equals(Locales.Norge)) {
			sheetname = "All EN except Australia";
		}
		if (name.equals(Locales.Australia)) {
			sheetname = "EN - Australia";
		}
		if (name.equals(Locales.US)) {
			sheetname = "All EN except Australia";
		}
		if (name.equals(Locales.UK)) {
			sheetname = "All EN except Australia";
		}
		if (name.equals(Locales.España)) {
			sheetname = "Spanish";
		}
		if (name.equals(Locales.Luxembourg)) {
			sheetname = "All French";
		}
		if (name.equals(Locales.BEFR)) {
			sheetname = "All French";
		}
		if (name.equals(Locales.France)) {
			sheetname = "All French";
		}
		if (name.equals(Locales.Italia)) {
			sheetname = "Italian";
		}
		if (name.equals(Locales.Brasil)) {
			sheetname = "Portuguese";
		}
		if (name.equals(Locales.Ja)) {
			sheetname = "Japanese";
		}
		if (name.equals(Locales.CN)) {
			sheetname = "Simplified Chinese";
		}
		if (name.equals(Locales.TwZh)) {
			sheetname = "Traditional Chinese";
		}
		if (name.equals(Locales.Ko)) {
			sheetname = "Korean";
		}

		return sheetname;
	}

}

package pageFactory;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.Locales;
import commonUtilities.SendMail;
import commonUtilities.Utility;

public class OnlineServicesHomePage extends BaseClass {

	BaseClass base;

	SendMail mail;
	SupportHomePage homepage;
	GamesPage gp;
	EmailTemplates email;
	List<String> expplatformtitle = null;

	@FindBy(xpath = "//div[@class='row bannerTitle']//h1")
	public WebElement OnlineServicesHeader;
	@FindBy(xpath = "//*[@class='right carousel-control']")
	public WebElement connectiontiprightcontrol;
	@FindBy(xpath = "//*[@class='twitter-link']")
	public WebElement twitterlink;
	@FindBy(className = "game-dropdown")
	public WebElement gameselectordropdown;
	@FindBy(id = "platform-status")
	public WebElement gamestitle;
	@FindBy(id = "event-status")
	public WebElement eventsstatus;
	@FindBy(id = "start-date")
	public WebElement eventstartdate;
	@FindBy(id = "end-date")
	public WebElement eventenddate;
	@FindBy(id = "eventnumber")
	public WebElement eventnumber;

	public List<WebElement> platfoalerttitlermnames() {
		return Driver.getDriver()
				.findElements(By.xpath("//*[@id='homePage:theTemplate:theForm:serverStatusGS']//li/span[2]"));
	}

	/*
	 * @FindBy(xpath = "//*[@id='marquee123']/div[2]//a") public WebElement
	 * alerttitle;
	 */
	public List<WebElement> alerttitles() {
		return Driver.getDriver().findElements(By.xpath("//*[@id='marquee123']/div[2]//a"));
	}

	public List<WebElement> connectiontipsitemlist() {
		return Driver.getDriver().findElements(By.xpath("//*[@class='carousel-inner']/div/div"));
	}

	public List<WebElement> platformnetworks() {
		return Driver.getDriver().findElements(By.xpath("//div[contains(@class,'platformStatusBox')]//a/p"));
	}

	public List<WebElement> platformnetworkslinks() {
		return Driver.getDriver().findElements(By.xpath("//div[contains(@class,'platformStatusBox')]//a"));
	}

	public WebElement gamesserverstatus(String platformname) {
		return Driver.getDriver().findElement(By.xpath("//*[text()='" + platformname + "']/following-sibling::span"));
	}

	public WebElement Eventlinktext(String platformname) {
		return Driver.getDriver().findElement(By.xpath("//*[text()='" + platformname + "']/following-sibling::a"));
	}

	public List<WebElement> platformnames() {
		return Driver.getDriver()
				.findElements(By.xpath("//*[@id='homePage:theTemplate:theForm:serverStatusGS']//li/span[2]"));
	}

	@FindBy(xpath = "//*[@id='homePage:theTemplate:theForm:serverStatusGS']//li/a")
	public WebElement eventdetails;
	@FindBy(xpath = "//*[@id='table-one']/tr/td[1]")
	public WebElement eventgametitles;

	/*
	 * public List<WebElement> eventgametitles() { return
	 * Driver.getDriver().findElements(By.xpath("//*[@id='table-one']/tr/td[1]")); }
	 * public List<WebElement> eventplatforms() { return
	 * Driver.getDriver().findElements(By.xpath("//*[@id='table-one']/tr/td[2]")); }
	 */

	@FindBy(xpath = "//*[@id='table-two']//td[2]")
	public WebElement eventupdates;
	@FindBy(xpath = "//*[@id='alert-carousel']//a[@class='right carousel-control']")
	public WebElement alertrightarrow;
	@FindBy(xpath = "//*[@id='table-one']/tr/td[2]")
	public WebElement eventplatforms;

	public WebElement eventdetailsonmaintenance(int no) {
		return Driver.getDriver().findElement(By.xpath("//*[@id='maintenanceList']/li/div/div[2]/text()[" + no + "]"));
	}

	@FindBy(xpath = "//*[@class='maintenanceBox__group']/div[2]/span")
	public WebElement eventdetailsonmaintenance;

	public OnlineServicesHomePage() throws Exception {
		Driver.getinstance();
		PageFactory.initElements(Driver.getDriver(), this);
		base = new BaseClass();
		homepage = new SupportHomePage();
		gp = new GamesPage();
		mail = new SendMail();
		email = new EmailTemplates();
		homepage.OnlineServies.click();
		// expplatformtitle= base.readExcelColumnData(Utility.OnlineServices,
		// "EventData", "PlatformsTitle");

	}

	public void triggerEmailDefcon1(String platformtitle) throws Exception, MessagingException {
		Map<String, String> emaildetails = new HashMap<String, String>();
		base.stepInfo("String title for the game is :--->" + platformtitle);
		emaildetails = email.Defcon1(platformtitle);
		mail.sendmail1(emaildetails.get("Subject"), emaildetails.get("Mailbody"));
		Thread.sleep(10000);
	}

	public void triggerEmailDefcon2(String platformtitle) throws Exception, MessagingException {
		Map<String, String> emaildetails = new HashMap<String, String>();
		base.stepInfo("String title for the game is :--->" + platformtitle);
		emaildetails = email.Defcon2(platformtitle);
		mail.sendmail1(emaildetails.get("Subject"), emaildetails.get("Mailbody"));
		Thread.sleep(10000);
	}

	public void triggerEmailDefcon3(String platformtitle) throws Exception, MessagingException {
		Map<String, String> emaildetails = new HashMap<String, String>();
		base.stepInfo("String title for the game is :--->" + platformtitle);
		emaildetails = email.Defcon3(platformtitle);
		mail.sendmail1(emaildetails.get("Subject"), emaildetails.get("Mailbody"));
		Thread.sleep(10000);
	}

	public void triggerEmailDefcon4(String platformtitle) throws Exception, MessagingException {
		Map<String, String> emaildetails = new HashMap<String, String>();
		base.stepInfo("String title for the game is :--->" + platformtitle);
		emaildetails = email.Defcon4(platformtitle);
		mail.sendmail1(emaildetails.get("Subject"), emaildetails.get("Mailbody"));
		Thread.sleep(10000);
	}

	public void triggerEmailDefcon5(String platformtitle) throws Exception, MessagingException {
		Map<String, String> emaildetails = new HashMap<String, String>();
		base.stepInfo("String title for the game is :--->" + platformtitle);
		emaildetails = email.Defcon5(platformtitle);
		mail.sendmail1(emaildetails.get("Subject"), emaildetails.get("Mailbody"));
		Thread.sleep(10000);
	}

	public void triggerEmailFinalIncident(String platformtitle) throws Exception, MessagingException {
		Map<String, String> emaildetails = new HashMap<String, String>();
		base.stepInfo("String title for the game is :--->" + platformtitle);
		emaildetails = email.FinalIncident(platformtitle);
		mail.sendmail1(emaildetails.get("Subject"), emaildetails.get("Mailbody"));
		Thread.sleep(15000);
	}

	public void verifyPlatformStatus(Locales name, String GamesinDropDown, String Platforms, String Gamesfromgamepage,
			String GamesPlatforms) throws Exception {
		SoftAssert sa = new SoftAssert();
		/*
		 * List<String> expgames= base.readExcelColumnData(Utility.OnlineServices,
		 * "EventData", "GamesinDropDown"); List<String> expplatforms=
		 * base.readExcelColumnData(Utility.OnlineServices, "EventData", "Platforms");
		 * List<String> expgamesingamepage=
		 * base.readExcelColumnData(Utility.OnlineServices, "EventData",
		 * "Gamesfromgamepage"); List<String> expplatformsgames=
		 * base.readExcelColumnData(Utility.OnlineServices, "EventData",
		 * "GamesPlatforms");
		 * 
		 * //List<WebElement> optionsList =
		 * base.getlistofalloptions_SelectTag(gameselectordropdown); List<String>
		 * expeventupdate= base.readExcelColumnData(Utility.OnlineServices,
		 * name.toString(), "EventDetails"); List<String> expeventupdate=
		 * base.readExcelColumnData(Utility.OnlineServices, name.toString(),
		 * "EventDetails");
		 * 
		 */
		String expeventtextlink = base.readexcelwithcolumnnindex(Utility.OnlineServices, name.toString(), 1, 0);
		String expeventupdate = base.readexcelwithcolumnnindex(Utility.OnlineServices, name.toString(), 1, 1);

		Driver.getinstance().waitForPageToBeReady();
		base.stepInfo("Select game name from drop down list");
		base.select_Option_In_DropDown_ByVisibleText(gameselectordropdown, GamesinDropDown);
		Driver.getinstance().waitForPageToBeReady();
		base.waituntilelementtobevisible(gamesserverstatus(Platforms), 30);

		if (gamesserverstatus(Platforms).getText().toString().equals("ONLINE")) {

			base.waituntilelementtobevisible(gamesserverstatus(Platforms), 10);
			// Driver.getDriver().navigate().refresh();
			base.waituntilelementtobevisible(gamesserverstatus(Platforms), 10);
			sa.assertEquals(gamesserverstatus(Platforms).getText().toString(), "ONLINE");
			sa.assertTrue(gamesserverstatus(Platforms).getAttribute("class").equals("online"));
			base.passedStep("Platform status is showing as" + gamesserverstatus(Platforms).getText().toString());
		}

		else {

			// for(WebElement e: gamesserverstatus(expplatforms.get(i)))
			// {
			base.waitTillElemetToBeClickable(gamesserverstatus(Platforms));
			if (gamesserverstatus(Platforms).getText().toString().equals("OUTAGE")) {

				sa.assertEquals(gamesserverstatus(Platforms).getText().toString(), "OUTAGE");
				sa.assertTrue(gamesserverstatus(Platforms).getAttribute("class").equals("offline"));
				base.passedStep("Server status is showing as down" + gamesserverstatus(Platforms).getText().toString());
			} else if (gamesserverstatus(Platforms).getText().toString().equals("LIMITED")) {
				base.waituntilelementtobevisible(gamesserverstatus(Platforms), 10);
				System.out.println(gamesserverstatus(Platforms).getAttribute("class"));
				// Driver.getDriver().navigate().refresh();
				base.waituntilelementtobevisible(gamesserverstatus(Platforms), 10);
				sa.assertEquals(gamesserverstatus(Platforms).getText().toString(), "LIMITED");
				sa.assertTrue(gamesserverstatus(Platforms).getAttribute("class").equals("warning"));
			}

			if (gamesserverstatus(Platforms).getText().toString().equals("OUTAGE")
					|| gamesserverstatus(Platforms).getText().toString().equals("LIMITED")) {
				sa.assertEquals(expeventtextlink, Eventlinktext(Platforms).getText());
				base.passedStep("Event details is showing as expected" + Eventlinktext(Platforms).getText());

				base.stepInfo("Click on event link");
				eventdetails.click();
				base.passedStep("User is naviagted to event details page");
				System.out.println(email.currentdateupdated);
				sa.assertEquals(eventnumber.getText(), email.currentdateupdated);
				if (eventnumber.getText().equals(email.currentdateupdated)) {
					base.passedStep("Event number is showing as expected-->" + eventnumber.getText());
				} else {
					base.failedStep("Event number is not showing correct-->" + eventnumber.getText());
					sa.fail();
				}

				base.passedStep("Event start date is showing as expected-->" + eventstartdate.getText());
				String date = base.getCurrentDateOnly("MMMMM dd, yyyy");
				System.out.println(date);
				String date1 = date + " " + "AM PST";
				sa.assertTrue(eventstartdate.getText().contains(date1));

				base.stepInfo("Validate event details");
				Driver.getinstance().scrollingToElementofAPage(eventgametitles);

				// for(int i=0;i<expplatformtitle.size();i++)
				// {
				Driver.getinstance().waitForPageToBeReady();
				base.waitTillElemetToBeClickable(eventgametitles);
				System.out.println("Game names from application------>:" + eventgametitles.getText());
				// base.stepInfo("Game names from
				// application------>:"+eventgametitles().get(i).getText().toString());
				base.stepInfo("Game names from excel------>:" + Gamesfromgamepage);
				base.stepInfo("Platform name from application------>:" + eventplatforms.getText());
				base.stepInfo("Platform name from excel------>:" + GamesPlatforms);

				// sa.assertEquals(eventgametitles.getText(),Gamesfromgamepage);
				base.passedStep("Game title on event's page is showing as expected-->" + eventgametitles.getText());

				sa.assertEquals(eventplatforms.getText(), Platforms);
				base.passedStep("Platform title on event's page is showing as expected-->" + eventplatforms.getText());

				sa.assertEquals(expeventupdate, eventupdates.getText());
				base.passedStep(
						"Event Update details on event's page is showing as expected-->" + eventupdates.getText());

				Driver.getinstance().scrollPageToTop();
				base.stepInfo("Click on Games link");
				homepage.games.click();
				base.waitTillElemetToBeClickable(gp.selectgamebyname(Gamesfromgamepage));
				gp.selectgamebyname(Gamesfromgamepage).click();
				base.passedStep(Gamesfromgamepage + "--Game is selected");

				base.passedStep("Navigated to Product page");

				if (gp.serverstatus().size() > 0) {
					base.waitTillElemetToBeClickable(gp.serverplatforms(GamesPlatforms));

					sa.assertEquals(gp.serverstatus(GamesPlatforms).getAttribute("class"), "ico outage");
					base.passedStep("Server status is showing as expected-->"
							+ gp.serverstatus(GamesPlatforms).getAttribute("class"));

					sa.assertEquals(gp.serverplatforms(GamesPlatforms).getText(), GamesPlatforms);
					base.passedStep(
							"Platform is showing as expected-->" + gp.serverplatforms(GamesPlatforms).getText());

					base.stepInfo("Click on platform link from games page");
					gp.serverplatforms(GamesPlatforms).click();

					for (WebElement e : alerttitles()) {
						if (e.getText().contains(GamesinDropDown)) {
							base.waitTillElemetToBeClickable(e);
							System.out.println(e.getText());
							// sa.assertTrue(e.getText().contains(GamesinDropDown));
							base.passedStep("User is navigated to Online services page and alert title is displayed "
									+ e.getText());
							base.passedStep("Alert title is showing game name");
						} else {
							alertrightarrow.click();
						}
					}
				} else {
					base.passedStep("Platforms are not showing for this game on product page");
					homepage.OnlineServies.click();
					base.select_Option_In_DropDown_ByVisibleText(gameselectordropdown, GamesinDropDown);
					Driver.getinstance().waitForPageToBeReady();
				}

			}
		}

		 sa.assertAll();
	}

	public void validateFinalIncidentDetails() {
		SoftAssert sa = new SoftAssert();
		base.stepInfo("Verify recently resolved all title details");
		String startdate = eventdetailsonmaintenance(1).toString();
		String enddate = eventdetailsonmaintenance(2).getText();
		String eventid = eventdetailsonmaintenance(3).getText();
		DateFormat dateFormat = new SimpleDateFormat("MMMMM dd, yyyy");
		String formattedstartdate = dateFormat.format(email.pstdatetime);
		String formattedenddate = dateFormat.format(email.pstEnddatetime);
		System.out.println(email.currentdateupdated);
		System.out.println(eventid);
		sa.assertEquals(email.currentdateupdated, eventid);
		sa.assertTrue(startdate.contains(formattedstartdate));
		sa.assertTrue(enddate.contains(formattedenddate));
		sa.assertAll();
	}

	public void verifyConnectionTips(Locales name) throws Exception {
		SoftAssert sa = new SoftAssert();
		List<String> expitemtips = base.readExcelColumnData(Utility.OnlineServicesTips, name.toString(),
				"Carouselcaption");
		base.stepInfo("List of all data from excel" + expitemtips);

		for (int i = 0; i < connectiontipsitemlist().size(); i++) {
			base.waitTillElemetToBeClickable(connectiontipsitemlist().get(i));
			base.stepInfo("Data from application------>:" + connectiontipsitemlist().get(i).getText().toString());
			base.stepInfo("Data from excel------>:" + expitemtips.get(i).trim());
			Driver.getinstance().scrollingToElementofAPage(connectiontipsitemlist().get(i));
			sa.assertEquals(connectiontipsitemlist().get(i).getText(), expitemtips.get(i).trim());

			if (connectiontipsitemlist().get(i).getText().equals(expitemtips.get(i).trim())) {
				base.passedStep("Connection tips values are displayed as expected");
			} else {
				base.failedStep("Connection tips values are not displayed as expected");
				sa.fail();
			}
			connectiontiprightcontrol.click();
		}
		sa.assertAll();
	}

	public void verifyFollowonTwitter() throws Exception {
		SoftAssert sa = new SoftAssert();
		Map<String, String> nameMap = new HashMap<String, String>();

		String url = "https://twitter.com/ATVIAssist";
		String title = "Activision Support (@ATVIAssist) / Twitter";
		nameMap = base.verifyURLAndTitleOnNewOpenedTab(twitterlink, null);
		System.out.println(nameMap.get("URL"));
		System.out.println(nameMap.get("Title"));

		sa.assertEquals(nameMap.get("URL"), url);
		sa.assertEquals(nameMap.get("Title"), title);
		if (nameMap.get("URL").equals(url)) {
			base.passedStep("Actual urls" + nameMap.get("URL") + "------------------"
					+ "is matching with the Url after navigating to link--->" + url);
		} else {
			base.failedStep("Actual urls" + nameMap.get("URL") + "------------------"
					+ "is not matching with the Url after navigating to link-->" + url);
			sa.fail();

		}

		if (nameMap.get("Title").equals(title)) {
			base.passedStep("Actual title--->" + nameMap.get("Title") + "------------------"
					+ "is matching with the title after navigating to link--->" + title);
		} else {
			base.failedStep("Actual title---->" + nameMap.get("Title") + "------------------"
					+ "is not matching with the title after navigating to link-->" + title);
			sa.fail();
		}
        sa.assertAll();
	}

	public void checkServerNetworkStatus() throws Exception {
		SoftAssert sa = new SoftAssert();
		List<String> expplatforms = base.readExcelColumnData(Utility.OnlineServicesAllData, "PlatformNetwork",
				"Platform");
		List<String> expplatformsurl = base.readExcelColumnData(Utility.OnlineServicesAllData, "PlatformNetwork",
				"URL");
		String actualurl = null;

		for (int i = 0; i < platformnetworks().size(); i++) {
			base.waitTillElemetToBeClickable(platformnetworks().get(i));
			base.stepInfo("Platform names from application------>:" + platformnetworks().get(i).getText().toString());
			base.stepInfo("Platform name from excel------>:" + expplatforms.get(i).trim());
			base.stepInfo("Platform URL from excel------>:" + expplatformsurl.get(i).trim());

			Driver.getinstance().scrollingToElementofAPage(platformnetworks().get(i));
			if (platformnetworks().get(i).getText().equals(expplatforms.get(i))) {
				actualurl = base.verifyChildWindowandReturnUrl(platformnetworkslinks().get(i));
				sa.assertEquals(actualurl, expplatformsurl.get(i).trim());
			}

			if (actualurl.equals(expplatformsurl.get(i).trim())) {
				base.passedStep("Platform network urls are loaded properly");
			} else {
				base.failedStep("Platform network urls are not loaded properly");
				sa.fail();
			}
		}
		sa.assertAll();
	}

	public void gamesstatus(Locales name) throws Exception {
		SoftAssert sa = new SoftAssert();

		Workbook wb = null;
		Sheet sheet = null;
		File file = new File(Utility.OnlineServicesGamesData);
		FileInputStream fis = new FileInputStream(file);
		wb = WorkbookFactory.create(fis);

		sheet = wb.getSheet(name.toString());

		base.stepInfo("Verifying default game title on Online Services page");

		String gamesdefaulttitle = sheet.getRow(1)
				.getCell(0, org.apache.poi.ss.usermodel.Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
				.getStringCellValue();
		String actualgamestitle = gamestitle.getAttribute("data-game-title");
		if (gamesdefaulttitle.equals(actualgamestitle)) {
			base.passedStep("Game title is displayed correctly" + actualgamestitle);
		} else {
			base.failedStep("Game title is not displayed correctly" + actualgamestitle);
			sa.fail();
		}
		List<WebElement> optionsList = base.getlistofalloptions_SelectTag(gameselectordropdown);
		List<String> actualgamelist = base.availableListofElements(optionsList);
		List<String> expectedgamelist = base.readExcelColumnData(Utility.OnlineServicesGamesData, name.toString(),
				"Title List");

		sa.assertEquals(actualgamelist, expectedgamelist);
		if (actualgamelist.equals(expectedgamelist)) {
			base.passedStep("Games list is displayed correctly" + actualgamelist);
		} else {
			base.failedStep("Games list is not displayed correctly" + actualgamelist);
			sa.fail();
		}

		for (int i = 1; i < sheet.getLastRowNum(); i++) {
			Driver.getinstance().waitForPageToBeReady();
			String expgameslist = sheet.getRow(i).getCell(1).getStringCellValue();
			String expplatforms = sheet.getRow(i)
					.getCell(2, org.apache.poi.ss.usermodel.Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
					.getStringCellValue();

			base.stepInfo("----" + expgameslist + "------" + expplatforms + "----------");

			base.waitTillElemetToBeClickable(optionsList.get(i));

			base.select_Option_In_DropDown_ByVisibleText(gameselectordropdown, expgameslist);
			base.passedStep("Selected game from drop down list-->" + expgameslist);
			Driver.getinstance().waitForPageToBeReady();

			base.waitTillElemetToBeClickable(gamestitle);
			List<String> expplatforms1 = base.convertstringintolist(expplatforms);
			List<String> actualplatforms1 = base.availableListofElements(platformnames());
			sa.assertEquals(expplatforms1, actualplatforms1);
			if (expplatforms1.equals(actualplatforms1)) {
				base.passedStep("Games actual platform list---" + actualplatforms1 + "--is matching with expected"
						+ "platforms list" + expplatforms1);
			} else {
				base.failedStep("Games actual platform list---" + actualplatforms1 + "--is not matching with expected"
						+ "platforms list" + expplatforms1);
				sa.fail();
			}
		}

		sa.assertAll();
	}

	public void selectLocaleAndVerifyStatus(Locales code, String GamesinDropDown, String Platforms,
			String Gamesfromgamepage, String GamesPlatforms) throws Exception {
		gp.selectRegionByName(code);
		verifyPlatformStatus(code, GamesinDropDown, Platforms, Gamesfromgamepage, GamesPlatforms);
	}
}

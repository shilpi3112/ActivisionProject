package pageFactory;

import java.util.HashMap;
import java.util.Map;

import base.BaseClass;
import commonUtilities.Utility;

public class EmailTemplates {
	BaseClass base = new BaseClass();
	public String currentdate = base.getCurrentDateOnly("YYYYMMdd");
	public String pstdatetime = base.getCurrentTimeUsingTimeZone("PST");
	public String edtdatetime = base.getCurrentTimeUsingTimeZone("America/New_York");
	public String utcdatetime = base.getCurrentTimeUsingTimeZone("UTC");
	public String pstEnddatetime = base.addminutestoCurrentTimeUsingTimeZone("PST", 40);
	public String edtEnddatetime = base.addminutestoCurrentTimeUsingTimeZone("America/New_York", 40);
	public String utcEnddatetime = base.addminutestoCurrentTimeUsingTimeZone("UTC", 40);
	public String currentdateupdated = currentdate + Utility.randomnumberAppender();

	Map<String, String> nameMap = new HashMap<String, String>();

	public Map<String, String> Defcon1(String platformtitle) {
		System.out.println("Updated time in mentioned timezone  " + currentdateupdated);
		String subject = "Demonware Initial Incident Notification: [#" + currentdateupdated
				+ "] User Drop on Listed Title";
		String mailbody = "Start: " + utcdatetime + " UTC\r\n" + "        " + edtdatetime + "  EDT\r\n" + "        "
				+ pstdatetime + " PDT\r\n" + "\r\n" + "\r\n"
				+ "        This issue is currently ongoing and under investigation, but no end time is yet certain.\r\n"
				+ "\r\n" + "\r\n" + "        Affected Titles/Services:\r\n" + "          * " + platformtitle + "\r\n"
				+ "\r\n" + "\r\n" + "        Summary:\r\n" + "\r\n"
				+ "        We detected a user drop for the titles and/or services listed. Our operations team is investigating this issue. We will provide further updates as they become available.\r\n"
				+ "\r\n" + "\r\n" + "        This is a DEFCON 1 incident.\r\n" + "\r\n" + "        Regards,\r\n"
				+ "\r\n" + "        Demonware Monitoring\r\n" + "        --\r\n" + "        Demonware Liveops\r\n" + "";
		nameMap.put("Subject", subject);
		nameMap.put("Mailbody", mailbody);

		return nameMap;
	}

	public Map<String, String> Defcon2(String platformtitle) {

		String subject = "Demonware Updated Incident Notification: [#" + currentdateupdated
				+ "] User Drop on Listed Title";
		String mailbody = "Start: " + utcdatetime + " UTC\r\n" + "        " + edtdatetime + " EDT\r\n" + "        "
				+ pstdatetime + " PDT\r\n" + "\r\n" + "\r\n"
				+ "        This issue is currently ongoing and under investigation, but no end time is yet certain.\r\n"
				+ "\r\n" + "\r\n" + "        Affected Titles/Services:\r\n" + "          * " + platformtitle + "\r\n"
				+ "\r\n" + "\r\n" + "        Summary:\r\n" + "\r\n"
				+ "        We detected a user drop for the titles and/or services listed. Our operations team is investigating this issue. We will provide further updates as they become available.\r\n"
				+ "\r\n" + "\r\n" + "        This is a DEFCON 2 incident.\r\n" + "\r\n" + "        Regards,\r\n"
				+ "\r\n" + "        Demonware Monitoring\r\n" + "        --\r\n" + "        Demonware Liveops\r\n" + "";
		nameMap.put("Subject", subject);
		nameMap.put("Mailbody", mailbody);

		return nameMap;

	}

	public Map<String, String> Defcon3(String platformtitle) {
		String subject = "Demonware Updated Incident Notification: [#" + currentdateupdated
				+ "] User Drop on Listed Title";
		String mailbody = "        Start: " + utcdatetime + " UTC\r\n" + "        " + edtdatetime + " EDT\r\n"
				+ "        " + pstdatetime + " PDT\r\n" + "\r\n" + "\r\n"
				+ "        This issue is currently ongoing and under investigation, but no end time is yet certain.\r\n"
				+ "\r\n" + "\r\n" + "        Affected Titles/Services:\r\n" + "          * " + platformtitle + "\r\n"
				+ "\r\n" + "\r\n" + "        Summary:\r\n" + "\r\n"
				+ "        We detected a user drop for the titles and/or services listed. Our operations team is investigating this issue. We will provide further updates as they become available.\r\n"
				+ "\r\n" + "\r\n" + "        This is a DEFCON 3 incident.\r\n" + "\r\n" + "        Regards,\r\n"
				+ "\r\n" + "        Demonware Monitoring\r\n" + "        --\r\n" + "        Demonware Liveops\r\n"
				+ "\r\n" + "";
		nameMap.put("Subject", subject);
		nameMap.put("Mailbody", mailbody);

		return nameMap;
	}

	public Map<String, String> Defcon4(String platformtitle) {
		String subject = "Demonware Updated Incident Notification: [#" + currentdateupdated
				+ "] User Drop on Listed Title";

		String mailbody = "        Start: " + utcdatetime + "  UTC\r\n" + "        " + edtdatetime + "  EDT\r\n"
				+ "        " + pstdatetime + " PDT\r\n" + "\r\n" + "\r\n"
				+ "        This issue is currently ongoing and under investigation, but no end time is yet certain.\r\n"
				+ "\r\n" + "\r\n" + "        Affected Titles/Services:\r\n" + "          * " + platformtitle + "\r\n"
				+ "\r\n" + "\r\n" + "        Summary:\r\n" + "\r\n"
				+ "        We detected a user drop for the titles and/or services listed. Our operations team is investigating this issue. We will provide further updates as they become available.\r\n"
				+ "\r\n" + "\r\n" + "        This is a DEFCON 4 incident.\r\n" + "\r\n" + "        Regards,\r\n"
				+ "\r\n" + "        Demonware Monitoring\r\n" + "        --\r\n" + "        Demonware Liveops\r\n" + "";
		nameMap.put("Subject", subject);
		nameMap.put("Mailbody", mailbody);

		return nameMap;
	}

	public Map<String, String> Defcon5(String platformtitle) {
		String subject = "Demonware Updated Incident Notification: [#" + currentdateupdated
				+ "] User Drop on Listed Title";
		String mailbody = "                    Update sent by Demonware Monitoring at " + utcEnddatetime + " UTC\r\n"
				+ "                    " + edtEnddatetime + " EDT\r\n" + "                    " + pstEnddatetime
				+ " PDT\r\n" + "\r\n"
				+ "                    Online services are now operating normally. User counts have fully recovered.\r\n"
				+ "\r\n" + "\r\n"
				+ "                    This message is an update to the incident notification which follows:\r\n"
				+ "\r\n" + "                    Start: " + utcdatetime + " UTC\r\n" + "                    "
				+ edtdatetime + " EDT\r\n" + "                    " + pstdatetime + " PDT\r\n" + "\r\n"
				+ "                    End: " + utcEnddatetime + " UTC\r\n" + "                    " + edtEnddatetime
				+ " EDT\r\n" + "                    " + pstEnddatetime + " PDT\r\n" + "\r\n"
				+ "                    Duration: 0:40:00\r\n" + "\r\n" + "\r\n"
				+ "                    Affected Titles/Services:\r\n" + "                       * " + platformtitle
				+ "\r\n" + "\r\n" + "                    Summary:\r\n" + "\r\n"
				+ "                    We detected a user drop for the titles and/or services listed. Our operations team is investigating this issue. We will provide further updates as they become available.\r\n"
				+ "\r\n" + "\r\n" + "                    This is a DEFCON 5 incident.\r\n" + "\r\n" + "\r\n"
				+ "                    Regards,\r\n" + "\r\n" + "                    Demonware Monitoring\r\n"
				+ "                    --\r\n" + "                    Demonware Liveops\r\n" + "";

		nameMap.put("Subject", subject);
		nameMap.put("Mailbody", mailbody);

		return nameMap;
	}

	public Map<String, String> FinalIncident(String platformtitle) {
		String subject = "Demonware Final Incident Notification: [#" + currentdateupdated
				+ "] User Drop on Listed Title";
		String mailbody = "Start: " + utcdatetime + " UTC\r\n" + "                        " + edtdatetime + " EDT\r\n"
				+ "                        " + pstdatetime + "PDT\r\n" + "\r\n" + "                        End: "
				+ utcEnddatetime + " UTC\r\n" + "                        " + edtEnddatetime + " EDT\r\n"
				+ "                        " + pstEnddatetime + " PDT\r\n" + "\r\n"
				+ "                        Duration: 0:40:00\r\n" + "\r\n" + "\r\n"
				+ "                        Summary:\r\n"
				+ "                        We detected a user drop for the titles and/or services listed. Our operations team investigated this issue.\r\n"
				+ "\r\n" + "\r\n" + "                        Root cause category:\r\n"
				+ "                        Studio Caused Outage\r\n" + "\r\n"
				+ "                        Root cause:\r\n"
				+ "                        The studio pushed an update to the listed titles. Players logged out to download the update.\r\n"
				+ "\r\n" + "                        Resolution:\r\n"
				+ "                        No action was required by Demonware in order to resume service. Players were able to resume playing once they downloaded the update.\r\n"
				+ "\r\n" + "                        Action taken to prevent such incidents in future:\r\n"
				+ "                        The drop detected was related to an update pushed by the studio. No action can be taken by Demonware to prevent future recurrences. However, we will continue to monitor and report on these events to ensure the downtime is momentary and the root cause is properly understood.\r\n"
				+ "\r\n" + "                        Affected Titles/Services:\r\n" + "                          * "
				+ platformtitle + "\r\n" + "\r\n" + "                        Regards,\r\n" + "\r\n"
				+ "                        Demonware Monitoring\r\n" + "                        --\r\n"
				+ "                        Demonware Liveops\r\n" + "";
		nameMap.put("Subject", subject);
		nameMap.put("Mailbody", mailbody);

		return nameMap;

	}

}

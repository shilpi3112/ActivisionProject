package pageFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;
import automationLibrary.Driver;
import base.BaseClass;
import commonUtilities.Constants.GamesList;
import commonUtilities.Constants.Localecodes;
import commonUtilities.Stopwatchtime;
import commonUtilities.Utility;

public class SupportOptionsHomePage {

	BaseClass base;
	SupportHomePage shp;
	SupportOptionsResultPage sorp;

	// Games
	@FindBy(xpath = "//div[@class='container content']//h1")
	public WebElement supportoptionheader;
	@FindBy(id = "games")
	public WebElement gamessection;

	public WebElement selectgamebyname(String gamename) {
		return Driver.getDriver().findElement(By.xpath("//*[@id='games']/li[@data-game-title='" + gamename + "']"));
	}

	@FindBy(xpath = "//*[@id='headingOne']//span[3]")
	public WebElement selectedgameheader;
	@FindBy(xpath = "//*[@id='headingOne']//a")
	public WebElement selectedgameclass;
	// Platforms
	@FindBy(id = "headingTwo")
	public WebElement platformsection;

	public WebElement selectplatformbyname(String platform) {
		return Driver.getDriver().findElement(By.xpath("//*[@id='" + platform + "']"));
	}

	@FindBy(xpath = "//*[@id='headingTwo']//span[3]")
	public WebElement selectedplatformheader;
	@FindBy(xpath = "//*[@id='headingTwo']//a")
	public WebElement selectedplatformclass;
	// Topics
	@FindBy(id = "headingThree")
	public WebElement topicssection;

	public WebElement selecttopicbyname(String game, String topic) {
		return Driver.getDriver().findElement(By
				.xpath("//*[@id='collapseThree']//li[@data-game-title='" + game + "']/a[@data-title='" + topic + "']"));
	}

	@FindBy(xpath = "//*[@id='headingThree']//span[3]")
	public WebElement selectedtopicheader;
	@FindBy(xpath = "//*[@id='headingThree']//a")
	public WebElement selectedtopicclass;
	// Issues
	@FindBy(id = "issues")
	public WebElement issuesection;
	@FindBy(xpath = "//*[@id='headingFour']//span[3]")
	public WebElement selectedissueheader;
	@FindBy(xpath = "//*[@id='headingFour']//a")
	public WebElement selectedissueclass;
	@FindBy(xpath = "//*[@href='#collapseFour']")
	public WebElement selectedissue;
	@FindBy(xpath = "//*[@href='#collapseThree']")
	public WebElement selectedtopic;
	@FindBy(xpath = "//*[@href='#collapseTwo']")
	public WebElement selectedplatform;

	public List<WebElement> selectissuebyname(String game, String topic) {
		return Driver.getDriver().findElements(By.xpath(
				"//*[@id='collapseFour']//li[@data-game-title='" + game + "' and @data-topics='" + topic + "']/a"));
	}

	public SupportOptionsHomePage() throws Exception {
		base = new BaseClass();
		PageFactory.initElements(Driver.getDriver(), this);

		shp = new SupportHomePage();
		sorp = new SupportOptionsResultPage();
		shp.SupportOptions.click();
	}

	public void selectGame(GamesList gamename) throws InterruptedException {
		SoftAssert sa = new SoftAssert();
		String classtext;
		String area;
		base.waitTillElemetToBeClickable(gamessection);
		base.stepInfo("Verify Games section is visible");
		sa.assertTrue(gamessection.isDisplayed());
		base.passedStep("Games section is available and displayed ");
		classtext = selectedgameheader.getAttribute("class");
		area = selectedgameclass.getAttribute("aria-expanded");
		sa.assertEquals(classtext, "selected-option inactive");
		sa.assertTrue(selectedgameheader.getText().equals(""));
		sa.assertEquals(area, "true");
		base.passedStep("Area is displayed as expanded");
		base.stepInfo("Select Game--->" + selectgamebyname(gamename.toString()).getText());

		selectgamebyname(gamename.toString()).click();
		sa.assertEquals(selectedgameheader.getText(), gamename.toString());
		base.passedStep("Games is selected and header is displayed as expected---->" + selectedgameheader.getText());
		base.waituntilelementtobevisible(selectedgameclass, 10);
		classtext = selectedgameclass.getAttribute("class");
		area = selectedgameclass.getAttribute("aria-expanded");
		sa.assertEquals(classtext, "collapsed clickable");
		sa.assertEquals(area, "false");
		sa.assertTrue(selectedgameheader.getText().equals(gamename.toString()));
		base.passedStep("Area is displayed as collapsed");
	}

	public void selectPlatform(String platformname) throws InterruptedException {
		SoftAssert sa = new SoftAssert();
		String platformtext;
		String area;
		base.waitTillElemetToBeClickable(platformsection);
		base.stepInfo("Verify Platform section is visible");
		sa.assertTrue(platformsection.isDisplayed());
		base.passedStep("Platform section is available and displayed ");
		// base.waituntilelementtobevisible(selectedplatform, 10);
		// sa.assertTrue(selectedissueclass.getAttribute("aria-expanded").equals("false"));
		base.javascriptclick(selectedplatform);
		Thread.sleep(1000);
		// base.waituntilelementtobevisible(selectedplatformheader, 5);
		platformtext = selectedplatformheader.getAttribute("class");
		area = selectedplatformclass.getAttribute("aria-expanded");
		sa.assertEquals(platformtext, "selected-option inactive");
		sa.assertTrue(selectedplatformheader.getText().equals(""));
		// sa.assertEquals(area, "true");
		base.passedStep("Area is displayed as expanded");
		base.stepInfo("Select platform--->" + selectplatformbyname(platformname).getText());
		Driver.getinstance().scrollingToElementofAPage(selectplatformbyname(platformname));
		selectplatformbyname(platformname).click();
		base.waitTillElemetToBeClickable(selectedplatformheader);
		sa.assertEquals(selectedplatformheader.getText(), platformname);
		base.passedStep(
				"Platform is selected and header is displayed as expected--->" + selectedplatformheader.getText());
		platformtext = selectedplatformclass.getAttribute("class");
		area = selectedplatformclass.getAttribute("aria-expanded");
		// sa.assertEquals(platformtext, "collapsed clickable");
		// sa.assertEquals(area, "false");
		sa.assertTrue(selectedplatformheader.getText().equals(platformname));
		base.passedStep("Area is displayed as collapsed");
	}

	public void selectTopic(GamesList gamename, String topicname) throws InterruptedException {
		SoftAssert sa = new SoftAssert();
		String topictext;
		String area;
		base.waitTillElemetToBeClickable(topicssection);
		base.stepInfo("Verify Topics section is visible");
		sa.assertTrue(topicssection.isDisplayed());
		base.passedStep("Topics section is available and displayed ");
		// sa.assertTrue(selectedtopicclass.getAttribute("aria-expanded").equals("false"));

		selectedtopic.click();
		// base.waitForElementToBeVisible(selectedtopicheader, 10);

		base.javascriptclick(selectedtopic);
		// base.waitTillElemetToBeClickable(selectedtopicheader);
		topictext = selectedtopicheader.getAttribute("class");
		area = selectedtopicclass.getAttribute("aria-expanded");
		sa.assertEquals(topictext, "selected-option inactive");
		sa.assertTrue(selectedtopicheader.getText().equals(""));
		// sa.assertEquals(area, "true");
		base.passedStep("Area is displayed as expanded");
		base.stepInfo("Select Topic--->" + selecttopicbyname(gamename.toString(), topicname).getText());
		Thread.sleep(1000);
		// base.waitTillElemetToBeClickable(selecttopicbyname(gamename.toString(),topicname));
		Driver.getinstance().scrollingToElementofAPage(selecttopicbyname(gamename.toString(), topicname));
		selecttopicbyname(gamename.toString(), topicname).click();
		Thread.sleep(1000);
		base.waitTillElemetToBeClickable(selectedtopicheader);
		sa.assertEquals(selectedtopicheader.getText(), topicname);
		base.passedStep("Topic is selected and header is displayed as expected--->" + selectedtopicheader.getText());
		topictext = selectedtopicclass.getAttribute("class");
		area = selectedtopicclass.getAttribute("aria-expanded");
		// sa.assertEquals(topictext, "clickable collapsed");
		// sa.assertEquals(area, "false");
		sa.assertTrue(selectedtopicheader.getText().equals(topicname));
		base.passedStep("Area is displayed as collapsed");
	}

	public void selectIssue(GamesList gamename, String topicname, String issuetitle) throws Exception {
		SoftAssert sa = new SoftAssert();
		String issuetext;
		String area;

		base.waitTillElemetToBeClickable(issuesection);
		base.waitForElementToBeVisible(issuesection, 5);
		base.stepInfo("Verify Issues section is visible");
		sa.assertTrue(issuesection.isDisplayed());
		base.passedStep("Issues section is available and displayed ");
		selectedissue.click();
		Driver.getinstance().waitTime(1);
		// sa.assertTrue(selectedissueclass.getAttribute("aria-expanded").equals("false"));
		base.javascriptclick(selectedissue);
		Driver.getinstance().waitTime(1);
		// sa.assertTrue(alloptionstext.getText().equals("What's your issue?"));
		base.waitForElementToBeVisible(selectedissueclass, 10);
		issuetext = selectedissueheader.getAttribute("class");
		area = selectedissueclass.getAttribute("aria-expanded");
		sa.assertEquals(issuetext, "selected-option inactive");
		sa.assertTrue(selectedissueheader.getText().equals(""));
		// sa.assertEquals(area, "true");
		base.passedStep("Area is displayed as expanded");

		for (WebElement e : selectissuebyname(gamename.toString(), topicname)) {
			if (e.getAttribute("data-title").toString().equalsIgnoreCase(issuetitle)) {
				base.passedStep("Issue is selected and solution page is displayed--->"
						+ e.getAttribute("data-title").toString());
				base.waitTillElemetToBeClickable(e);
				e.click();
				base.waitTillElemetToBeClickable(sorp.backtoselections);
				break;
			}
		}
	}

	public void validatePlatforms(String localename, String filepath, GamesList gamename, Localecodes code)
			throws Exception, IOException {
		SoftAssert sa = new SoftAssert();
		List<String> expectedplatforms = base.readExcelColumnData(filepath, localename, "Platforms");
		List<String> expectedtopics = base.readExcelColumnData(filepath, localename, "Topics");

		for (int i = 0; i < expectedplatforms.size(); i++) {

			Driver.getinstance().waitForPageToBeReady();
			selectPlatform(expectedplatforms.get(i));

			for (int i1 = 0; i1 < expectedtopics.size(); i1++) {
				selectTopic(gamename, expectedtopics.get(i1));

				Map<String, List<Row>> data = new HashMap<>();

				// Driver.getinstance().waitTime(2);
				data = base.setfilter(Utility.SupportOptionsWarzone2, localename);
				// Thread.sleep(1000);

				List<Row> getissues = data.get(expectedtopics.get(i1));
				// Thread.sleep(1000);

				for (Row issuedata : getissues) {
					selectIssue(gamename, expectedtopics.get(i1), issuedata.getCell(1).toString());

					List<Row> issuesolution = data.get(issuedata.getCell(1).toString());
					for (Row solution : issuesolution) {

						if (sorp.mainsolutionblock.isDisplayed()) {
							try {
								if (base.waitForElementToBeVisible(sorp.mainiconarticle, 5)) {
									sorp.validateSuggestedOptions_Article1(solution.getCell(1).toString());
								} else if (base.waitForElementToBeVisible(sorp.mainiconticket, 2)) {
									base.waitTillElemetToBeClickable(sorp.mainiconticket);
									sa.assertTrue(sorp.mainiconticket.isDisplayed());
									base.passedStep("Ticket icon is displayed as expected");
								} else {
									sorp.validateSuggestedOptions_ReportBug(solution.getCell(1).toString(), code);
								}
							}

							catch (Exception e) {
								base.stepInfo("Element not present");
							}
						}

						try {
							if (sorp.secondaryarticlesection.isDisplayed()) {
								sorp.validateSecondary_Article(solution.getCell(2).toString(),
										solution.getCell(3).toString());
							}
						} catch (Exception e) {
							base.stepInfo("Element is not present " + sorp.secondaryarticlesection);
						}
						sorp.validateAdditionalOptionsSection();

						try {
							if (sorp.OnlineServicesicon.isDisplayed()) {
								sorp.validateSuggestedOptions_OnlineServices(solution.getCell(2).toString(),
										solution.getCell(3).toString());
							}
						} catch (Exception e) {
							base.stepInfo("Element is not present " + sorp.OnlineServicesicon);
						}

						try {
							if (sorp.ticketicon.isDisplayed()) {
								sorp.validateSuggestedOptions_SubmitTicket(solution.getCell(4).toString(),
										solution.getCell(5).toString());
							}
						} catch (Exception e) {
							base.stepInfo("Element is not present " + sorp.ticketicon);
						}
						if (sorp.producticon.isDisplayed()) {
							sorp.validateSuggestedOptions_ProductPage(solution.getCell(6).toString(),
									solution.getCell(7).toString());
						}
						sorp.navigateBackToSelection();
					}
				}
			}

		}
		sa.assertAll();
	}

}

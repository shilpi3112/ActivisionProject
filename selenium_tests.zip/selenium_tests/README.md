# [BACKUP] Test Automation Framework
Backup of the test automation framework that lives on a windows server.

Code was taken from the server, packages into git, and copied here to this repo.

Because this repo is only a backup, commits made may not reflect the original authors.